package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        UserProfile::class,
        DailyLog::class,
        StudyTask::class,
        ScheduleSlot::class,
        FavoriteItem::class,
        TasbihCounter::class,
        StudySession::class,
        StudyGoal::class,
        DbVerse::class,
        DbHadith::class,
        DbDua::class,
        DbFatwa::class,
        DbStory::class,
        DbCategory::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userProfileDao(): UserProfileDao
    abstract fun dailyLogDao(): DailyLogDao
    abstract fun studyTaskDao(): StudyTaskDao
    abstract fun scheduleSlotDao(): ScheduleSlotDao
    abstract fun favoriteItemDao(): FavoriteItemDao
    abstract fun tasbihCounterDao(): TasbihCounterDao
    abstract fun studySessionDao(): StudySessionDao
    abstract fun studyGoalDao(): StudyGoalDao
    abstract fun dbVerseDao(): DbVerseDao
    abstract fun dbHadithDao(): DbHadithDao
    abstract fun dbDuaDao(): DbDuaDao
    abstract fun dbFatwaDao(): DbFatwaDao
    abstract fun dbStoryDao(): DbStoryDao
    abstract fun dbCategoryDao(): DbCategoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "alkanz_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
