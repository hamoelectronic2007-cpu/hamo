package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserProfileDao {
    @Query("SELECT * FROM user_profiles WHERE id = 1 LIMIT 1")
    fun getUserProfile(): Flow<UserProfile?>

    @Query("SELECT * FROM user_profiles WHERE id = 1 LIMIT 1")
    suspend fun getUserProfileOneShot(): UserProfile?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(profile: UserProfile)
}

@Dao
interface DailyLogDao {
    @Query("SELECT * FROM daily_logs WHERE dateString = :dateString LIMIT 1")
    fun getDailyLog(dateString: String): Flow<DailyLog?>

    @Query("SELECT * FROM daily_logs WHERE dateString = :dateString LIMIT 1")
    suspend fun getDailyLogOneShot(dateString: String): DailyLog?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(log: DailyLog)
}

@Dao
interface StudyTaskDao {
    @Query("SELECT * FROM study_tasks ORDER BY id DESC")
    fun getAllTasks(): Flow<List<StudyTask>>

    @Query("SELECT * FROM study_tasks WHERE dateString = :dateString ORDER BY id DESC")
    fun getTasksForDate(dateString: String): Flow<List<StudyTask>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: StudyTask)

    @Update
    suspend fun updateTask(task: StudyTask)

    @Delete
    suspend fun deleteTask(task: StudyTask)

    @Query("DELETE FROM study_tasks WHERE id = :id")
    suspend fun deleteTaskById(id: Int)
}

@Dao
interface ScheduleSlotDao {
    @Query("SELECT * FROM schedule_slots ORDER BY id ASC")
    fun getAllSlots(): Flow<List<ScheduleSlot>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSlot(slot: ScheduleSlot)

    @Delete
    suspend fun deleteSlot(slot: ScheduleSlot)

    @Query("DELETE FROM schedule_slots WHERE dayOfWeek = :dayOfWeek AND timeSlot = :timeSlot")
    suspend fun deleteSlotByTime(dayOfWeek: String, timeSlot: String)
}

@Dao
interface FavoriteItemDao {
    @Query("SELECT * FROM favorite_items ORDER BY timestamp DESC")
    fun getAllFavorites(): Flow<List<FavoriteItem>>

    @Query("SELECT EXISTS(SELECT 1 FROM favorite_items WHERE text = :text LIMIT 1)")
    suspend fun isFavorite(text: String): Boolean

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFavorite(item: FavoriteItem)

    @Query("DELETE FROM favorite_items WHERE text = :text")
    suspend fun deleteFavoriteByText(text: String)

    @Delete
    suspend fun deleteFavorite(item: FavoriteItem)
}

@Dao
interface TasbihCounterDao {
    @Query("SELECT * FROM tasbih_counters ORDER BY id ASC")
    fun getAllCounters(): Flow<List<TasbihCounter>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCounter(counter: TasbihCounter)

    @Update
    suspend fun updateCounter(counter: TasbihCounter)

    @Delete
    suspend fun deleteCounter(counter: TasbihCounter)

    @Query("UPDATE tasbih_counters SET count = :count WHERE id = :id")
    suspend fun updateCount(id: Int, count: Int)
}

@Dao
interface StudySessionDao {
    @Query("SELECT * FROM study_sessions ORDER BY dateString DESC, startTime DESC")
    fun getAllSessions(): Flow<List<StudySession>>

    @Query("SELECT * FROM study_sessions WHERE dateString = :dateString ORDER BY startTime DESC")
    fun getSessionsForDate(dateString: String): Flow<List<StudySession>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSession(session: StudySession)

    @Delete
    suspend fun deleteSession(session: StudySession)
}

@Dao
interface StudyGoalDao {
    @Query("SELECT * FROM study_goals ORDER BY id DESC")
    fun getAllGoals(): Flow<List<StudyGoal>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: StudyGoal)

    @Update
    suspend fun updateGoal(goal: StudyGoal)

    @Delete
    suspend fun deleteGoal(goal: StudyGoal)
}

@Dao
interface DbVerseDao {
    @Query("SELECT * FROM verses ORDER BY id ASC")
    fun getAllVerses(): Flow<List<DbVerse>>

    @Query("SELECT * FROM verses WHERE text LIKE '%' || :query || '%' OR surahName LIKE '%' || :query || '%'")
    fun searchVerses(query: String): Flow<List<DbVerse>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVerse(verse: DbVerse)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVerses(verses: List<DbVerse>)
}

@Dao
interface DbHadithDao {
    @Query("SELECT * FROM hadiths ORDER BY id ASC")
    fun getAllHadiths(): Flow<List<DbHadith>>

    @Query("SELECT * FROM hadiths WHERE text LIKE '%' || :query || '%'")
    fun searchHadiths(query: String): Flow<List<DbHadith>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHadith(hadith: DbHadith)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHadiths(hadiths: List<DbHadith>)
}

@Dao
interface DbDuaDao {
    @Query("SELECT * FROM duas ORDER BY id ASC")
    fun getAllDuas(): Flow<List<DbDua>>

    @Query("SELECT * FROM duas WHERE text LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%'")
    fun searchDuas(query: String): Flow<List<DbDua>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDua(dua: DbDua)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertDuas(duas: List<DbDua>)
}

@Dao
interface DbFatwaDao {
    @Query("SELECT * FROM fatawa ORDER BY id ASC")
    fun getAllFatawa(): Flow<List<DbFatwa>>

    @Query("SELECT * FROM fatawa WHERE question LIKE '%' || :query || '%' OR answer LIKE '%' || :query || '%'")
    fun searchFatawa(query: String): Flow<List<DbFatwa>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFatwa(fatwa: DbFatwa)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFatawa(fatawa: List<DbFatwa>)
}

@Dao
interface DbStoryDao {
    @Query("SELECT * FROM stories ORDER BY id ASC")
    fun getAllStories(): Flow<List<DbStory>>

    @Query("SELECT * FROM stories WHERE title LIKE '%' || :query || '%' OR content LIKE '%' || :query || '%'")
    fun searchStories(query: String): Flow<List<DbStory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStory(story: DbStory)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStories(stories: List<DbStory>)
}

@Dao
interface DbCategoryDao {
    @Query("SELECT * FROM categories ORDER BY id ASC")
    fun getAllCategories(): Flow<List<DbCategory>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: DbCategory)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategories(categories: List<DbCategory>)
}
