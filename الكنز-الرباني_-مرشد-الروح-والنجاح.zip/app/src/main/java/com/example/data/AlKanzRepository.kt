package com.example.data

import kotlinx.coroutines.flow.Flow

class AlKanzRepository(private val database: AppDatabase) {

    private val userProfileDao = database.userProfileDao()
    private val dailyLogDao = database.dailyLogDao()
    private val studyTaskDao = database.studyTaskDao()
    private val scheduleSlotDao = database.scheduleSlotDao()
    private val favoriteItemDao = database.favoriteItemDao()
    private val tasbihCounterDao = database.tasbihCounterDao()
    private val studySessionDao = database.studySessionDao()
    private val studyGoalDao = database.studyGoalDao()
    private val dbVerseDao = database.dbVerseDao()
    private val dbHadithDao = database.dbHadithDao()
    private val dbDuaDao = database.dbDuaDao()
    private val dbFatwaDao = database.dbFatwaDao()
    private val dbStoryDao = database.dbStoryDao()
    private val dbCategoryDao = database.dbCategoryDao()

    // --- User Profile ---
    fun getUserProfile(): Flow<UserProfile?> = userProfileDao.getUserProfile()
    
    suspend fun getUserProfileOneShot(): UserProfile? = userProfileDao.getUserProfileOneShot()

    suspend fun saveUserProfile(profile: UserProfile) {
        userProfileDao.insertOrUpdate(profile)
    }

    // --- Daily Log ---
    fun getDailyLog(dateString: String): Flow<DailyLog?> = dailyLogDao.getDailyLog(dateString)

    suspend fun getDailyLogOneShot(dateString: String): DailyLog? = dailyLogDao.getDailyLogOneShot(dateString)

    suspend fun saveDailyLog(log: DailyLog) {
        dailyLogDao.insertOrUpdate(log)
    }

    // --- Study Tasks ---
    fun getAllTasks(): Flow<List<StudyTask>> = studyTaskDao.getAllTasks()

    fun getTasksForDate(dateString: String): Flow<List<StudyTask>> = studyTaskDao.getTasksForDate(dateString)

    suspend fun insertTask(task: StudyTask) {
        studyTaskDao.insertTask(task)
    }

    suspend fun updateTask(task: StudyTask) {
        studyTaskDao.updateTask(task)
    }

    suspend fun deleteTask(task: StudyTask) {
        studyTaskDao.deleteTask(task)
    }

    suspend fun deleteTaskById(id: Int) {
        studyTaskDao.deleteTaskById(id)
    }

    // --- Schedule Slots ---
    fun getAllSlots(): Flow<List<ScheduleSlot>> = scheduleSlotDao.getAllSlots()

    suspend fun insertSlot(slot: ScheduleSlot) {
        scheduleSlotDao.insertSlot(slot)
    }

    suspend fun deleteSlot(slot: ScheduleSlot) {
        scheduleSlotDao.deleteSlot(slot)
    }

    suspend fun deleteSlotByTime(dayOfWeek: String, timeSlot: String) {
        scheduleSlotDao.deleteSlotByTime(dayOfWeek, timeSlot)
    }

    // --- Favorites ---
    fun getAllFavorites(): Flow<List<FavoriteItem>> = favoriteItemDao.getAllFavorites()

    suspend fun isFavorite(text: String): Boolean = favoriteItemDao.isFavorite(text)

    suspend fun addFavorite(text: String, category: String) {
        favoriteItemDao.insertFavorite(FavoriteItem(text = text, category = category))
    }

    suspend fun removeFavoriteByText(text: String) {
        favoriteItemDao.deleteFavoriteByText(text)
    }

    suspend fun deleteFavorite(item: FavoriteItem) {
        favoriteItemDao.deleteFavorite(item)
    }

    // --- Tasbih ---
    fun getAllCounters(): Flow<List<TasbihCounter>> = tasbihCounterDao.getAllCounters()

    suspend fun insertCounter(counter: TasbihCounter) {
        tasbihCounterDao.insertCounter(counter)
    }

    suspend fun updateCounter(counter: TasbihCounter) {
        tasbihCounterDao.updateCounter(counter)
    }

    suspend fun deleteCounter(counter: TasbihCounter) {
        tasbihCounterDao.deleteCounter(counter)
    }

    suspend fun updateCount(id: Int, count: Int) {
        tasbihCounterDao.updateCount(id, count)
    }

    // --- Study Sessions ---
    fun getAllSessions(): Flow<List<StudySession>> = studySessionDao.getAllSessions()
    fun getSessionsForDate(dateString: String): Flow<List<StudySession>> = studySessionDao.getSessionsForDate(dateString)
    suspend fun insertSession(session: StudySession) = studySessionDao.insertSession(session)
    suspend fun deleteSession(session: StudySession) = studySessionDao.deleteSession(session)

    // --- Study Goals ---
    fun getAllGoals(): Flow<List<StudyGoal>> = studyGoalDao.getAllGoals()
    suspend fun insertGoal(goal: StudyGoal) = studyGoalDao.insertGoal(goal)
    suspend fun updateGoal(goal: StudyGoal) = studyGoalDao.updateGoal(goal)
    suspend fun deleteGoal(goal: StudyGoal) = studyGoalDao.deleteGoal(goal)

    // --- DB Verses ---
    fun getAllVerses(): Flow<List<DbVerse>> = dbVerseDao.getAllVerses()
    fun searchVerses(query: String): Flow<List<DbVerse>> = dbVerseDao.searchVerses(query)
    suspend fun insertVerse(verse: DbVerse) = dbVerseDao.insertVerse(verse)
    suspend fun insertVerses(verses: List<DbVerse>) = dbVerseDao.insertVerses(verses)

    // --- DB Hadiths ---
    fun getAllHadiths(): Flow<List<DbHadith>> = dbHadithDao.getAllHadiths()
    fun searchHadiths(query: String): Flow<List<DbHadith>> = dbHadithDao.searchHadiths(query)
    suspend fun insertHadith(hadith: DbHadith) = dbHadithDao.insertHadith(hadith)
    suspend fun insertHadiths(hadiths: List<DbHadith>) = dbHadithDao.insertHadiths(hadiths)

    // --- DB Duas ---
    fun getAllDuas(): Flow<List<DbDua>> = dbDuaDao.getAllDuas()
    fun searchDuas(query: String): Flow<List<DbDua>> = dbDuaDao.searchDuas(query)
    suspend fun insertDua(dua: DbDua) = dbDuaDao.insertDua(dua)
    suspend fun insertDuas(duas: List<DbDua>) = dbDuaDao.insertDuas(duas)

    // --- DB Fatawa ---
    fun getAllFatawa(): Flow<List<DbFatwa>> = dbFatwaDao.getAllFatawa()
    fun searchFatawa(query: String): Flow<List<DbFatwa>> = dbFatwaDao.searchFatawa(query)
    suspend fun insertFatwa(fatwa: DbFatwa) = dbFatwaDao.insertFatwa(fatwa)
    suspend fun insertFatawa(fatawa: List<DbFatwa>) = dbFatwaDao.insertFatawa(fatawa)

    // --- DB Stories ---
    fun getAllStories(): Flow<List<DbStory>> = dbStoryDao.getAllStories()
    fun searchStories(query: String): Flow<List<DbStory>> = dbStoryDao.searchStories(query)
    suspend fun insertStory(story: DbStory) = dbStoryDao.insertStory(story)
    suspend fun insertStories(stories: List<DbStory>) = dbStoryDao.insertStories(stories)

    // --- DB Categories ---
    fun getAllCategories(): Flow<List<DbCategory>> = dbCategoryDao.getAllCategories()
    suspend fun insertCategory(category: DbCategory) = dbCategoryDao.insertCategory(category)
    suspend fun insertCategories(categories: List<DbCategory>) = dbCategoryDao.insertCategories(categories)
}
