package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profiles")
data class UserProfile(
    @PrimaryKey val id: Int = 1, // Single user app, so we only use id = 1
    val name: String = "محمد حسام",
    val targetPercentage: Double = 99.0,
    val targetCollege: String = "كلية الهندسة، جامعة الإسكندرية",
    val examDateMillis: Long = 1813449600000L // Approx June 15, 2027 (in millis)
)

@Entity(tableName = "daily_logs")
data class DailyLog(
    @PrimaryKey val dateString: String, // format: "yyyy-MM-dd"
    val quranReadCount: Int = 0,
    val focusLevel: Int = 5, // 1 to 10
    val morningAzkarCompleted: Boolean = false,
    val eveningAzkarCompleted: Boolean = false,
    val duhaCompleted: Boolean = false,
    val nightPrayerCompleted: Boolean = false,
    val intentionSet: Boolean = false
)

@Entity(tableName = "study_tasks")
data class StudyTask(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val subject: String, // e.g. "عربي", "إنجليزي", "كيمياء", "فيزياء", "أحياء", "جيولوجيا"
    val isCompleted: Boolean = false,
    val dateString: String, // format: "yyyy-MM-dd"
    val timeString: String = "12:00",
    val priority: String = "MEDIUM", // "HIGH", "MEDIUM", "LOW"
    val status: String = "PENDING" // "PENDING", "COMPLETED", "POSTPONED"
)

@Entity(tableName = "study_sessions")
data class StudySession(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dateString: String, // format: "yyyy-MM-dd"
    val startTime: String,
    val endTime: String,
    val subject: String,
    val pagesCount: Int = 0,
    val notes: String = ""
)

@Entity(tableName = "study_goals")
data class StudyGoal(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val description: String = "",
    val targetDateString: String, // format: "yyyy-MM-dd"
    val progressPercentage: Int = 0 // 0 to 100
)

@Entity(tableName = "schedule_slots")
data class ScheduleSlot(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val dayOfWeek: String, // "السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة"
    val timeSlot: String,  // "صباحاً", "مساءً"
    val subject: String    // Subject name
)

@Entity(tableName = "favorite_items")
data class FavoriteItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val category: String, // e.g. "أذكار", "رقية", "حديث", "قصة"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "tasbih_counters")
data class TasbihCounter(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val count: Int = 0,
    val targetCount: Int = 33
)

// --- Encyclopedia of Ruqyah & Azkar Tables ---

@Entity(tableName = "verses")
data class DbVerse(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val surahName: String,
    val verseNumber: String,
    val text: String,
    val tafsir: String = "",
    val categoryId: Int = 0,
    val tags: String = ""
)

@Entity(tableName = "hadiths")
data class DbHadith(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val source: String,
    val grade: String = "صحيح",
    val categoryId: Int = 0
)

@Entity(tableName = "duas")
data class DbDua(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val text: String,
    val category: String,
    val description: String = "",
    val source: String = ""
)

@Entity(tableName = "fatawa")
data class DbFatwa(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val question: String,
    val answer: String,
    val scholar: String,
    val category: String
)

@Entity(tableName = "stories")
data class DbStory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val content: String,
    val source: String = ""
)

@Entity(tableName = "categories")
data class DbCategory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val parentId: Int = 0
)
