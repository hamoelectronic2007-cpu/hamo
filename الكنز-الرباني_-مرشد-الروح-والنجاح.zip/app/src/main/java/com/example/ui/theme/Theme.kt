package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = DeepGold,
    secondary = EmeraldGreen,
    tertiary = RichGold,
    background = DarkBackground,
    surface = CardGreen,
    onPrimary = DarkBackground,
    onSecondary = PaleGold,
    onTertiary = DarkBackground,
    onBackground = TextGold,
    onSurface = TextGold
)

private val LightColorScheme = lightColorScheme(
    primary = LightPrimary,
    secondary = LightSecondary,
    tertiary = DeepGold,
    background = LightBackground,
    surface = LightSurface,
    onPrimary = LightBackground,
    onSecondary = IslamicDeepGreen,
    onTertiary = IslamicDeepGreen,
    onBackground = IslamicDeepGreen,
    onSurface = IslamicDeepGreen
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    // Keep specialized colors consistent by default
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit,
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
