package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Premium Islamic Green & Gold Theme
val IslamicDeepGreen = Color(0xFF0A2F1F)
val EmeraldGreen = Color(0xFF14532D)
val CardGreen = Color(0xFF0F3A24)
val DarkBackground = Color(0xFF03140C)

val DeepGold = Color(0xFFD4AF37)
val RichGold = Color(0xFFFFD700)
val PaleGold = Color(0xFFF3E5AB)
val TextGold = Color(0xFFFFEFA8)

val LightBackground = Color(0xFFF5FDF7)
val LightPrimary = Color(0xFF1B5E20)
val LightSecondary = Color(0xFFF57F17)
val LightSurface = Color(0xFFE8F5E9)

