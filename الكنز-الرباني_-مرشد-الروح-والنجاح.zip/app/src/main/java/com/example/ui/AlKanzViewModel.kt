package com.example.ui

import android.app.Application
import android.speech.tts.TextToSpeech
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AlKanzViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val repository: AlKanzRepository
    private var tts: TextToSpeech? = null
    private var isTtsInitialized = false

    init {
        val database = AppDatabase.getDatabase(application)
        repository = AlKanzRepository(database)
        tts = TextToSpeech(application, this)
        
        // Initialize default database data
        initializeDefaultData()
    }

    // --- State: Navigation and UI ---
    private val _currentScreen = MutableStateFlow(Screen.Dashboard)
    val currentScreen: StateFlow<Screen> = _currentScreen.asStateFlow()

    fun navigateTo(screen: Screen) {
        _currentScreen.value = screen
    }

    // Settings & Preferences
    private val _fontScale = MutableStateFlow(1.2f)
    val fontScale: StateFlow<Float> = _fontScale.asStateFlow()

    fun updateFontScale(scale: Float) {
        _fontScale.value = scale
    }

    private val _isNightMode = MutableStateFlow<Boolean?>(null) // null = Automatic (system)
    val isNightMode: StateFlow<Boolean?> = _isNightMode.asStateFlow()

    fun setNightMode(mode: Boolean?) {
        _isNightMode.value = mode
    }

    // Selected Date (For tasks and daily log, defaults to today)
    private val _selectedDate = MutableStateFlow(getTodayDateString())
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    fun setSelectedDate(dateString: String) {
        _selectedDate.value = dateString
    }

    // --- Flows: Room Data ---
    val userProfile: StateFlow<UserProfile> = repository.getUserProfile()
        .map { it ?: UserProfile() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserProfile())

    val dailyLog: StateFlow<DailyLog> = _selectedDate
        .flatMapLatest { date ->
            repository.getDailyLog(date).map { it ?: DailyLog(dateString = date) }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DailyLog(getTodayDateString()))

    val tasksForSelectedDate: StateFlow<List<StudyTask>> = _selectedDate
        .flatMapLatest { date -> repository.getTasksForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allScheduleSlots: StateFlow<List<ScheduleSlot>> = repository.getAllSlots()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allFavorites: StateFlow<List<FavoriteItem>> = repository.getAllFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTasbihCounters: StateFlow<List<TasbihCounter>> = repository.getAllCounters()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allGoals: StateFlow<List<StudyGoal>> = repository.getAllGoals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allSessions: StateFlow<List<StudySession>> = repository.getAllSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sessionsForSelectedDate: StateFlow<List<StudySession>> = _selectedDate
        .flatMapLatest { date -> repository.getSessionsForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Search Flows for Encyclopedia ---
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    val searchResultsVerses: StateFlow<List<DbVerse>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isEmpty()) repository.getAllVerses() else repository.searchVerses(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResultsHadiths: StateFlow<List<DbHadith>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isEmpty()) repository.getAllHadiths() else repository.searchHadiths(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResultsDuas: StateFlow<List<DbDua>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isEmpty()) repository.getAllDuas() else repository.searchDuas(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResultsFatawa: StateFlow<List<DbFatwa>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isEmpty()) repository.getAllFatawa() else repository.searchFatawa(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val searchResultsStories: StateFlow<List<DbStory>> = _searchQuery
        .flatMapLatest { query ->
            if (query.isEmpty()) repository.getAllStories() else repository.searchStories(query)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCategories: StateFlow<List<DbCategory>> = repository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- Pomodoro Timer State ---
    private val _pomodoroSecondsLeft = MutableStateFlow(25 * 60)
    val pomodoroSecondsLeft: StateFlow<Int> = _pomodoroSecondsLeft.asStateFlow()

    private val _pomodoroIsActive = MutableStateFlow(false)
    val pomodoroIsActive: StateFlow<Boolean> = _pomodoroIsActive.asStateFlow()

    private val _pomodoroMode = MutableStateFlow(PomodoroMode.STUDY)
    val pomodoroMode: StateFlow<PomodoroMode> = _pomodoroMode.asStateFlow()

    private var pomodoroJob: Job? = null

    fun startPomodoro() {
        if (_pomodoroIsActive.value) return
        _pomodoroIsActive.value = true
        pomodoroJob = viewModelScope.launch {
            while (_pomodoroSecondsLeft.value > 0) {
                delay(1000)
                _pomodoroSecondsLeft.value -= 1
            }
            // Timer finished! Toggle mode and reset
            if (_pomodoroMode.value == PomodoroMode.STUDY) {
                _pomodoroMode.value = PomodoroMode.BREAK
                _pomodoroSecondsLeft.value = 5 * 60
            } else {
                _pomodoroMode.value = PomodoroMode.STUDY
                _pomodoroSecondsLeft.value = 25 * 60
            }
            _pomodoroIsActive.value = false
            speakText(if (_pomodoroMode.value == PomodoroMode.BREAK) "انتهت جلسة المذاكرة. وقت الاستراحة خمس دقائق." else "انتهى وقت الاستراحة. فلنبدأ جلسة مذاكرة جديدة.")
        }
    }

    fun pausePomodoro() {
        pomodoroJob?.cancel()
        _pomodoroIsActive.value = false
    }

    fun resetPomodoro() {
        pomodoroJob?.cancel()
        _pomodoroIsActive.value = false
        _pomodoroMode.value = PomodoroMode.STUDY
        _pomodoroSecondsLeft.value = 25 * 60
    }

    // --- Actions: User Profile ---
    fun updateProfile(name: String, targetPct: Double, college: String, examDateMillis: Long) {
        viewModelScope.launch {
            repository.saveUserProfile(
                UserProfile(
                    id = 1,
                    name = name,
                    targetPercentage = targetPct,
                    targetCollege = college,
                    examDateMillis = examDateMillis
                )
            )
        }
    }

    // --- Actions: Daily Logs ---
    fun incrementQuranCount() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(quranReadCount = currentLog.quranReadCount + 1))
        }
    }

    fun decrementQuranCount() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            if (currentLog.quranReadCount > 0) {
                repository.saveDailyLog(currentLog.copy(quranReadCount = currentLog.quranReadCount - 1))
            }
        }
    }

    fun updateFocusLevel(level: Int) {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(focusLevel = level))
        }
    }

    fun toggleMorningAzkar() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(morningAzkarCompleted = !currentLog.morningAzkarCompleted))
        }
    }

    fun toggleEveningAzkar() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(eveningAzkarCompleted = !currentLog.eveningAzkarCompleted))
        }
    }

    fun toggleDuha() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(duhaCompleted = !currentLog.duhaCompleted))
        }
    }

    fun toggleNightPrayer() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(nightPrayerCompleted = !currentLog.nightPrayerCompleted))
        }
    }

    fun toggleIntentionSet() {
        viewModelScope.launch {
            val currentLog = dailyLog.value
            repository.saveDailyLog(currentLog.copy(intentionSet = !currentLog.intentionSet))
        }
    }

    // --- Actions: Study Tasks ---
    fun addTask(title: String, subject: String, time: String = "12:00", priority: String = "MEDIUM", status: String = "PENDING") {
        viewModelScope.launch {
            repository.insertTask(
                StudyTask(
                    title = title,
                    subject = subject,
                    dateString = _selectedDate.value,
                    timeString = time,
                    priority = priority,
                    status = status,
                    isCompleted = status == "COMPLETED"
                )
            )
        }
    }

    fun toggleTaskCompletion(task: StudyTask) {
        viewModelScope.launch {
            val newIsCompleted = !task.isCompleted
            val newStatus = if (newIsCompleted) "COMPLETED" else "PENDING"
            repository.updateTask(task.copy(isCompleted = newIsCompleted, status = newStatus))
        }
    }

    fun updateTask(task: StudyTask) {
        viewModelScope.launch {
            repository.updateTask(task)
        }
    }

    fun deleteTask(task: StudyTask) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    // --- Actions: Study Sessions ---
    fun addStudySession(startTime: String, endTime: String, subject: String, pagesCount: Int, notes: String) {
        viewModelScope.launch {
            repository.insertSession(
                StudySession(
                    dateString = _selectedDate.value,
                    startTime = startTime,
                    endTime = endTime,
                    subject = subject,
                    pagesCount = pagesCount,
                    notes = notes
                )
            )
        }
    }

    fun deleteStudySession(session: StudySession) {
        viewModelScope.launch {
            repository.deleteSession(session)
        }
    }

    // --- Actions: Study Goals ---
    fun addStudyGoal(title: String, description: String, targetDateString: String, progress: Int = 0) {
        viewModelScope.launch {
            repository.insertGoal(
                StudyGoal(
                    title = title,
                    description = description,
                    targetDateString = targetDateString,
                    progressPercentage = progress
                )
            )
        }
    }

    fun updateStudyGoal(goal: StudyGoal) {
        viewModelScope.launch {
            repository.updateGoal(goal)
        }
    }

    fun deleteStudyGoal(goal: StudyGoal) {
        viewModelScope.launch {
            repository.deleteGoal(goal)
        }
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    // --- Actions: Schedule Slots ---
    fun addScheduleSlot(day: String, time: String, subject: String) {
        viewModelScope.launch {
            // Delete existing slot for this day and time to avoid overlaps
            repository.deleteSlotByTime(day, time)
            repository.insertSlot(
                ScheduleSlot(
                    dayOfWeek = day,
                    timeSlot = time,
                    subject = subject
                )
            )
        }
    }

    fun deleteScheduleSlot(slot: ScheduleSlot) {
        viewModelScope.launch {
            repository.deleteSlot(slot)
        }
    }

    // --- Actions: Favorites ---
    fun toggleFavorite(text: String, category: String) {
        viewModelScope.launch {
            if (repository.isFavorite(text)) {
                repository.removeFavoriteByText(text)
            } else {
                repository.addFavorite(text, category)
            }
        }
    }

    suspend fun isFavorite(text: String): Boolean {
        return repository.isFavorite(text)
    }

    fun removeFavorite(item: FavoriteItem) {
        viewModelScope.launch {
            repository.deleteFavorite(item)
        }
    }

    // --- Actions: Tasbih ---
    fun addTasbihCounter(name: String, target: Int) {
        viewModelScope.launch {
            repository.insertCounter(TasbihCounter(name = name, targetCount = target))
        }
    }

    fun incrementTasbih(counter: TasbihCounter) {
        viewModelScope.launch {
            val newCount = (counter.count + 1) % (counter.targetCount + 1)
            repository.updateCounter(counter.copy(count = newCount))
            if (newCount == counter.targetCount) {
                // Audio or voice cue if desired
                speakText("تمت المسبحة: ${counter.name}")
            }
        }
    }

    fun resetTasbih(counter: TasbihCounter) {
        viewModelScope.launch {
            repository.updateCounter(counter.copy(count = 0))
        }
    }

    fun deleteTasbih(counter: TasbihCounter) {
        viewModelScope.launch {
            repository.deleteCounter(counter)
        }
    }

    // --- Text To Speech ---
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("ar"))
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsInitialized = true
            }
        }
    }

    fun speakText(text: String) {
        if (isTtsInitialized) {
            // Clean text of Quran brackets for smoother speech
            val cleanText = text.replace("﴿", "").replace("﴾", "")
            tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "alkanz_tts")
        }
    }

    fun stopSpeaking() {
        if (isTtsInitialized) {
            tts?.stop()
        }
    }

    override fun onCleared() {
        super.onCleared()
        tts?.stop()
        tts?.shutdown()
        pomodoroJob?.cancel()
    }

    // --- Helpers ---
    private fun getTodayDateString(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Date())
    }

    private fun initializeDefaultData() {
        viewModelScope.launch {
            // Check and populate profile
            val currentProfile = repository.getUserProfileOneShot()
            if (currentProfile == null) {
                repository.saveUserProfile(UserProfile())
            }

            // Check and populate default weekly slots if empty
            val slots = repository.getAllSlots().first()
            if (slots.isEmpty()) {
                val defaultSlots = listOf(
                    ScheduleSlot(dayOfWeek = "السبت", timeSlot = "صباحاً", subject = "عربي"),
                    ScheduleSlot(dayOfWeek = "الأحد", timeSlot = "مساءً", subject = "كيمياء"),
                    ScheduleSlot(dayOfWeek = "الاثنين", timeSlot = "صباحاً", subject = "فيزياء"),
                    ScheduleSlot(dayOfWeek = "الثلاثاء", timeSlot = "مساءً", subject = "أحياء"),
                    ScheduleSlot(dayOfWeek = "الأربعاء", timeSlot = "صباحاً", subject = "جيولوجيا"),
                    ScheduleSlot(dayOfWeek = "الخميس", timeSlot = "مساءً", subject = "إنجليزي")
                )
                defaultSlots.forEach { repository.insertSlot(it) }
            }

            // Check and populate default tasbih counters if empty
            val counters = repository.getAllCounters().first()
            if (counters.isEmpty()) {
                val defaultCounters = listOf(
                    TasbihCounter(name = "سبحان الله", targetCount = 33),
                    TasbihCounter(name = "الحمد لله", targetCount = 33),
                    TasbihCounter(name = "الله أكبر", targetCount = 34),
                    TasbihCounter(name = "أستغفر الله", targetCount = 100),
                    TasbihCounter(name = "لا إله إلا الله", targetCount = 100),
                    TasbihCounter(name = "صلى الله على محمد", targetCount = 100)
                )
                defaultCounters.forEach { repository.insertCounter(it) }
            }

            // Populate some default tasks for today if none exist
            val todayDate = getTodayDateString()
            val todayTasks = repository.getTasksForDate(todayDate).first()
            if (todayTasks.isEmpty()) {
                val defaultTasks = listOf(
                    StudyTask(title = "مراجعة الباب الأول كيمياء", subject = "كيمياء", dateString = todayDate, timeString = "09:00", priority = "HIGH"),
                    StudyTask(title = "حل اختبار لغة عربية شامل", subject = "عربي", dateString = todayDate, timeString = "14:00", priority = "HIGH"),
                    StudyTask(title = "حفظ الكلمات الجديدة وحدة 5", subject = "إنجليزي", dateString = todayDate, timeString = "18:00", priority = "MEDIUM")
                )
                defaultTasks.forEach { repository.insertTask(it) }
            }

            // Populate encyclopedia if empty
            val dbVersesCount = repository.getAllVerses().first()
            if (dbVersesCount.isEmpty()) {
                val defaultVerses = ReligiousData.quranItems.map { q ->
                    DbVerse(
                        surahName = q.surah,
                        verseNumber = q.verse,
                        text = q.text,
                        tafsir = q.tafsir,
                        tags = q.category
                    )
                }
                repository.insertVerses(defaultVerses)
            }

            val dbHadithsCount = repository.getAllHadiths().first()
            if (dbHadithsCount.isEmpty()) {
                val defaultHadiths = ReligiousData.hadithItems.map { h ->
                    DbHadith(
                        text = h.text,
                        source = h.source,
                        grade = h.grade
                    )
                }
                repository.insertHadiths(defaultHadiths)
            }

            val dbDuasCount = repository.getAllDuas().first()
            if (dbDuasCount.isEmpty()) {
                val defaultDuas = (ReligiousData.azkarMorning + ReligiousData.azkarEvening + ReligiousData.azkarSleep + ReligiousData.studyDuas).map { d ->
                    DbDua(
                        text = d.text,
                        category = d.category,
                        source = d.source
                    )
                }
                repository.insertDuas(defaultDuas)
            }

            val dbFatawaCount = repository.getAllFatawa().first()
            if (dbFatawaCount.isEmpty()) {
                val defaultFatawa = ReligiousData.fatwaItems.map { f ->
                    DbFatwa(
                        question = f.question,
                        answer = f.answer,
                        scholar = f.scholar,
                        category = f.category
                    )
                }
                repository.insertFatawa(defaultFatawa)
            }

            val dbStoriesCount = repository.getAllStories().first()
            if (dbStoriesCount.isEmpty()) {
                val defaultStories = listOf(
                    DbStory(title = "قصة الشفاء باليقين والدعاء", content = "يروى أن رجلاً أصيب بمرض شديد عجز الأطباء عن علاجه، فلزم الاستغفار والرقية الشرعية بالفاتحة صباحاً ومساءً بيقين تام، حتى شفاه الله شفاءً تاماً كأن لم يكن به بأس.", source = "مواقف الصالحين"),
                    DbStory(title = "قصة البركة بالقرآن الكريم والمداومة على الورد", content = "طالب علم كان يشتكي من ضيق الوقت وصعوبة الفهم، فجعل لنفسه ورداً يومياً ثابتاً من القرآن يقرؤه بعد الفجر بتركيز وتدبر، ففتح الله عليه في دراسته وبارك في وقته وصار الأول على دفعته.", source = "تجارب الناجحين")
                )
                repository.insertStories(defaultStories)
            }

            val dbCategoriesCount = repository.getAllCategories().first()
            if (dbCategoriesCount.isEmpty()) {
                val defaultCategories = listOf(
                    DbCategory(name = "الرقية الشرعية"),
                    DbCategory(name = "أذكار الصباح والمساء"),
                    DbCategory(name = "أدعية العلم والنجاح"),
                    DbCategory(name = "قصص الشفاء والعبرة")
                )
                repository.insertCategories(defaultCategories)
            }
        }
    }
}

enum class Screen {
    Dashboard,
    SpiritualFortress,
    AcademicSuccess,
    CharismaAndRelations,
    IslamicLibrary,
    HelperTools
}

enum class PomodoroMode {
    STUDY,
    BREAK
}
