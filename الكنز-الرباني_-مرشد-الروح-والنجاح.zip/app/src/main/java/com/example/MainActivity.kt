package com.example

import android.content.Context
import android.os.Bundle
import android.os.Vibrator
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.*
import com.example.ui.AlKanzViewModel
import com.example.ui.PomodoroMode
import com.example.ui.Screen
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: AlKanzViewModel = viewModel()
            val userNightModeSetting by viewModel.isNightMode.collectAsStateWithLifecycle()
            val systemInDarkTheme = isSystemInDarkTheme()
            val darkTheme = when (userNightModeSetting) {
                true -> true
                false -> false
                null -> systemInDarkTheme
            }
            MyApplicationTheme(darkTheme = darkTheme) {
                AlKanzApp(viewModel)
            }
        }
    }
}

val LocalQuranFontScale = compositionLocalOf { 1.2f }

@Composable
fun IslamicBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF03140C), // DarkBackground
                        Color(0xFF0A2F1F), // IslamicDeepGreen
                        Color(0xFF020B06)  // Greenish Black
                    )
                )
            )
    ) {
        // Draw repeating Islamic geometric patterns behind
        Canvas(modifier = Modifier.fillMaxSize()) {
            val width = size.width
            val height = size.height
            val starSize = 120.dp.toPx()
            val spacing = starSize * 1.5f
            
            // Draw a grid of 8-pointed stars with a very low opacity golden/green line
            val strokeWidth = 1.dp.toPx()
            val patternColor = Color(0xFFFFD700).copy(alpha = 0.035f) // Golden watermark
            
            var y = 0f
            while (y < height + starSize) {
                var x = 0f
                while (x < width + starSize) {
                    val radius = starSize / 2f
                    
                    // Square 1
                    val path1 = androidx.compose.ui.graphics.Path().apply {
                        moveTo(x, y - radius)
                        lineTo(x + radius, y)
                        lineTo(x, y + radius)
                        lineTo(x - radius, y)
                        close()
                    }
                    drawPath(path = path1, color = patternColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth))
                    
                    // Square 2 (rotated 45 degrees)
                    val offsetRadius = radius * 0.7071f
                    val path2 = androidx.compose.ui.graphics.Path().apply {
                        moveTo(x - offsetRadius, y - offsetRadius)
                        lineTo(x + offsetRadius, y - offsetRadius)
                        lineTo(x + offsetRadius, y + offsetRadius)
                        lineTo(x - offsetRadius, y + offsetRadius)
                        close()
                    }
                    drawPath(path = path2, color = patternColor, style = androidx.compose.ui.graphics.drawscope.Stroke(width = strokeWidth))
                    
                    // Intersecting lines to form a grid
                    drawLine(
                        color = patternColor,
                        start = androidx.compose.ui.geometry.Offset(x - radius * 1.5f, y),
                        end = androidx.compose.ui.geometry.Offset(x + radius * 1.5f, y),
                        strokeWidth = strokeWidth * 0.5f
                    )
                    drawLine(
                        color = patternColor,
                        start = androidx.compose.ui.geometry.Offset(x, y - radius * 1.5f),
                        end = androidx.compose.ui.geometry.Offset(x, y + radius * 1.5f),
                        strokeWidth = strokeWidth * 0.5f
                    )
                    
                    x += spacing
                }
                y += spacing
            }
        }
        
        // Add a gentle vignette radial gradient on top
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0xFF020B06).copy(alpha = 0.85f)
                        )
                    )
                )
        )
        
        content()
    }
}

@Composable
fun KanzGlassCard(
    modifier: Modifier = Modifier,
    glow: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val borderColor = if (glow) {
        Color(0xFFFFD700).copy(alpha = 0.35f)
    } else {
        Color(0xFFFFD700).copy(alpha = 0.15f)
    }
    
    Box(
        modifier = modifier
            .background(
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.72f),
                shape = RoundedCornerShape(16.dp)
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        borderColor,
                        borderColor.copy(alpha = 0.05f)
                    )
                ),
                shape = RoundedCornerShape(16.dp)
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            content = content
        )
    }
}

@Composable
fun HolyText(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.onSurface,
    baseSize: androidx.compose.ui.unit.TextUnit = 18.sp,
    baseLineHeight: androidx.compose.ui.unit.TextUnit = 28.sp
) {
    val scale = LocalQuranFontScale.current
    Text(
        text = text,
        fontFamily = AmiriFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = (baseSize.value * scale).sp,
        lineHeight = (baseLineHeight.value * scale).sp,
        color = color,
        textAlign = TextAlign.Right,
        modifier = modifier.fillMaxWidth()
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlKanzApp(viewModel: AlKanzViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    val dailyLog by viewModel.dailyLog.collectAsStateWithLifecycle()
    val favorites by viewModel.allFavorites.collectAsStateWithLifecycle()
    val fontScale by viewModel.fontScale.collectAsStateWithLifecycle()
    
    var showSettingsSheet by remember { mutableStateOf(false) }
    
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "الْكَنْزُ الرَّبَّانِيُّ",
                        fontFamily = AmiriFontFamily,
                        fontWeight = FontWeight.Bold,
                        fontSize = 24.sp,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                },
                actions = {
                    IconButton(onClick = { showSettingsSheet = true }) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.Transparent,
                    titleContentColor = MaterialTheme.colorScheme.primary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f),
                tonalElevation = 8.dp
            ) {
                val items = listOf(
                    NavigationItem("الرئيسية", Screen.Dashboard, Icons.Default.Home, Icons.Default.Home),
                    NavigationItem("الحصن", Screen.SpiritualFortress, Icons.Default.Favorite, Icons.Default.Favorite),
                    NavigationItem("التفوق", Screen.AcademicSuccess, Icons.Default.Star, Icons.Default.Star),
                    NavigationItem("الهيبة", Screen.CharismaAndRelations, Icons.Default.Settings, Icons.Default.Settings),
                    NavigationItem("المكتبة", Screen.IslamicLibrary, Icons.Default.Search, Icons.Default.Search),
                    NavigationItem("الأدوات", Screen.HelperTools, Icons.Default.Build, Icons.Default.Build)
                )

                items.forEach { item ->
                    val selected = currentScreen == item.screen
                    NavigationBarItem(
                        selected = selected,
                        onClick = { viewModel.navigateTo(item.screen) },
                        label = { Text(item.title, fontSize = 11.sp, fontWeight = FontWeight.Bold) },
                        icon = {
                            Icon(
                                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                contentDescription = item.title,
                                tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }
        }
    ) { innerPadding ->
        CompositionLocalProvider(LocalQuranFontScale provides fontScale) {
            IslamicBackground {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    AnimatedContent(
                        targetState = currentScreen,
                        transitionSpec = {
                            fadeIn() togetherWith fadeOut()
                        },
                        label = "ScreenTransition"
                    ) { screen ->
                        when (screen) {
                            Screen.Dashboard -> DashboardScreen(viewModel, userProfile, dailyLog)
                            Screen.SpiritualFortress -> SpiritualFortressScreen(viewModel, favorites)
                            Screen.AcademicSuccess -> AcademicSuccessScreen(viewModel)
                            Screen.CharismaAndRelations -> CharismaAndRelationsScreen(viewModel)
                            Screen.IslamicLibrary -> IslamicLibraryScreen(viewModel, favorites)
                            Screen.HelperTools -> HelperToolsScreen(viewModel, favorites, vibrator)
                        }
                    }
                }
            }
            
            if (showSettingsSheet) {
                SettingsBottomSheet(viewModel = viewModel) {
                    showSettingsSheet = false
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsBottomSheet(
    viewModel: AlKanzViewModel,
    onDismiss: () -> Unit
) {
    val fontScale by viewModel.fontScale.collectAsStateWithLifecycle()
    val isNightMode by viewModel.isNightMode.collectAsStateWithLifecycle()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.onSurface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = "إعدادات القراءة والمظهر 🌟",
                style = MaterialTheme.typography.titleLarge,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.Bold
            )
            
            HorizontalDivider(color = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))

            // Font size controller
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.End
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "${(fontScale * 100).toInt()}%",
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "حجم خط النصوص والآيات 📖",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                Slider(
                    value = fontScale,
                    onValueChange = { viewModel.updateFontScale(it) },
                    valueRange = 0.8f..2.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = MaterialTheme.colorScheme.primary,
                        activeTrackColor = MaterialTheme.colorScheme.primary,
                        inactiveTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                    )
                )
                // Preview text using Amiri font
                Text(
                    text = "﴿رَبِّ زِدْنِي عِلْمًا﴾",
                    fontFamily = AmiriFontFamily,
                    fontSize = (22 * fontScale).sp,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .background(
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.05f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(8.dp)
                )
            }

            // Theme controller
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "وضعية المظهر (الليل والنهار) 🌓",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 8.dp)
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // System (Auto) button
                    Button(
                        onClick = { viewModel.setNightMode(null) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isNightMode == null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            contentColor = if (isNightMode == null) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("تلقائي ⚙️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    // Day button
                    Button(
                        onClick = { viewModel.setNightMode(false) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isNightMode == false) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            contentColor = if (isNightMode == false) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("نهاري ☀️", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    // Night button
                    Button(
                        onClick = { viewModel.setNightMode(true) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isNightMode == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                            contentColor = if (isNightMode == true) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary
                        ),
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("ليلي 🌙", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

data class NavigationItem(
    val title: String,
    val screen: Screen,
    val selectedIcon: androidx.compose.ui.graphics.vector.ImageVector,
    val unselectedIcon: androidx.compose.ui.graphics.vector.ImageVector
)

// ============================================================
// 1. DASHBOARD SCREEN
// ============================================================
@Composable
fun DashboardScreen(viewModel: AlKanzViewModel, userProfile: UserProfile, dailyLog: DailyLog) {
    var showIntentionDialog by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    
    // Choose a random reminder on start
    val randomReminder = remember {
        val allReminders = ReligiousData.quranItems.filter { it.category == "النصر والتمكين" } +
                           ReligiousData.sufiWisdom.filter { it.category == "حكم" }
        allReminders.shuffled().firstOrNull()
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App header
        item {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 8.dp)
            ) {
                Text(
                    text = "الْكَنْزُ الرَّبَّانِيُّ",
                    style = MaterialTheme.typography.headlineLarge,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Text(
                    text = "مرشد الروح والنجاح والتفوق الدراسي",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                    textAlign = TextAlign.Center
                )
            }
        }

        // Welcome card
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "أهلاً بك يا ${userProfile.name} 🌟",
                        style = MaterialTheme.typography.titleLarge.copy(textDirection = TextDirection.Rtl),
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "«السعي يكتمل بالجهد والتوكل. متبقي على حلمك ودراستك في ${userProfile.targetCollege} معدل مستهدف ${userProfile.targetPercentage}%»",
                        style = MaterialTheme.typography.bodyMedium.copy(textDirection = TextDirection.Rtl),
                        color = MaterialTheme.colorScheme.onSurface,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Countdown timer
                    val timeDiff = userProfile.examDateMillis - System.currentTimeMillis()
                    val daysLeft = if (timeDiff > 0) timeDiff / (1000 * 60 * 60 * 24) else 0L
                    
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.1f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Countdown",
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "متبقي على امتحانات الثانوية العامة: $daysLeft يوماً",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }

        // START DAY BUTTON
        item {
            Button(
                onClick = { showIntentionDialog = true },
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp)
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Start Day",
                    tint = MaterialTheme.colorScheme.onPrimary
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "بدء اليوم الجديد ونية العبادة",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onPrimary
                )
            }
        }

        // QUICK STATS
        item {
            Text(
                text = "إحصائيات اليوم الروحية والدراسية",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                textAlign = TextAlign.Right
            )
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .widthIn(max = 600.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Quran stats row
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.incrementQuranCount() }) {
                                Icon(Icons.Default.AddCircle, contentDescription = "Add", tint = MaterialTheme.colorScheme.primary)
                            }
                            Text(
                                text = "${dailyLog.quranReadCount} صفحات",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            IconButton(onClick = { viewModel.decrementQuranCount() }) {
                                Icon(Icons.Default.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                        Text(
                            text = "ورد القرآن اليومي 📖",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                // Azkar Completed Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (dailyLog.morningAzkarCompleted) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(12.dp)
                                .clickable { viewModel.toggleMorningAzkar() },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (dailyLog.morningAzkarCompleted) Icons.Default.Check else Icons.Default.Close,
                                contentDescription = "Morning",
                                tint = if (dailyLog.morningAzkarCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("أذكار الصباح 🌅", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }

                    Card(
                        modifier = Modifier.weight(1f),
                        colors = CardDefaults.cardColors(
                            containerColor = if (dailyLog.eveningAzkarCompleted) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .padding(12.dp)
                                .clickable { viewModel.toggleEveningAzkar() },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(
                                imageVector = if (dailyLog.eveningAzkarCompleted) Icons.Default.Check else Icons.Default.Close,
                                contentDescription = "Evening",
                                tint = if (dailyLog.eveningAzkarCompleted) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("أذكار المساء 🌆", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                // Focus level slider
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${dailyLog.focusLevel} / 10",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = "مستوى التركيز النفسي والذهني 🧠",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Slider(
                            value = dailyLog.focusLevel.toFloat(),
                            onValueChange = { viewModel.updateFocusLevel(it.toInt()) },
                            valueRange = 1f..10f,
                            steps = 8,
                            colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary)
                        )
                    }
                }
            }
        }

        // DAILY RANDOM REMINDER
        item {
            randomReminder?.let { reminder ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 600.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "💡 حكمة وتذكير اليوم",
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        
                        val text = when (reminder) {
                            is QuranItem -> reminder.text
                            is WisdomItem -> reminder.text
                            else -> ""
                        }
                        val reference = when (reminder) {
                            is QuranItem -> "سورة ${reminder.surah} [${reminder.verse}]"
                            is WisdomItem -> reminder.author
                            else -> ""
                        }

                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            lineHeight = 26.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = reference,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            IconButton(onClick = { viewModel.speakText(text) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Listen", tint = MaterialTheme.colorScheme.primary)
                            }
                            IconButton(onClick = { viewModel.stopSpeaking() }) {
                                Icon(Icons.Default.Close, contentDescription = "Stop", tint = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }
            }
        }
    }

    // Intention setting dialog
    if (showIntentionDialog) {
        AlertDialog(
            onDismissRequest = { showIntentionDialog = false },
            title = {
                Text(
                    text = "تحديد نية اليوم وبدء الأعمال الروحية 🤲",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text(
                        text = "حدّد نيتك لبدء يوم حافل بالبركة والتفوق الدراسي والعبادة:",
                        textAlign = TextAlign.Right,
                        style = MaterialTheme.typography.bodyMedium
                    )

                    val intentions = listOf(
                        "1. نية طلب العلم إعلاءً لدين الله ونفعاً للمسلمين.",
                        "2. نية تحصين النفس والبيت بالأذكار والرقية الشرعية.",
                        "3. نية التفوق وإدخال السرور على الوالدين.",
                        "4. نية الاستقامة وغض البصر وكمال الأدب والأخلاق."
                    )

                    intentions.forEach { intent ->
                        Text(
                            text = intent,
                            textAlign = TextAlign.Right,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.toggleIntentionSet()
                        showIntentionDialog = false
                        viewModel.speakText("تم تحديد النية والتوكل على الله. وفقك الله اليوم يا محمد حسام.")
                    }
                ) {
                    Text("توكلت على الله وبدأت يومي")
                }
            },
            dismissButton = {
                TextButton(onClick = { showIntentionDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

// ============================================================
// 2. SPIRITUAL FORTRESS SCREEN
// ============================================================
@Composable
fun SpiritualFortressScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: الحصن اليومي, 1: رقية, 2: مجربات وأوراد, 3: فتاوى

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "الْحِصْنُ الرُّوحِيُّ الْيَوْمِيُّ",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Custom Sub-Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color.Transparent,
            edgePadding = 0.dp
        ) {
            val tabs = listOf("الحصن اليومي 🛡️", "الرقية الشرعية 📖", "كنوز الصوفية 🌿", "فتاوى وأحكام ⚖️")
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> DailyFortressSubScreen(viewModel, favorites)
                1 -> RuqyahSubScreen(viewModel, favorites)
                2 -> SufiSubScreen(viewModel, favorites)
                3 -> FatwasSubScreen(viewModel)
            }
        }
    }
}

@Composable
fun DailyFortressSubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>) {
    var selectedGroup by remember { mutableStateOf(0) } // 0: صباح, 1: مساء, 2: نوم
    val azkarList = when (selectedGroup) {
        0 -> ReligiousData.azkarMorning
        1 -> ReligiousData.azkarEvening
        else -> ReligiousData.azkarSleep
    }

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { selectedGroup = 0 },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedGroup == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    contentColor = if (selectedGroup == 0) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                )
            ) {
                Text("الصباح 🌅", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { selectedGroup = 1 },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedGroup == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    contentColor = if (selectedGroup == 1) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                )
            ) {
                Text("المساء 🌆", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { selectedGroup = 2 },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (selectedGroup == 2) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                    contentColor = if (selectedGroup == 2) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                )
            ) {
                Text("النوم 🌙", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(azkarList) { azkar ->
                var countLeft by remember(azkar.text, selectedGroup) {
                    val count = if (azkar.source.contains("3 مرات")) 3 else if (azkar.source.contains("100")) 100 else 1
                    mutableStateOf(count)
                }

                KanzGlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        HolyText(
                            text = azkar.text,
                            color = MaterialTheme.colorScheme.onSurface,
                            baseSize = 18.sp,
                            baseLineHeight = 28.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Audio and favorite actions
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                val isFav = favorites.any { it.text == azkar.text }
                                IconButton(onClick = { viewModel.toggleFavorite(azkar.text, "أذكار") }) {
                                    Icon(
                                        imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.Star,
                                        contentDescription = "Favorite",
                                        tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                    )
                                }
                                IconButton(onClick = { viewModel.speakText(azkar.text) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                                }
                            }
                            
                            // Replay counter button
                            Button(
                                onClick = { if (countLeft > 0) countLeft-- },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (countLeft == 0) MaterialTheme.colorScheme.secondary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Text(
                                    text = if (countLeft == 0) "تمت القراءة ✓" else "التكرار: $countLeft",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (countLeft == 0) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f) else MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun RuqyahSubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>) {
    var selectedCategory by remember { mutableStateOf("إبطال السحر") }
    val categories = listOf("إبطال السحر", "حرق الجن والقرين", "آيات الشفاء", "الحسد والعين", "العزة والهيبة والقبول")

    Column(modifier = Modifier.fillMaxSize()) {
        ScrollableTabRow(
            selectedTabIndex = categories.indexOf(selectedCategory),
            containerColor = Color.Transparent,
            edgePadding = 0.dp
        ) {
            categories.forEach { cat ->
                Tab(
                    selected = selectedCategory == cat,
                    onClick = { selectedCategory = cat },
                    text = { Text(cat, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val items = ReligiousData.quranItems.filter { it.category == selectedCategory }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                KanzGlassCard(
                    modifier = Modifier.fillMaxWidth(),
                    glow = true
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        HolyText(
                            text = item.text,
                            color = MaterialTheme.colorScheme.primary,
                            baseSize = 22.sp,
                            baseLineHeight = 34.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "سورة ${item.surah} - آية [${item.verse}]",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Left,
                            fontFamily = TajawalFontFamily
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "تفسير ابن كثير: ${item.tafsir}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth(),
                            fontFamily = TajawalFontFamily
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val isFav = favorites.any { it.text == item.text }
                            IconButton(onClick = { viewModel.toggleFavorite(item.text, "رقية") }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                IconButton(onClick = { viewModel.speakText(item.text) }) {
                                    Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                                }
                                IconButton(onClick = { viewModel.stopSpeaking() }) {
                                    Icon(Icons.Default.Close, contentDescription = "Stop", tint = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SufiSubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>) {
    var selectedCategory by remember { mutableStateOf("حكم") }
    val categories = listOf("حكم", "مقامات", "أوراد", "مجربات")

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            categories.forEach { cat ->
                Button(
                    onClick = { selectedCategory = cat },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedCategory == cat) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                        contentColor = if (selectedCategory == cat) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
                    )
                ) {
                    Text(cat, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        val items = ReligiousData.sufiWisdom.filter { it.category == selectedCategory }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                KanzGlassCard(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        HolyText(
                            text = item.text,
                            color = MaterialTheme.colorScheme.onSurface,
                            baseSize = 18.sp,
                            baseLineHeight = 28.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "المصدر: ${item.author}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Left,
                            fontFamily = TajawalFontFamily
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val isFav = favorites.any { it.text == item.text }
                            IconButton(onClick = { viewModel.toggleFavorite(item.text, "حكم") }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            IconButton(onClick = { viewModel.speakText(item.text) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FatwasSubScreen(viewModel: AlKanzViewModel) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(ReligiousData.fatwaItems) { fatwa ->
            KanzGlassCard(
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "❓ السؤال: ${fatwa.question}",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth(),
                        fontFamily = TajawalFontFamily
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "✍️ الجواب: ${fatwa.answer}",
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 20.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth(),
                        fontFamily = TajawalFontFamily
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "📌 المفتي: ${fatwa.scholar}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Left,
                        fontFamily = TajawalFontFamily
                    )
                }
            }
        }
    }
}

// ============================================================
// 3. ACADEMIC SUCCESS SCREEN (تنظيم الوقت والمذاكرة)
// ============================================================
@Composable
fun AcademicSuccessScreen(viewModel: AlKanzViewModel) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: المقاتل اليومي, 1: جدول المذاكرة, 2: بومودورو وجلسات العمل, 3: التقارير والإنجازات, 4: أدعية ونصائح

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "مُقَاتِلُ النَّجَاحِ الدِّرَاسِيِّ",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color.Transparent,
            edgePadding = 0.dp
        ) {
            val tabs = listOf(
                "المقاتل اليومي ⚔️",
                "الجدول الأسبوعي 📅",
                "بومودورو والمذاكرة ⏱️",
                "التقارير والإنجازات 🏆",
                "أدعية ونصائح 💡"
            )
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> DailyTasksSubScreen(viewModel)
                1 -> WeeklyTimetableSubScreen(viewModel)
                2 -> PomodoroAndSessionsSubScreen(viewModel)
                3 -> ReportsAndAchievementsSubScreen(viewModel)
                4 -> DuasAndTipsSubScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun DailyTasksSubScreen(viewModel: AlKanzViewModel) {
    val selectedDate by viewModel.selectedDate.collectAsStateWithLifecycle()
    val tasks by viewModel.tasksForSelectedDate.collectAsStateWithLifecycle()
    
    var showAddTaskDialog by remember { mutableStateOf(false) }
    var newTaskTitle by remember { mutableStateOf("") }
    var newTaskSubject by remember { mutableStateOf("كيمياء") }
    var newTaskTime by remember { mutableStateOf("10:00") }
    var newTaskPriority by remember { mutableStateOf("HIGH") } // HIGH, MEDIUM, LOW

    var enableReminders by remember { mutableStateOf(true) }

    val daysList = remember {
        val list = mutableListOf<String>()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -3)
        for (i in 0..6) {
            list.add(sdf.format(cal.time))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        list
    }

    val subjects = listOf("عربي", "إنجليزي", "كيمياء", "فيزياء", "أحياء", "جيولوجيا", "أخرى")

    // Recommend the most urgent task
    val urgentTask = tasks.firstOrNull { !it.isCompleted && it.priority == "HIGH" }
        ?: tasks.firstOrNull { !it.isCompleted }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // --- 1. Horizontal Calendar View ---
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "تقويم المهام اليومية",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.fillMaxWidth(),
                    textAlign = TextAlign.Right
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    daysList.forEach { dateStr ->
                        val isSelected = dateStr == selectedDate
                        val dayNum = dateStr.substring(8, 10)
                        
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .padding(2.dp)
                                .background(
                                    color = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .border(
                                    width = 1.dp,
                                    color = if (isSelected) Color(0xFFFFD700) else Color.Transparent,
                                    shape = RoundedCornerShape(12.dp)
                                )
                                .clickable { viewModel.selectDate(dateStr) }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = dayNum,
                                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                // Little gold dot indicator for task
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .background(
                                            color = if (isSelected) Color(0xFFFFD700) else MaterialTheme.colorScheme.primary.copy(alpha = 0.7f),
                                            shape = CircleShape
                                        )
                                )
                            }
                        }
                    }
                }
            }
        }

        // --- 2. Most Urgent Task Suggestion ---
        if (urgentTask != null) {
            item {
                KanzGlassCard(glow = true) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.toggleTaskCompletion(urgentTask) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFD700)),
                            modifier = Modifier.testTag("quick_complete_urgent")
                        ) {
                            Text("تم الإنجاز ⚡", color = Color(0x0A2F1F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(end = 8.dp)) {
                            Text(
                                text = "⚡ اقتراح المهمة الأكثر إلحاحاً",
                                style = MaterialTheme.typography.titleSmall,
                                color = Color(0xFFFFD700),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${urgentTask.title} (${urgentTask.subject})",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Right
                            )
                            Text(
                                text = "الموعد المقدر: ${urgentTask.timeString} | الأولوية: عاجل جداً 🔥",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f)
                            )
                        }
                    }
                }
            }
        }

        // --- 3. Header and Reminder Toggle ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("منبه الحصن", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary)
                    Switch(
                        checked = enableReminders,
                        onCheckedChange = { enableReminders = it },
                        modifier = Modifier.scale(0.8f).testTag("alarm_switch")
                    )
                }
                
                Button(
                    onClick = { showAddTaskDialog = true },
                    modifier = Modifier.testTag("add_task_btn")
                ) {
                    Text("+ إضافة مهمة", fontWeight = FontWeight.Bold)
                }
            }
        }

        // --- 4. Reminder Success Status ---
        if (enableReminders) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(Color(0x1F4CAF50), RoundedCornerShape(8.dp))
                        .border(1.dp, Color(0xFF4CAF50).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                        .padding(12.dp)
                ) {
                    Text(
                        text = "🔔 تم تفعيل تذكيرات المذاكرة ومواعيد المهام بنجاح! سيقوم التطبيق بتنبيهك بمجرد حلول موعد الدرس.",
                        color = Color(0xFF81C784),
                        style = MaterialTheme.typography.bodySmall,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // --- 5. Tasks List ---
        if (tasks.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("لا توجد مهام مقررة لهذا اليوم. أضف مهمة للبدء!", style = MaterialTheme.typography.bodyMedium, color = Color.Gray)
                }
            }
        } else {
            items(tasks) { task ->
                KanzGlassCard(glow = task.priority == "HIGH" && !task.isCompleted) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.deleteTask(task) },
                            modifier = Modifier.testTag("delete_task_${task.id}")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red.copy(alpha = 0.7f))
                        }

                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .background(
                                            color = when (task.priority) {
                                                "HIGH" -> Color.Red.copy(alpha = 0.2f)
                                                "MEDIUM" -> Color(0xFFFFD700).copy(alpha = 0.2f)
                                                else -> Color.Gray.copy(alpha = 0.2f)
                                            },
                                            shape = RoundedCornerShape(4.dp)
                                        )
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = when (task.priority) {
                                            "HIGH" -> "عالية"
                                            "MEDIUM" -> "متوسطة"
                                            else -> "منخفضة"
                                        },
                                        color = when (task.priority) {
                                            "HIGH" -> Color.Red
                                            "MEDIUM" -> Color(0xFFFFD700)
                                            else -> Color.LightGray
                                        },
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = task.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else null,
                                    color = if (task.isCompleted) Color.Gray else Color.White,
                                    textAlign = TextAlign.Right
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "المادة: ${task.subject} | الوقت: ${task.timeString}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                        }

                        Checkbox(
                            checked = task.isCompleted,
                            onCheckedChange = { viewModel.toggleTaskCompletion(task) },
                            modifier = Modifier.testTag("complete_checkbox_${task.id}")
                        )
                    }
                }
            }
        }
    }

    // Add Task Dialog
    if (showAddTaskDialog) {
        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("إضافة مهمة دراسية جديدة", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = newTaskTitle,
                        onValueChange = { newTaskTitle = it },
                        label = { Text("عنوان المهمة") },
                        modifier = Modifier.fillMaxWidth().testTag("dialog_task_title"),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = newTaskTime,
                        onValueChange = { newTaskTime = it },
                        label = { Text("الوقت (مثال: 14:30)") },
                        modifier = Modifier.fillMaxWidth().testTag("dialog_task_time"),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    Text("اختر المادة:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        subjects.forEach { s ->
                            FilterChip(
                                selected = newTaskSubject == s,
                                onClick = { newTaskSubject = s },
                                label = { Text(s) }
                            )
                        }
                    }

                    Text("الأولوية:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("HIGH" to "عالية 🔥", "MEDIUM" to "متوسطة ⚡", "LOW" to "منخفضة 💤").forEach { (key, name) ->
                            FilterChip(
                                selected = newTaskPriority == key,
                                onClick = { newTaskPriority = key },
                                label = { Text(name) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTaskTitle.isNotBlank()) {
                            viewModel.addTask(newTaskTitle, newTaskSubject, newTaskTime, newTaskPriority, "PENDING")
                            newTaskTitle = ""
                            showAddTaskDialog = false
                        }
                    },
                    modifier = Modifier.testTag("dialog_task_confirm")
                ) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun WeeklyTimetableSubScreen(viewModel: AlKanzViewModel) {
    val scheduleSlots by viewModel.allScheduleSlots.collectAsStateWithLifecycle()
    var showAddSlotDialog by remember { mutableStateOf(false) }
    
    var selectedDay by remember { mutableStateOf("السبت") }
    var selectedTime by remember { mutableStateOf("صباحاً") }
    var selectedSubject by remember { mutableStateOf("عربي") }

    val days = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
    val subjects = listOf("عربي", "إنجليزي", "كيمياء", "فيزياء", "أحياء", "جيولوجيا", "أخرى")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { showAddSlotDialog = true },
                    modifier = Modifier.testTag("add_schedule_slot_btn")
                ) {
                    Text("تعديل الجدول +", fontWeight = FontWeight.Bold)
                }
                Text("جدول الحصص والمواد الأسبوعي", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        item {
            KanzGlassCard {
                Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                            .padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("مساءً 🌙", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Text("صباحاً ☀️", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                        Text("اليوم 📅", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), textAlign = TextAlign.Center)
                    }

                    days.forEach { day ->
                        val morningSubject = scheduleSlots.firstOrNull { it.dayOfWeek == day && it.timeSlot == "صباحاً" }?.subject ?: "فارغ"
                        val eveningSubject = scheduleSlots.firstOrOfWeek == day && it.timeSlot == "مساءً" }?.subject ?: "فارغ"
                        val eveningSubjectResolved = scheduleSlots.firstOrNull { it.dayOfWeek == day && it.timeSlot == "مساءً" }?.subject ?: "فارغ"

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, Color(0xFFFFD700).copy(alpha = 0.1f), RoundedCornerShape(8.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = eveningSubjectResolved,
                                color = if (eveningSubjectResolved == "فارغ") Color.Gray else Color(0xFFFFD700),
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                fontWeight = if (eveningSubjectResolved == "فارغ") FontWeight.Normal else FontWeight.Bold
                            )
                            Text(
                                text = morningSubject,
                                color = if (morningSubject == "فارغ") Color.Gray else Color(0xFFFFD700),
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center,
                                fontWeight = if (morningSubject == "فارغ") FontWeight.Normal else FontWeight.Bold
                            )
                            Text(
                                text = day,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddSlotDialog) {
        AlertDialog(
            onDismissRequest = { showAddSlotDialog = false },
            title = { Text("تعديل الحصة الدراسية", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("اليوم:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        days.forEach { d ->
                            FilterChip(
                                selected = selectedDay == d,
                                onClick = { selectedDay = d },
                                label = { Text(d) }
                            )
                        }
                    }

                    Text("الفترة الزمنية:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("صباحاً", "مساءً").forEach { t ->
                            FilterChip(
                                selected = selectedTime == t,
                                onClick = { selectedTime = t },
                                label = { Text(t) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    Text("المادة الدراسية:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        subjects.forEach { s ->
                            FilterChip(
                                selected = selectedSubject == s,
                                onClick = { selectedSubject = s },
                                label = { Text(s) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addScheduleSlot(selectedDay, selectedTime, selectedSubject)
                        showAddSlotDialog = false
                    }
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSlotDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ObsoleteStudyScheduleSubScreen(viewModel: AlKanzViewModel) {
    val scheduleSlots by viewModel.allScheduleSlots.collectAsStateWithLifecycle()
    val tasks by viewModel.tasksForSelectedDate.collectAsStateWithLifecycle()
    var showAddSlotDialog by remember { mutableStateOf(false) }
    var showAddTaskDialog by remember { mutableStateOf(false) }
    
    var selectedDay by remember { mutableStateOf("السبت") }
    var selectedTime by remember { mutableStateOf("صباحاً") }
    var selectedSubject by remember { mutableStateOf("عربي") }
    
    var newTaskTitle by remember { mutableStateOf("") }
    var newTaskSubject by remember { mutableStateOf("عربي") }

    val days = listOf("السبت", "الأحد", "الاثنين", "الثلاثاء", "الأربعاء", "الخميس", "الجمعة")
    val subjects = listOf("عربي", "إنجليزي", "كيمياء", "فيزياء", "أحياء", "جيولوجيا", "أخرى")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // --- 1. Weekly Schedule Grid ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { showAddSlotDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("تعديل الفترة +", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("الخطة الدراسية الأسبوعية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Display Days Table
                    days.forEach { day ->
                        val morningSlot = scheduleSlots.find { it.dayOfWeek == day && it.timeSlot == "صباحاً" }
                        val eveningSlot = scheduleSlots.find { it.dayOfWeek == day && it.timeSlot == "مساءً" }
                        
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Evening slot
                            Text(
                                text = "مساءً: ${eveningSlot?.subject ?: "استراحة 🍃"}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (eveningSlot != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Left
                            )

                            // Morning slot
                            Text(
                                text = "صباحاً: ${morningSlot?.subject ?: "استراحة 🍃"}",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                color = if (morningSlot != null) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                                modifier = Modifier.weight(1f),
                                textAlign = TextAlign.Center
                            )

                            // Day name
                            Text(
                                text = day,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.width(60.dp),
                                textAlign = TextAlign.Right
                            )
                        }
                        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
                    }
                }
            }
        }

        // --- 2. Tasks Management ---
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { showAddTaskDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("إضافة مهمة +", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("المهام الدراسية المعلقة لليوم", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (tasks.isEmpty()) {
                        Text(
                            text = "لا توجد مهام معلقة اليوم! أحسنت العمل 🎉",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    } else {
                        tasks.forEach { task ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = task.isCompleted,
                                        onCheckedChange = { viewModel.toggleTaskCompletion(task) }
                                    )
                                    Text(
                                        text = task.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        textDecoration = if (task.isCompleted) androidx.compose.ui.text.style.TextDecoration.LineThrough else null,
                                        color = if (task.isCompleted) MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f) else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = task.subject,
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier
                                            .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f), RoundedCornerShape(4.dp))
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                    IconButton(onClick = { viewModel.deleteTask(task) }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(20.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Schedule Slot Dialog
    if (showAddSlotDialog) {
        AlertDialog(
            onDismissRequest = { showAddSlotDialog = false },
            title = { Text("إضافة/تعديل فترة دراسية أسبوعية", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("اختر اليوم:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        days.forEach { d ->
                            FilterChip(
                                selected = selectedDay == d,
                                onClick = { selectedDay = d },
                                label = { Text(d) }
                            )
                        }
                    }

                    Text("اختر الوقت:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("صباحاً", "مساءً").forEach { t ->
                            FilterChip(
                                selected = selectedTime == t,
                                onClick = { selectedTime = t },
                                label = { Text(t) }
                            )
                        }
                    }

                    Text("اختر المادة:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        subjects.forEach { s ->
                            FilterChip(
                                selected = selectedSubject == s,
                                onClick = { selectedSubject = s },
                                label = { Text(s) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.addScheduleSlot(selectedDay, selectedTime, selectedSubject)
                        showAddSlotDialog = false
                    }
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddSlotDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add Task Dialog
    if (showAddTaskDialog) {
        AlertDialog(
            onDismissRequest = { showAddTaskDialog = false },
            title = { Text("إضافة مهمة دراسية جديدة", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = newTaskTitle,
                        onValueChange = { newTaskTitle = it },
                        label = { Text("عنوان المهمة") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    Text("اختر المادة:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        subjects.forEach { s ->
                            FilterChip(
                                selected = newTaskSubject == s,
                                onClick = { newTaskSubject = s },
                                label = { Text(s) }
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newTaskTitle.isNotBlank()) {
                            viewModel.addTask(newTaskTitle, newTaskSubject)
                            newTaskTitle = ""
                            showAddTaskDialog = false
                        }
                    }
                ) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTaskDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun PomodoroAndSessionsSubScreen(viewModel: AlKanzViewModel) {
    val pomodoroSecondsLeft by viewModel.pomodoroSecondsLeft.collectAsStateWithLifecycle()
    val pomodoroIsActive by viewModel.pomodoroIsActive.collectAsStateWithLifecycle()
    val pomodoroMode by viewModel.pomodoroMode.collectAsStateWithLifecycle()

    val sessions by viewModel.sessionsForSelectedDate.collectAsStateWithLifecycle()

    var showLogSessionDialog by remember { mutableStateOf(false) }
    var sessionSubject by remember { mutableStateOf("كيمياء") }
    var sessionPages by remember { mutableStateOf("10") }
    var sessionNotes by remember { mutableStateOf("") }
    var sessionStartTime by remember { mutableStateOf("09:00") }
    var sessionEndTime by remember { mutableStateOf("10:00") }

    val minutes = pomodoroSecondsLeft / 60
    val seconds = pomodoroSecondsLeft % 60
    val progress = pomodoroSecondsLeft.toFloat() / (if (pomodoroMode == PomodoroMode.STUDY) 25 * 60 else 5 * 60)

    val subjects = listOf("عربي", "إنجليزي", "كيمياء", "فيزياء", "أحياء", "جيولوجيا", "أخرى")

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // --- 1. Pomodoro Visual Timer ---
        item {
            KanzGlassCard(glow = pomodoroIsActive) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (pomodoroMode == PomodoroMode.STUDY) "⏱️ فترة المذاكرة والتركيز" else "💤 فترة الراحة والاسترخاء",
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700)
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(
                            progress = { progress },
                            modifier = Modifier.size(160.dp),
                            color = Color(0xFFFFD700),
                            strokeWidth = 8.dp,
                            trackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f),
                        )
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = String.format(Locale.US, "%02d:%02d", minutes, seconds),
                                style = MaterialTheme.typography.headlineLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.resetPomodoro() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color.Gray)
                        ) {
                            Text("إعادة تعيين", fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = { viewModel.togglePomodoro() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (pomodoroIsActive) Color.Red.copy(alpha = 0.8f) else MaterialTheme.colorScheme.primary
                            ),
                            modifier = Modifier.testTag("pomodoro_toggle")
                        ) {
                            Text(if (pomodoroIsActive) "إيقاف مؤقت" else "ابدأ الآن", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- 2. Spiritual Transition Duas ---
        item {
            KanzGlassCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "🤲 الورد الروحي أثناء المذاكرة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "قبل المذاكرة: \"اللهم إني أسألك فهم النبيين، وحفظ المرسلين، والملائكة المقربين. اللهم اجعل ألسنتنا عامرة بذكرك، وقلوبنا بخشيتك.\"",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Right,
                        lineHeight = 22.sp,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Divider(color = Color(0xFFFFD700).copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "بعد المذاكرة: \"اللهم إني أستودعك ما قرأت وما حفظت وما تعلمت، فرده عند حاجتي إليه، إنك على كل شيء قدير.\"",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Right,
                        lineHeight = 22.sp,
                        color = Color.White
                    )
                }
            }
        }

        // --- 3. Log Real Study Session ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { showLogSessionDialog = true },
                    modifier = Modifier.testTag("log_session_btn")
                ) {
                    Text("+ تسجيل جلسة مذاكرة", fontWeight = FontWeight.Bold)
                }
                Text("سجل جلسات المذاكرة الفعلية", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        if (sessions.isEmpty()) {
            item {
                Text("لا توجد جلسات مذاكرة مسجلة اليوم. ابدأ وسجل تقدمك!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        } else {
            items(sessions) { session ->
                KanzGlassCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { viewModel.deleteStudySession(session) },
                            modifier = Modifier.testTag("delete_session_${session.id}")
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red.copy(alpha = 0.7f))
                        }

                        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                            Text(
                                text = "جلسة مذاكرة: ${session.subject}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD700)
                            )
                            Text(
                                text = "الوقت: من ${session.startTime} إلى ${session.endTime}",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.7f)
                            )
                            if (session.pagesCount > 0) {
                                Text(
                                    text = "عدد الصفحات المنجزة: ${session.pagesCount} صفحة 📖",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White
                                )
                            }
                            if (session.notes.isNotBlank()) {
                                Text(
                                    text = "ملاحظات: ${session.notes}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLogSessionDialog) {
        AlertDialog(
            onDismissRequest = { showLogSessionDialog = false },
            title = { Text("تسجيل جلسة مذاكرة جديدة", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("المادة الدراسية:", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        subjects.forEach { s ->
                            FilterChip(
                                selected = sessionSubject == s,
                                onClick = { sessionSubject = s },
                                label = { Text(s) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = sessionStartTime,
                        onValueChange = { sessionStartTime = it },
                        label = { Text("وقت البدء (مثال: 14:00)") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = sessionEndTime,
                        onValueChange = { sessionEndTime = it },
                        label = { Text("وقت الانتهاء (مثال: 15:30)") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = sessionPages,
                        onValueChange = { sessionPages = it },
                        label = { Text("عدد الصفحات المدروسة") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = sessionNotes,
                        onValueChange = { sessionNotes = it },
                        label = { Text("ملاحظات إضافية") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val pages = sessionPages.toIntOrNull() ?: 0
                        viewModel.addStudySession(sessionStartTime, sessionEndTime, sessionSubject, pages, sessionNotes)
                        sessionNotes = ""
                        showLogSessionDialog = false
                    },
                    modifier = Modifier.testTag("confirm_log_session")
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showLogSessionDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ReportsAndAchievementsSubScreen(viewModel: AlKanzViewModel) {
    val tasks by viewModel.tasksForSelectedDate.collectAsStateWithLifecycle()
    val sessions by viewModel.allSessions.collectAsStateWithLifecycle()
    val goals by viewModel.allGoals.collectAsStateWithLifecycle()

    var showAddGoalDialog by remember { mutableStateOf(false) }
    var goalTitle by remember { mutableStateOf("") }
    var goalDesc by remember { mutableStateOf("") }
    var goalTargetDate by remember { mutableStateOf("2026-07-01") }

    // Rewards Calculation
    val completedTasksCount = tasks.count { it.isCompleted }
    val starsCount = completedTasksCount * 10 + sessions.size * 15

    // Study Hours Calculation
    var totalMinutes = 0
    sessions.forEach { s ->
        try {
            val startParts = s.startTime.split(":")
            val endParts = s.endTime.split(":")
            if (startParts.size == 2 && endParts.size == 2) {
                val startMin = startParts[0].toInt() * 60 + startParts[1].toInt()
                val endMin = endParts[0].toInt() * 60 + endParts[1].toInt()
                if (endMin > startMin) {
                    totalMinutes += (endMin - startMin)
                }
            }
        } catch (e: Exception) {
            totalMinutes += 45 // Fallback estimate
        }
    }
    val totalHours = totalMinutes / 60.0

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(16.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // --- 1. Star Rewards Card ---
        item {
            KanzGlassCard(glow = true) {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "🏆 وسام الفارس الدراسي",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700),
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "لقد حصلت اليوم على:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "$starsCount",
                            style = MaterialTheme.typography.displayMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD700)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "نجمة ذهبية 🌟",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD700)
                        )
                    }
                    Text(
                        text = "تمنح النجوم عند إنجاز المهام اليومية (+10 لكلمهمة) والانتهاء من جلسات المذاكرة المثمرة (+15 لكل جلسة). واصل القتال!",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.8f),
                        textAlign = TextAlign.Center
                    )
                }
            }
        }

        // --- 2. Study Report and Analytics ---
        item {
            KanzGlassCard {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "📊 تقرير الأداء والمذاكرة الفعلي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFD700),
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("الساعات الفعلية", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                            Text(String.format(Locale.US, "%.1f ساعة", totalHours), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("الجلسات المثمرة", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                            Text("${sessions.size} جلسات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.weight(1f)) {
                            Text("الصفحات المدروسة", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                            Text("${sessions.sumOf { it.pagesCount }} صفحة", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "المقارنة بالهدف اليومي (المقترح: 6 ساعات مذاكرة):",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.LightGray,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.Right
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        progress = { (totalHours / 6.0).toFloat().coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = Color(0xFFFFD700),
                        trackColor = Color.White.copy(alpha = 0.2f)
                    )
                }
            }
        }

        // --- 3. Goals Manager ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Button(
                    onClick = { showAddGoalDialog = true },
                    modifier = Modifier.testTag("add_goal_btn")
                ) {
                    Text("+ إضافة هدف", fontWeight = FontWeight.Bold)
                }
                Text("الأهداف الدراسية بعيدة المدى", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
            }
        }

        if (goals.isEmpty()) {
            item {
                Text("لا توجد أهداف حالية. أضف هدفاً دراسياً لتتبع تقدمك!", style = MaterialTheme.typography.bodySmall, color = Color.Gray)
            }
        } else {
            items(goals) { goal ->
                KanzGlassCard {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row {
                                IconButton(
                                    onClick = { viewModel.deleteStudyGoal(goal) },
                                    modifier = Modifier.testTag("delete_goal_${goal.id}")
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = Color.Red.copy(alpha = 0.6f))
                                }
                                IconButton(
                                    onClick = { 
                                        val nextProgress = (goal.progressPercentage + 10).coerceAtMost(100)
                                        viewModel.updateStudyGoal(goal.copy(progressPercentage = nextProgress))
                                    },
                                    modifier = Modifier.testTag("increase_goal_${goal.id}")
                                ) {
                                    Icon(Icons.Default.KeyboardArrowUp, contentDescription = "زيادة التقدم", tint = Color(0xFFFFD700))
                                }
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = goal.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                                Text(
                                    text = "تاريخ الإنجاز المستهدف: ${goal.targetDateString}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = Color.LightGray
                                )
                            }
                        }

                        if (goal.description.isNotBlank()) {
                            Text(
                                text = goal.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = 0.8f),
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "${goal.progressPercentage}%", color = Color(0xFFFFD700), fontWeight = FontWeight.Bold)
                            LinearProgressIndicator(
                                progress = { goal.progressPercentage / 100f },
                                modifier = Modifier.weight(1f).padding(horizontal = 8.dp).height(6.dp),
                                color = Color(0xFFFFD700),
                                trackColor = Color.White.copy(alpha = 0.1f)
                            )
                        }
                    }
                }
            }
        }
    }

    if (showAddGoalDialog) {
        AlertDialog(
            onDismissRequest = { showAddGoalDialog = false },
            title = { Text("إضافة هدف دراسي جديد", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = goalTitle,
                        onValueChange = { goalTitle = it },
                        label = { Text("عنوان الهدف") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = goalDesc,
                        onValueChange = { goalDesc = it },
                        label = { Text("الوصف أو تفاصيل الخطة") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = goalTargetDate,
                        onValueChange = { goalTargetDate = it },
                        label = { Text("تاريخ الإنجاز (مثال: 2026-12-31)") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (goalTitle.isNotBlank()) {
                            viewModel.addStudyGoal(goalTitle, goalDesc, goalTargetDate, 0)
                            goalTitle = ""
                            goalDesc = ""
                            showAddGoalDialog = false
                        }
                    },
                    modifier = Modifier.testTag("confirm_goal")
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddGoalDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun DuasAndTipsSubScreen(viewModel: AlKanzViewModel) {
    var activeSubTab by remember { mutableStateOf(0) } // 0: أدعية, 1: نصائح

    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = { activeSubTab = 1 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == 1) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text("نصائح التفوق المنهجي", fontWeight = FontWeight.Bold)
            }
            Button(
                onClick = { activeSubTab = 0 },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (activeSubTab == 0) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.2f)
                ),
                modifier = Modifier.weight(1f)
            ) {
                Text("أدعية العلم والنجاح", fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            if (activeSubTab == 0) {
                StudyDuasSubScreen(viewModel)
            } else {
                CognitiveTipsSubScreen()
            }
        }
    }
}

@Composable
fun StudyDuasSubScreen(viewModel: AlKanzViewModel) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(ReligiousData.studyDuas) { dua ->
            KanzGlassCard {
                Column(modifier = Modifier.padding(8.dp)) {
                    Text(
                        text = dua.text,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 26.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المناسبة: ${dua.source}",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color(0xFFFFD700)
                        )
                        IconButton(onClick = { viewModel.speakText(dua.text) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "قراءة صوتية", tint = Color(0xFFFFD700))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CognitiveTipsSubScreen() {
    val tips = listOf(
        Pair("علاج النسيان وتثبيت المذاكرة 🧠", "لتجنب النسيان، اعتمد على 'التكرار المتباعد' بدلاً من الحفظ السريع ليلة الامتحان. استخدم خرائط المفاهيم الذهنية لتلخيص الدروس الطويلة في رسم واحد منسق بأسهم ملونة. قم بتلخيص الفقرات الصعبة بكلماتك الشخصية لتثبيتها في ذهنك بشكل أسرع."),
        Pair("مصفوفة أيزنهاور لتنظيم أولويات الدراسة 📊", "قسّم مهامك إلى أربع خانات:\n1. عاجل وهام: أنجزه فوراً (مثل امتحان الغد).\n2. غير عاجل وهام: خطط له للمستقبل وهو مربع التميز الحقيقي (مثل ورد المذاكرة المنتظم وبناء المهارات التقنية).\n3. عاجل وغير هام: فوضه أو قلل منه (مثل مكالمات المقاطعة).\n4. غير عاجل وغير هام: تصفح تيك توك وسوشيال ميديا (تجنبه لإنقاذ تركيزك)."),
        Pair("أهمية غض البصر علمياً وروحياً 👁️", "غض البصر يحمي ذهنك من التشوش والصور الزائدة التي ترهق خلايا التذكر وتملأ العقل الباطن بضوضاء مشوشة. روحياً، هو طاعة لأمر الله العظيم تجلب نوراً وإشراقاً وقوة حفظ خارقة للقلب.")
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(tips) { tip ->
            var expanded by remember { mutableStateOf(false) }

            KanzGlassCard {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { expanded = !expanded }
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Expand",
                            tint = Color(0xFFFFD700)
                        )
                        Text(
                            text = tip.first,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFFFD700),
                            textAlign = TextAlign.Right
                        )
                    }

                    if (expanded) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = tip.second,
                            style = MaterialTheme.typography.bodyMedium,
                            lineHeight = 22.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun ObsoletePomodoroSubScreen(viewModel: AlKanzViewModel) {
    val secondsLeft by viewModel.pomodoroSecondsLeft.collectAsStateWithLifecycle()
    val isActive by viewModel.pomodoroIsActive.collectAsStateWithLifecycle()
    val mode by viewModel.pomodoroMode.collectAsStateWithLifecycle()

    val minutes = secondsLeft / 60
    val seconds = secondsLeft % 60
    val timeString = String.format("%02d:%02d", minutes, seconds)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Mode Header
        Text(
            text = if (mode == PomodoroMode.STUDY) "جلسة المذاكرة المركزة ✍️" else "وقت الاستراحة 🍃",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = if (mode == PomodoroMode.STUDY) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.secondary
        )

        // Pre-study focused verse / prayer
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.05f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
        ) {
            Column(
                modifier = Modifier.padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "💡 آية ودعاء لتثبيت الحفظ وفتح الذهن قبل بدء الجلسة:",
                    style = MaterialTheme.typography.bodySmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "«رَبِّ اشْرَحْ لِي صَدْرِي * وَيَسِّرْ لِي أَمْرِي»",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Large Timer Display
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(200.dp)
                .background(
                    Brush.sweepGradient(
                        colors = listOf(
                            MaterialTheme.colorScheme.primary,
                            MaterialTheme.colorScheme.secondary,
                            MaterialTheme.colorScheme.primary
                        )
                    ),
                    shape = CircleShape
                )
                .padding(8.dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.surface, shape = CircleShape)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = timeString,
                        style = MaterialTheme.typography.headlineLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = if (mode == PomodoroMode.STUDY) "مذاكرة" else "استراحة",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Controls Row
        Row(
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { if (isActive) viewModel.pausePomodoro() else viewModel.startPomodoro() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isActive) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(
                    imageVector = if (isActive) Icons.Default.Close else Icons.Default.PlayArrow,
                    contentDescription = if (isActive) "Pause" else "Start"
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(if (isActive) "إيقاف مؤقت" else "ابدأ الجلسة")
            }

            OutlinedButton(onClick = { viewModel.resetPomodoro() }) {
                Icon(Icons.Default.Refresh, contentDescription = "Reset")
                Spacer(modifier = Modifier.width(8.dp))
                Text("إعادة تعيين")
            }
        }
    }
}

@Composable
fun StudyDuasSubScreen(viewModel: AlKanzViewModel) {
    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(ReligiousData.studyDuas) { dua ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = dua.text,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.Bold,
                        lineHeight = 24.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "الحالة: ${dua.source}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                        IconButton(onClick = { viewModel.speakText(dua.text) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CognitiveTipsSubScreen() {
    val tips = listOf(
        Pair("علاج النسيان وتثبيت المذاكرة 🧠", "لتجنب النسيان، اعتمد على 'التكرار المتباعد' بدلاً من الحفظ السريع ليلة الامتحان. استخدم خرائط المفاهيم الذهنية لتلخيص الدروس الطويلة في رسم واحد منسق بأسهم ملونة. قم بتلخيص الفقرات الصعبة بكلماتك الشخصية لتثبيتها في ذهنك بشكل أسرع."),
        Pair("مصفوفة أيزنهاور لتنظيم أولويات الدراسة 📊", "قسّم مهامك إلى أربع خانات:\n1. عاجل وهام: أنجزه فوراً (مثل امتحان الغد).\n2. غير عاجل وهام: خطط له للمستقبل وهو مربع التميز الحقيقي (مثل ورد المذاكرة المنتظم وبناء المهارات التقنية).\n3. عاجل وغير هام: فوضه أو قلل منه (مثل مكالمات المقاطعة).\n4. غير عاجل وغير هام: تصفح تيك توك وسوشيال ميديا (تجنبه لإنقاذ تركيزك)."),
        Pair("أهمية غض البصر علمياً وروحياً 👁️", "غض البصر يحمي ذهنك من التشوش والصور الزائدة التي ترهق خلايا التذكر وتملأ العقل الباطن بضوضاء مشوشة. روحياً، هو طاعة لأمر الله العظيم تجلب نوراً وإشراقاً وقوة حفظ خارقة للقلب.")
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(tips) { tip ->
            var expanded by remember { mutableStateOf(false) }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expanded = !expanded },
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = "Expand"
                        )
                        Text(
                            text = tip.first,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Right
                        )
                    }

                    if (expanded) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = tip.second,
                            style = MaterialTheme.typography.bodyMedium,
                            lineHeight = 22.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}

// ============================================================
// 4. CHARISMA AND RELATIONS SCREEN
// ============================================================
@Composable
fun CharismaAndRelationsScreen(viewModel: AlKanzViewModel) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: آيات العزة والقبول, 1: علم نفس العلاقات, 2: الشخصية الكاريزمية

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "الشَّخْصِيَّةُ وَالْهَيْبَةُ وَالْعَلَاقَاتُ",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Text(
            text = "السحر الاجتماعي المحمود من المنظور النفسي والإسلامي",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f),
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color.Transparent,
            edgePadding = 0.dp
        ) {
            val tabs = listOf("آيات الهيبة والقبول ✨", "علم نفس العلاقات 🤝", "الكاريزما الإسلامية 🛡️")
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> CharismaVersesSubScreen(viewModel)
                1 -> RelationsPsychologySubScreen()
                2 -> CharismaBuildSubScreen()
            }
        }
    }
}

@Composable
fun CharismaVersesSubScreen(viewModel: AlKanzViewModel) {
    val items = ReligiousData.quranItems.filter { it.category == "العزة والهيبة والقبول" }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(items) { item ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = item.text,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center,
                        lineHeight = 30.sp,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "تفسير: ${item.tafsir}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        IconButton(onClick = { viewModel.speakText(item.text) }) {
                            Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                        }
                        Text(
                            text = "سورة ${item.surah} [${item.verse}]",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun RelationsPsychologySubScreen() {
    val articles = ReligiousData.articles.filter { it.category == "الشخصية والهيبة" || it.category == "علم نفس العلاقات" }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(articles) { art ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = art.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = art.content,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

@Composable
fun CharismaBuildSubScreen() {
    val tips = listOf(
        Pair("القوة الداخلية والتوكل 💪", "كاريزما المسلم لا تقوم على التصنع أو رغبة إبهار الآخرين، بل تقوم على الافتقار والتوكل الكامل على رب السموات والأرض. عندما تؤمن أن الخلق كلهم لا يملكون لك ضراً ولا نفعاً إلا بإذن الله، تكتسب ثباتاً وهدوءاً عجيباً يهابك له الجميع."),
        Pair("الهدوء والثبات والسكينة 🕊️", "تجنب كثرة الكلام واللغو والهزار الزائد الذي يسقط من هيبتك ووقارك. الهدوء عند الغضب، وضبط النفس، واختيار الكلمات الصادقة والرزينة هم السحر الحقيقي لجذب قلوب الناس واحترامهم."),
        Pair("المراهقة والعواطف - ضبط النفس 🛡️", "في سن المراهقة والشباب، قد تكون الشهوات والعواطف قوية جداً ومشتتة. ضبط هذه العواطف عبر غض البصر، الصوم، الانشغال ببناء مستقبلك وصناعة النجاح في دراستك وأمنك السيبراني هو أعظم وقاية وصيانة لهيبتك واحترامك الذاتي.")
    )

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        items(tips) { tip ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = tip.first,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = tip.second,
                        style = MaterialTheme.typography.bodyMedium,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }
    }
}

// ============================================================
// 5. ISLAMIC LIBRARY SCREEN
// ============================================================
@Composable
fun IslamicLibraryScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: قرآن, 1: حديث, 2: أدب ومناجاة
    var searchQuery by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "الزَّادُ الْفِكْرِيُّ وَالثَّقَافِيُّ",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("ابحث في المكتبة...") },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 600.dp),
            shape = RoundedCornerShape(12.dp),
            textStyle = TextStyle(textAlign = TextAlign.Right)
        )

        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color.Transparent,
            edgePadding = 0.dp
        ) {
            val tabs = listOf("المصحف والتفسير 📖", "موسوعة الحديث 📚", "الخزانة الأدبية ✍️")
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> QuranLibrarySubScreen(viewModel, favorites, searchQuery)
                1 -> HadithLibrarySubScreen(viewModel, favorites, searchQuery)
                2 -> LiteraryLibrarySubScreen(viewModel, favorites, searchQuery)
            }
        }
    }
}

@Composable
fun QuranLibrarySubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>, query: String) {
    val items = ReligiousData.quranItems.filter {
        query.isEmpty() || it.text.contains(query) || it.surah.contains(query) || it.tafsir.contains(query)
    }

    if (items.isEmpty()) {
        Text("لم يتم العثور على نتائج في المصحف والتفسير.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = item.text,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary,
                            textAlign = TextAlign.Center,
                            lineHeight = 32.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "سورة ${item.surah} - آية [${item.verse}]",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Left
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "التفسير: ${item.tafsir}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f),
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val isFav = favorites.any { it.text == item.text }
                            IconButton(onClick = { viewModel.toggleFavorite(item.text, "قرآن") }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            IconButton(onClick = { viewModel.speakText(item.text) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun HadithLibrarySubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>, query: String) {
    val items = ReligiousData.hadithItems.filter {
        query.isEmpty() || it.text.contains(query) || it.source.contains(query) || it.category.contains(query)
    }

    if (items.isEmpty()) {
        Text("لم يتم العثور على نتائج في موسوعة الحديث.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = item.text,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Right,
                            lineHeight = 24.sp,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "المصدر: ${item.source} (${item.grade})",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Left
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val isFav = favorites.any { it.text == item.text }
                            IconButton(onClick = { viewModel.toggleFavorite(item.text, "حديث") }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            IconButton(onClick = { viewModel.speakText(item.text) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LiteraryLibrarySubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>, query: String) {
    val items = ReligiousData.sufiWisdom.filter {
        query.isEmpty() || it.text.contains(query) || it.author.contains(query)
    }

    if (items.isEmpty()) {
        Text("لم يتم العثور على نتائج في الخزانة الأدبية.", modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(items) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = item.text,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 24.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "الأديب/المؤلف: ${item.author}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Left
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val isFav = favorites.any { it.text == item.text }
                            IconButton(onClick = { viewModel.toggleFavorite(item.text, "أدب") }) {
                                Icon(
                                    imageVector = if (isFav) Icons.Default.Star else Icons.Outlined.Star,
                                    contentDescription = "Favorite",
                                    tint = if (isFav) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f)
                                )
                            }
                            IconButton(onClick = { viewModel.speakText(item.text) }) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Speak", tint = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// 6. HELPER TOOLS & SETTINGS SCREEN
// ============================================================
@Composable
fun HelperToolsScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>, vibrator: Vibrator?) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: مسبحة, 1: مفضلة, 2: إعدادات

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "الأَدَوَاتُ الْمُسَاعِدَةُ وَالْإِعْدَادَاتُ",
            style = MaterialTheme.typography.headlineSmall,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(12.dp))

        ScrollableTabRow(
            selectedTabIndex = selectedSubTab,
            containerColor = Color.Transparent,
            edgePadding = 0.dp
        ) {
            val tabs = listOf("المسبحة الإلكترونية 📿", "المفضلة ⭐", "الإعدادات ⚙️")
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedSubTab == index,
                    onClick = { selectedSubTab = index },
                    text = { Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Box(modifier = Modifier.weight(1f)) {
            when (selectedSubTab) {
                0 -> MisbahaSubScreen(viewModel, vibrator)
                1 -> FavoritesSubScreen(viewModel, favorites)
                2 -> SettingsSubScreen(viewModel)
            }
        }
    }
}

@Composable
fun MisbahaSubScreen(viewModel: AlKanzViewModel, vibrator: Vibrator?) {
    val counters by viewModel.allTasbihCounters.collectAsStateWithLifecycle()
    var selectedCounter by remember { mutableStateOf<TasbihCounter?>(null) }
    var showAddCounterDialog by remember { mutableStateOf(false) }
    
    var newCounterName by remember { mutableStateOf("") }
    var newCounterTarget by remember { mutableStateOf("33") }

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dropdown/Selector for active counter
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = { showAddCounterDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("تسبيح جديد +", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Text("اختر الذكر للتسبيح:", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }

        // Active Counter Display
        if (selectedCounter == null && counters.isNotEmpty()) {
            selectedCounter = counters.first()
        }

        val active = selectedCounter ?: counters.firstOrNull()

        if (active != null) {
            // Dropdown selection chip row
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(60.dp),
                verticalArrangement = Arrangement.Center
            ) {
                item {
                    Row(
                        modifier = Modifier.horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        counters.forEach { c ->
                            FilterChip(
                                selected = active.id == c.id,
                                onClick = { selectedCounter = c },
                                label = { Text(c.name) }
                            )
                        }
                    }
                }
            }

            // Misbaha Interactive Click Area
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(1f)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
                    .clickable {
                        vibrator?.vibrate(50) // Vibrate 50ms on tap
                        viewModel.incrementTasbih(active)
                        // Refresh state
                        selectedCounter = counters.find { it.id == active.id }
                    }
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = active.name,
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Text(
                        text = "${active.count}",
                        style = MaterialTheme.typography.displayLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "الهدف: ${active.targetCount}",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            // Reset Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(
                    onClick = {
                        viewModel.resetTasbih(active)
                        selectedCounter = counters.find { it.id == active.id }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Reset")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("إعادة تصفير")
                }

                Button(
                    onClick = {
                        viewModel.deleteTasbih(active)
                        selectedCounter = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete")
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حذف")
                }
            }
        } else {
            Text("لا توجد مسبحة مضافة. أضف واحدة جديدة للبدء.", style = MaterialTheme.typography.bodyMedium)
        }
    }

    // Add Counter Dialog
    if (showAddCounterDialog) {
        AlertDialog(
            onDismissRequest = { showAddCounterDialog = false },
            title = { Text("إضافة ذكر جديد للمسبحة", textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth()) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedTextField(
                        value = newCounterName,
                        onValueChange = { newCounterName = it },
                        label = { Text("صيغة الذكر") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )

                    OutlinedTextField(
                        value = newCounterTarget,
                        onValueChange = { newCounterTarget = it },
                        label = { Text("العدد المستهدف (مثال: 33، 100)") },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(textAlign = TextAlign.Right)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val target = newCounterTarget.toIntOrNull() ?: 33
                        if (newCounterName.isNotBlank()) {
                            viewModel.addTasbihCounter(newCounterName, target)
                            newCounterName = ""
                            newCounterTarget = "33"
                            showAddCounterDialog = false
                        }
                    }
                ) {
                    Text("إضافة")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddCounterDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
fun FavoritesSubScreen(viewModel: AlKanzViewModel, favorites: List<FavoriteItem>) {
    if (favorites.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("لم تقم بإضافة أي نصوص للمفضلة بعد. يمكنك حفظها بالنقر على النجمة ⭐", textAlign = TextAlign.Center)
        }
    } else {
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(favorites) { item ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = item.text,
                            style = MaterialTheme.typography.bodyLarge,
                            fontWeight = FontWeight.Bold,
                            lineHeight = 24.sp,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { viewModel.removeFavorite(item) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                            }
                            Text(
                                text = "القسم: ${item.category}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsSubScreen(viewModel: AlKanzViewModel) {
    val userProfile by viewModel.userProfile.collectAsStateWithLifecycle()
    
    var name by remember(userProfile) { mutableStateOf(userProfile.name) }
    var targetPct by remember(userProfile) { mutableStateOf(userProfile.targetPercentage.toString()) }
    var college by remember(userProfile) { mutableStateOf(userProfile.targetCollege) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp),
        horizontalAlignment = Alignment.End
    ) {
        Text("تعديل البيانات الشخصية ومستهدفات النجاح", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)

        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("اسم المستخدم") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = TextStyle(textAlign = TextAlign.Right)
        )

        OutlinedTextField(
            value = targetPct,
            onValueChange = { targetPct = it },
            label = { Text("النسبة المئوية المستهدفة للثانوية العامة (%)") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = TextStyle(textAlign = TextAlign.Right)
        )

        OutlinedTextField(
            value = college,
            onValueChange = { college = it },
            label = { Text("الكلية والجامعة المستهدفة") },
            modifier = Modifier.fillMaxWidth(),
            textStyle = TextStyle(textAlign = TextAlign.Right)
        )

        Button(
            onClick = {
                val pct = targetPct.toDoubleOrNull() ?: 99.0
                viewModel.updateProfile(name, pct, college, userProfile.examDateMillis)
                viewModel.speakText("تم حفظ البيانات بنجاح يا محمد حسام.")
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
        ) {
            Text("حفظ التغييرات")
        }
    }
}
