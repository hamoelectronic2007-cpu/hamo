package com.example.data

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.example.BuildConfig

object FirebaseManager {
    private const val TAG = "FirebaseManager"
    
    var isInitialized = false
        private set

    fun initialize(context: Context) {
        if (isInitialized) return
        try {
            // 1. Try to initialize dynamically using BuildConfig variables
            val apiKey = try { BuildConfig.FIREBASE_API_KEY } catch (e: Exception) { "" }
            val appId = try { BuildConfig.FIREBASE_APP_ID } catch (e: Exception) { "" }
            val projectId = try { BuildConfig.FIREBASE_PROJECT_ID } catch (e: Exception) { "" }

            if (!apiKey.isNullOrEmpty() && !appId.isNullOrEmpty() && !projectId.isNullOrEmpty()) {
                val options = FirebaseOptions.Builder()
                    .setApiKey(apiKey)
                    .setApplicationId(appId)
                    .setProjectId(projectId)
                    .build()
                FirebaseApp.initializeApp(context, options)
                Log.d(TAG, "Firebase initialized dynamically with custom options successfully.")
                isInitialized = true
            } else {
                // 2. Fallback to standard initialization (expects google-services.json configuration)
                FirebaseApp.initializeApp(context)
                Log.d(TAG, "Firebase initialized using google-services.json successfully.")
                isInitialized = true
            }
        } catch (e: Exception) {
            Log.e(TAG, "Firebase initialization failed: ${e.message}. Dynamic key/appID might be missing. App will run in offline simulation mode.", e)
            isInitialized = false
        }
    }

    val auth: FirebaseAuth?
        get() = if (isInitialized) FirebaseAuth.getInstance() else null

    val firestore: FirebaseFirestore?
        get() = if (isInitialized) FirebaseFirestore.getInstance() else null

    fun syncUserToFirestore(
        email: String,
        name: String,
        photoUrl: String,
        status: Map<String, Any>,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        val db = firestore ?: return
        val currentAuth = auth ?: return
        val uid = currentAuth.currentUser?.uid ?: return
        
        val userData = hashMapOf<String, Any>(
            "uid" to uid,
            "email" to email,
            "name" to name,
            "photoUrl" to photoUrl,
            "lastUpdated" to System.currentTimeMillis()
        )
        userData.putAll(status)

        db.collection("users").document(uid)
            .set(userData, SetOptions.merge())
            .addOnSuccessListener {
                Log.d(TAG, "User data synced to Firestore successfully.")
                onSuccess()
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error syncing user data to Firestore: ${e.message}", e)
                onFailure(e)
            }
    }

    fun syncLogsToFirestore(
        logs: List<String>,
        onSuccess: () -> Unit = {},
        onFailure: (Exception) -> Unit = {}
    ) {
        val db = firestore ?: return
        val currentAuth = auth ?: return
        val uid = currentAuth.currentUser?.uid ?: return

        val logData = hashMapOf(
            "logs" to logs,
            "timestamp" to System.currentTimeMillis()
        )

        db.collection("users").document(uid).collection("logs")
            .document("latest_logs")
            .set(logData)
            .addOnSuccessListener {
                Log.d(TAG, "Security logs backed up to Firestore successfully.")
                onSuccess()
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error backing up security logs to Firestore: ${e.message}", e)
                onFailure(e)
            }
    }
}
