package com.example.data

import android.content.Context
import android.content.SharedPreferences

class EncryptedPrefs(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("HamoSecurePrefs", Context.MODE_PRIVATE)

    fun putString(key: String, value: String) {
        val encryptedValue = HamoSecuritySuite.encrypt(value)
        prefs.edit().putString(key, encryptedValue).apply()
    }

    fun getString(key: String, defaultValue: String): String {
        val encryptedValue = prefs.getString(key, null) ?: return defaultValue
        val decrypted = HamoSecuritySuite.decrypt(encryptedValue)
        return if (decrypted == encryptedValue && encryptedValue.isNotEmpty() && !encryptedValue.contains(":")) {
            // It was not encrypted or decryption failed with same format, return default or value
            encryptedValue
        } else {
            decrypted
        }
    }

    fun putBoolean(key: String, value: Boolean) {
        putString(key, value.toString())
    }

    fun getBoolean(key: String, defaultValue: Boolean): Boolean {
        val str = getString(key, "")
        if (str.isEmpty()) return defaultValue
        return str.toBoolean()
    }

    fun putInt(key: String, value: Int) {
        putString(key, value.toString())
    }

    fun getInt(key: String, defaultValue: Int): Int {
        val str = getString(key, "")
        if (str.isEmpty()) return defaultValue
        return str.toIntOrNull() ?: defaultValue
    }

    fun putLong(key: String, value: Long) {
        putString(key, value.toString())
    }

    fun getLong(key: String, defaultValue: Long): Long {
        val str = getString(key, "")
        if (str.isEmpty()) return defaultValue
        return str.toLongOrNull() ?: defaultValue
    }
}
