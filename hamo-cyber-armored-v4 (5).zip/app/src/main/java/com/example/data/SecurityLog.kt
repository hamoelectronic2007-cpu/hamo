package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "security_logs")
data class SecurityLog(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val type: String, // "INFO", "ALERT", "SUCCESS", "DANGER"
    val title: String,
    val message: String,
    val timestamp: Long = System.currentTimeMillis()
)
