package com.example.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class ShieldRepository(
    private val vaultItemDao: VaultItemDao,
    private val securityLogDao: SecurityLogDao
) {
    val recentLogs: Flow<List<SecurityLog>> = securityLogDao.getRecentLogs()
    val vaultItems: Flow<List<VaultItem>> = vaultItemDao.getAllItems()

    suspend fun insertLog(log: SecurityLog): Long = withContext(Dispatchers.IO) {
        securityLogDao.insertLog(log)
    }

    suspend fun clearLogs() = withContext(Dispatchers.IO) {
        securityLogDao.clearLogs()
    }

    suspend fun deleteLog(id: Int) = withContext(Dispatchers.IO) {
        securityLogDao.deleteLog(id)
    }

    suspend fun insertVaultItem(item: VaultItem): Long = withContext(Dispatchers.IO) {
        vaultItemDao.insertItem(item)
    }

    suspend fun deleteVaultItem(id: Int) = withContext(Dispatchers.IO) {
        vaultItemDao.deleteItem(id)
    }

    suspend fun seedMockLogsOnInitial() = withContext(Dispatchers.IO) {
        // Pre-populate system with initial military logs to show in dashboard
        val firstLogs = listOf(
            SecurityLog(
                type = "SUCCESS",
                title = "نواة حمو الدفاعية نشطة",
                message = "تم تمهيد محرك التعرف الذكي Hamo Micro-OS بنجاح. حماية Zero-Click قائمة."
            ),
            SecurityLog(
                type = "INFO",
                title = "شهادة الحماية الرقمية",
                message = "تشفير AES-256-GCM متكامل لملفات قاعدة البيانات والخزنة."
            ),
            SecurityLog(
                type = "DANGER",
                title = "محاولة تتبع موقع صامتة",
                message = "منع تطبيق مشبوه من استدعاء طلب التتبع الجغرافي المكثف في الخلفية."
            ),
            SecurityLog(
                type = "ALERT",
                title = "جدار الحماية المحلي نشط",
                message = "مراقبة مستمرة للمنافذ المفتوحة وحزم الاتصال وحماية ARP مفعلة."
            )
        )
        for (log in firstLogs) {
            securityLogDao.insertLog(log)
        }
    }
}
