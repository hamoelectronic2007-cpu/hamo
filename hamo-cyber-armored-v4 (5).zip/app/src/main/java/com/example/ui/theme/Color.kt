package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val BgPrimary = Color(0xFF0A0A0F)        // Deep dark military blue background
val BgSecondary = Color(0xFF111118)      // Subtle dark card/panel layout
val BgGlass = Color(0xFF1A1A2E)          // Glassmorphic translucent frame

val NeonCyan = Color(0xFF00D4FF)         // HUD Glowing cyan highlight
val TechPurple = Color(0xFFA855F7)       // Deep Command purple borders
val DangerRed = Color(0xFFFF0040)        // Active Threat Red alerts
val SafeGreen = Color(0xFF10B981)        // Fully locked Emerald green
val WarningAmber = Color(0xFFF59E0B)     // System vulnerability warnings

val TextPrimary = Color(0xFFF0F4FF)      // Pristine Ice White
val TextSecondary = Color(0xFF94A3B8)    // Muted tech slate grey
val BorderGlow = Color(0x3300D4FF)       // Light glow overlay for glass layers
