package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = NeonCyan,
    secondary = TechPurple,
    tertiary = SafeGreen,
    background = BgPrimary,
    surface = BgSecondary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    surfaceVariant = BgGlass,
    onSurfaceVariant = TextPrimary,
    error = DangerRed,
    errorContainer = DangerRed,
    onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // The Ultimate Armour Shield is beautifully framed in the military dark mode by construct
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
