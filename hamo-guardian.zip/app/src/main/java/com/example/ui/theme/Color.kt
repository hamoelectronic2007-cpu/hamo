package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber Dark Theme Palette
val DarkBg = Color(0xFF070709)
val CyberCard = Color(0xFF111218)
val CyanNeon = Color(0xFF00FFCC)
val RedNeon = Color(0xFFFF2A6D)
val GreenNeon = Color(0xFF05FF9B)
val YellowNeon = Color(0xFFFFD200)

val TextPrimary = Color(0xFFE2E4F0)
val TextSecondary = Color(0xFF82899A)

// Legacy Material Palette mapping
val Purple80 = CyanNeon
val PurpleGrey80 = Color(0xFF1B1D28)
val Pink80 = RedNeon

val Purple40 = Color(0xFF00A383)
val PurpleGrey40 = Color(0xFF0E1017)
val Pink40 = Color(0xFFD01C54)

