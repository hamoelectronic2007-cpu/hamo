package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkBg
import com.example.ui.theme.YellowNeon

@Composable
fun BehavioralWarningCard(
    onTriggerBehaviorEvent: (category: String, message: String) -> Unit
) {
    var spamCount by remember { mutableStateOf(0) }
    var groupCount by remember { mutableStateOf(0) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp))
            .border(1.dp, YellowNeon.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .padding(16.dp)
            .testTag("behavioral_warning_card")
    ) {
        Text(
            text = "WHATSAPP BAN PREVENTER",
            color = YellowNeon,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.sp
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "WhatsApp uses automated heuristics to ban accounts performing rapid clicks, group mass joins, or spam patterns. Simulate behavioral warnings:",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f),
            fontSize = 11.sp,
            lineHeight = 15.sp
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Message Blast Velocity",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "Click to simulate sending multiple messages rapidly.",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    fontSize = 10.sp
                )
            }
            Button(
                onClick = {
                    spamCount++
                    if (spamCount >= 5) {
                        onTriggerBehaviorEvent(
                            "VELOCITY SHIELD",
                            "WARNING: Spam velocity detected! 5 messages sent in under 20 seconds. Automated bans usually trigger immediately. Cool-down requested."
                        )
                        spamCount = 0
                    } else {
                        onTriggerBehaviorEvent(
                            "Message Sent",
                            "Simulating normal message outbound activity ($spamCount/5 clicks for bot limit trigger)."
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = YellowNeon, contentColor = DarkBg),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Send Rapid ($spamCount/5)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Mass Group Join Velocity",
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )
                Text(
                    text = "Simulate bulk joining groups (triggering WhatsApp ban algorithms).",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                    fontSize = 10.sp
                )
            }
            Button(
                onClick = {
                    groupCount++
                    if (groupCount >= 3) {
                        onTriggerBehaviorEvent(
                            "BULK GROUP SHIELD",
                            "CRITICAL BAN RISK: Attempted to join 3 new WhatsApp groups in seconds. Bot heuristics active."
                        )
                        groupCount = 0
                    } else {
                        onTriggerBehaviorEvent(
                            "Group Joined",
                            "Simulated group join vector ($groupCount/3 joins)."
                        )
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = CyanNeon, contentColor = DarkBg),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Join Group ($groupCount/3)", fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
            }
        }
    }
}
