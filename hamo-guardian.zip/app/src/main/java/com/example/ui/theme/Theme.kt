package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val CyberColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = DarkBg,
    secondary = GreenNeon,
    onSecondary = DarkBg,
    tertiary = RedNeon,
    background = DarkBg,
    onBackground = TextPrimary,
    surface = CyberCard,
    onSurface = TextPrimary,
    error = RedNeon,
    onError = DarkBg
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Force Dark Cyber Mode
    dynamicColor: Boolean = false, // Maintain brand neon colors
    content: @Composable () -> Unit,
) {
    val colorScheme = CyberColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
