package com.example.data.repository

import com.example.data.database.LogEntity
import com.example.data.database.QuarantineEntity
import com.example.data.database.SecurityDao
import com.example.data.database.VulnerabilityEntity
import kotlinx.coroutines.flow.Flow

class SecurityRepository(private val securityDao: SecurityDao) {

    val allVulnerabilities: Flow<List<VulnerabilityEntity>> = securityDao.getAllVulnerabilities()
    val allLogs: Flow<List<LogEntity>> = securityDao.getAllLogs()
    val allQuarantine: Flow<List<QuarantineEntity>> = securityDao.getAllQuarantine()

    suspend fun insertLog(eventType: String, message: String, details: String, severity: String) {
        val log = LogEntity(
            eventType = eventType,
            message = message,
            details = details,
            severity = severity
        )
        securityDao.insertLog(log)
    }

    suspend fun clearLogs() {
        securityDao.clearLogs()
    }

    suspend fun quarantineFile(
        originalName: String,
        originalPath: String,
        fileSize: Long,
        threatType: String,
        hexSnippet: String,
        simulatedContent: String
    ) {
        val item = QuarantineEntity(
            originalName = originalName,
            originalPath = originalPath,
            fileSize = fileSize,
            threatType = threatType,
            hexSnippet = hexSnippet,
            simulatedContent = simulatedContent
        )
        securityDao.insertQuarantine(item)
        insertLog(
            eventType = "BLOCK",
            message = "Isolated threat: $originalName",
            details = "Detected $threatType payload and safely quarantined file. Path: $originalPath",
            severity = "Critical"
        )
    }

    suspend fun restoreQuarantine(id: Long) {
        val item = securityDao.getQuarantineById(id)
        if (item != null) {
            securityDao.deleteQuarantineById(id)
            insertLog(
                eventType = "RESTORE",
                message = "Restored file: ${item.originalName}",
                details = "User manually restored file to original path: ${item.originalPath}",
                severity = "Warning"
            )
        }
    }

    suspend fun deleteQuarantine(id: Long) {
        val item = securityDao.getQuarantineById(id)
        if (item != null) {
            securityDao.deleteQuarantineById(id)
            insertLog(
                eventType = "DELETE",
                message = "Permanently deleted: ${item.originalName}",
                details = "Quarantined threat has been safely purged from the device local sandboxed directory.",
                severity = "Info"
            )
        }
    }

    suspend fun updateVulnerabilities(vulns: List<VulnerabilityEntity>) {
        securityDao.insertVulnerabilities(vulns)
        insertLog(
            eventType = "SYNC",
            message = "Updated Vulnerability Database",
            details = "Successfully synchronized ${vulns.size} threat definitions with the HamO Guardian security cloud.",
            severity = "Info"
        )
    }

    suspend fun populateInitialVulnerabilities() {
        val defaultVulns = listOf(
            VulnerabilityEntity(
                id = "CVE-2023-4863",
                fileType = "webp",
                severity = "Critical",
                description = "Heap buffer overflow in WebP image parsing library (libwebp). Allows remote code execution via malformed WebP lossless images.",
                signaturePattern = "52 49 46 46 [..] 57 45 42 50 56 50 38 4c" // RIFF....WEBPVP8L lossless
            ),
            VulnerabilityEntity(
                id = "CVE-2024-27818",
                fileType = "png",
                severity = "Critical",
                description = "WhatsApp media parsing vulnerability involving malformed chunk headers in iMessage-style cross-app media processing.",
                signaturePattern = "89 50 4e 47 0d 0a 1a 0a [..] 49 45 4e 44" // PNG header with bad size
            ),
            VulnerabilityEntity(
                id = "CVE-2024-20017",
                fileType = "mp4",
                severity = "Critical",
                description = "Buffer overflow vulnerability in MediaTek video decode pipeline during parsing of customized Atoms.",
                signaturePattern = "00 00 00 [..] 66 74 79 70 6d 70 34 32" // ftypmp42
            ),
            VulnerabilityEntity(
                id = "CVE-2026-WAPP-POLY",
                fileType = "jpg",
                severity = "High",
                description = "Polyglot WhatsApp exploit. A valid JPEG image containing an appended executable ZIP/APK payload mimicking stickers.",
                signaturePattern = "ff d8 [..] ff d9 50 4b 03 04" // JPEG end + ZIP header
            ),
            VulnerabilityEntity(
                id = "CVE-2026-WAPP-STEG",
                fileType = "webp",
                severity = "High",
                description = "Steganographic command injection payload concealed within metadata tags or LSB pixel alterations.",
                signaturePattern = "55 73 65 72 43 6f 6d 6d 65 6e 74 3d 62 61 73 65 36 34" // UserComment=base64
            )
        )
        securityDao.insertVulnerabilities(defaultVulns)
        insertLog(
            eventType = "SCAN",
            message = "HamO Guardian Engine Initialized",
            details = "Local active monitoring shield is armed and ready. Ready to scan incoming media folders.",
            severity = "Info"
        )
    }
}
