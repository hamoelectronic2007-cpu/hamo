package com.example.data.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

// 1. CVE / Threat Definition Entity
@Entity(tableName = "vulnerabilities")
data class VulnerabilityEntity(
    @PrimaryKey val id: String, // e.g. CVE-2023-4863
    val fileType: String,       // webp, png, gif, pdf
    val severity: String,       // Critical, High, Medium
    val description: String,
    val signaturePattern: String, // Hex or regex pattern
    val dateAdded: Long = System.currentTimeMillis()
)

// 2. Incident Log Entity
@Entity(tableName = "incident_logs")
data class LogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val eventType: String,      // SCAN, BLOCK, SYNC, WALL, ALERT
    val message: String,
    val details: String,
    val severity: String        // Info, Warning, Critical
)

// 3. Quarantined File Entity
@Entity(tableName = "quarantine")
data class QuarantineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val originalName: String,
    val originalPath: String,
    val dateQuarantined: Long = System.currentTimeMillis(),
    val fileSize: Long,
    val threatType: String,     // Polyglot, Steganography, Zero-Click, Malicious Magic Bytes
    val hexSnippet: String,     // Hex representation of suspicious part
    val simulatedContent: String // Content simulated inside quarantine vault
)

@Dao
interface SecurityDao {
    // Vulnerability Queries
    @Query("SELECT * FROM vulnerabilities ORDER BY dateAdded DESC")
    fun getAllVulnerabilities(): Flow<List<VulnerabilityEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVulnerabilities(vulns: List<VulnerabilityEntity>)

    @Query("DELETE FROM vulnerabilities")
    suspend fun clearVulnerabilities()

    // Log Queries
    @Query("SELECT * FROM incident_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<LogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: LogEntity)

    @Query("DELETE FROM incident_logs")
    suspend fun clearLogs()

    // Quarantine Queries
    @Query("SELECT * FROM quarantine ORDER BY dateQuarantined DESC")
    fun getAllQuarantine(): Flow<List<QuarantineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertQuarantine(item: QuarantineEntity)

    @Query("DELETE FROM quarantine WHERE id = :id")
    suspend fun deleteQuarantineById(id: Long)

    @Query("SELECT * FROM quarantine WHERE id = :id LIMIT 1")
    suspend fun getQuarantineById(id: Long): QuarantineEntity?
}
