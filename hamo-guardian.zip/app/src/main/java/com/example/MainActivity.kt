package com.example

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewModelScope
import com.example.ui.components.BehavioralWarningCard
import com.example.ui.components.CyberAboutCard
import com.example.ui.components.DatabaseSyncCard
import com.example.ui.components.ExploitScannerModule
import com.example.ui.components.LogItemRow
import com.example.ui.components.MetricCard
import com.example.ui.components.QuarantineItemRow
import com.example.ui.components.StatusHeader
import com.example.ui.components.TabHeaderBar
import com.example.ui.components.VulnerabilityRow
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.DarkBg
import com.example.ui.theme.GreenNeon
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RedNeon
import com.example.ui.theme.YellowNeon
import com.example.viewmodel.SecurityViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val viewModel: SecurityViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainDashboardScreen(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboardScreen(viewModel: SecurityViewModel) {
    var selectedTab by remember { mutableStateOf(0) }
    var isShieldActive by remember { mutableStateOf(true) }

    // State bindings
    val vulns by viewModel.vulnerabilities.collectAsState()
    val logs by viewModel.logs.collectAsState()
    val quarantineItems by viewModel.quarantineItems.collectAsState()
    val scanState by viewModel.scanState.collectAsState()

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "HAMO GUARDIAN 2026",
                        color = CyanNeon,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        letterSpacing = 1.sp
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBg,
                    titleContentColor = CyanNeon
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(DarkBg)
                .padding(innerPadding)
        ) {
            // Persistent Active Shield Controller & Stat Board
            Column(modifier = Modifier.padding(16.dp)) {
                StatusHeader(
                    isProtected = isShieldActive,
                    onStatusClick = { isShieldActive = !isShieldActive }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Stats Dashboard Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    MetricCard(
                        title = "ISOLATED THREATS",
                        value = "${quarantineItems.size}",
                        accentColor = RedNeon,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "PARSED MEDIA",
                        value = "${logs.filter { it.eventType == "SCAN" }.size}",
                        accentColor = GreenNeon,
                        modifier = Modifier.weight(1f)
                    )
                    MetricCard(
                        title = "CVE SCHEMAS",
                        value = "${vulns.size}",
                        accentColor = CyanNeon,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // High Tech Navigation tabs
            val tabTitles = listOf("SHIELD TEST", "ISOLATIONS", "INCIDENT LOGS", "VULNERABILITIES", "ABOUT")
            TabHeaderBar(
                tabs = tabTitles,
                selectedTabIndex = selectedTab,
                onTabSelected = { selectedTab = it }
            )

            // Dynamic view content based on Tab select
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                when (selectedTab) {
                    0 -> ShieldTestTab(
                        onTriggerScan = { fileName, extension, bytes ->
                            viewModel.runManualScan(fileName, extension, bytes)
                        },
                        scanState = scanState,
                        onResetScan = { viewModel.resetScanState() },
                        onTriggerBehaviorEvent = { category, msg ->
                            viewModel.viewModelScope.launch {
                                val severity = if (category.contains("SHIELD")) "Critical" else "Info"
                                viewModel.runManualScan("simulated_behav", "txt", byteArrayOf())
                                // Seed behavior log directly to show warning feedback
                                (viewModel.getApplication() as? Application)?.let {
                                    val db = com.example.data.database.AppDatabase.getDatabase(it)
                                    db.securityDao().insertLog(
                                        com.example.data.database.LogEntity(
                                            eventType = "ALERT",
                                            message = category,
                                            details = msg,
                                            severity = severity
                                        )
                                    )
                                }
                            }
                        }
                    )
                    1 -> IsolationsTab(
                        quarantineItems = quarantineItems,
                        onRestore = { viewModel.restoreQuarantine(it) },
                        onDelete = { viewModel.deleteQuarantine(it) }
                    )
                    2 -> LogsTab(
                        logs = logs,
                        onClearLogs = { viewModel.clearLogs() }
                    )
                    3 -> VulnerabilitiesTab(
                        vulns = vulns,
                        onSyncClick = { viewModel.synchronizeDatabase() }
                    )
                    4 -> AboutTab()
                }
            }
        }
    }
}

@Composable
fun ShieldTestTab(
    onTriggerScan: (fileName: String, extension: String, bytes: ByteArray) -> Unit,
    scanState: com.example.viewmodel.ScanUiState,
    onResetScan: () -> Unit,
    onTriggerBehaviorEvent: (category: String, message: String) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            ExploitScannerModule(
                onTriggerScan = onTriggerScan,
                scanState = scanState,
                onResetScan = onResetScan
            )
        }
        item {
            BehavioralWarningCard(
                onTriggerBehaviorEvent = onTriggerBehaviorEvent
            )
        }
    }
}

@Composable
fun IsolationsTab(
    quarantineItems: List<com.example.data.database.QuarantineEntity>,
    onRestore: (Long) -> Unit,
    onDelete: (Long) -> Unit
) {
    if (quarantineItems.isEmpty()) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "🟢 NO ISOLATED THREATS",
                color = GreenNeon,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "No malicious files have been isolated in the local sandboxed directory.",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                fontSize = 11.sp,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    } else {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(quarantineItems, key = { it.id }) { item ->
                QuarantineItemRow(
                    id = item.id,
                    fileName = item.originalName,
                    threatType = item.threatType,
                    fileSize = item.fileSize,
                    hexSnippet = item.hexSnippet,
                    onRestore = onRestore,
                    onDelete = onDelete
                )
            }
        }
    }
}

@Composable
fun LogsTab(
    logs: List<com.example.data.database.LogEntity>,
    onClearLogs: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "REAL-TIME LOG CONSOLE",
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Button(
                onClick = onClearLogs,
                colors = ButtonDefaults.buttonColors(
                    containerColor = RedNeon.copy(alpha = 0.15f),
                    contentColor = RedNeon
                ),
                shape = RoundedCornerShape(6.dp)
            ) {
                Text("Clear History", fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

        if (logs.isEmpty()) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = "No System Logs Found",
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(logs) { log ->
                    LogItemRow(
                        eventType = log.eventType,
                        message = log.message,
                        details = log.details,
                        timestamp = log.timestamp,
                        severity = log.severity
                    )
                }
                item { Spacer(modifier = Modifier.height(16.dp)) }
            }
        }
    }
}

@Composable
fun VulnerabilitiesTab(
    vulns: List<com.example.data.database.VulnerabilityEntity>,
    onSyncClick: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        PaddingWrapper {
            DatabaseSyncCard(onSyncClick = onSyncClick)
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "KNOWN CVE ATTACK VECTORS",
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
        )

        Divider(color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vulns, key = { it.id }) { vuln ->
                VulnerabilityRow(
                    id = vuln.id,
                    fileType = vuln.fileType,
                    severity = vuln.severity,
                    description = vuln.description,
                    signaturePattern = vuln.signaturePattern
                )
            }
            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

@Composable
fun AboutTab() {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item { CyberAboutCard() }
    }
}

@Composable
fun PaddingWrapper(content: @Composable () -> Unit) {
    Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        content()
    }
}
