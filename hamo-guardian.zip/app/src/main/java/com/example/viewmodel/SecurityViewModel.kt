package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.database.AppDatabase
import com.example.data.database.LogEntity
import com.example.data.database.QuarantineEntity
import com.example.data.database.VulnerabilityEntity
import com.example.data.repository.SecurityRepository
import com.example.service.ScanningEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

sealed interface ScanUiState {
    object Idle : ScanUiState
    object Scanning : ScanUiState
    data class ScanFinished(val isSafe: Boolean, val threatName: String, val details: String) : ScanUiState
}

class SecurityViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: SecurityRepository
    private val scanner: ScanningEngine

    init {
        val database = AppDatabase.getDatabase(application)
        repository = SecurityRepository(database.securityDao())
        scanner = ScanningEngine(repository)

        // Seed default database if empty
        viewModelScope.launch {
            repository.populateInitialVulnerabilities()
        }
    }

    // UI Observables
    val vulnerabilities: StateFlow<List<VulnerabilityEntity>> = repository.allVulnerabilities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val logs: StateFlow<List<LogEntity>> = repository.allLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quarantineItems: StateFlow<List<QuarantineEntity>> = repository.allQuarantine
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _scanState = MutableStateFlow<ScanUiState>(ScanUiState.Idle)
    val scanState: StateFlow<ScanUiState> = _scanState.asStateFlow()

    // 1. Trigger simulated / manual file scanning
    fun runManualScan(fileName: String, fileExtension: String, simulatedBytes: ByteArray) {
        viewModelScope.launch {
            _scanState.value = ScanUiState.Scanning
            repository.insertLog(
                eventType = "SCAN",
                message = "Manual scan requested: $fileName.$fileExtension",
                details = "Analyzing headers, magic bytes and structure of user-provided sample.",
                severity = "Info"
            )

            // Simulate file delay
            kotlinx.coroutines.delay(1200)

            val tempFile = File(getApplication<Application>().cacheDir, "$fileName.$fileExtension")
            val scanResult = scanner.scanFile(tempFile, simulatedBytes)

            if (!scanResult.isSafe) {
                scanner.processThreat(tempFile, scanResult, simulatedBytes)
                _scanState.value = ScanUiState.ScanFinished(
                    isSafe = false,
                    threatName = scanResult.threatName,
                    details = scanResult.details
                )
            } else {
                repository.insertLog(
                    eventType = "SCAN",
                    message = "Scan clean: $fileName.$fileExtension",
                    details = "Verified structure safely. No known exploits detected.",
                    severity = "Info"
                )
                _scanState.value = ScanUiState.ScanFinished(
                    isSafe = true,
                    threatName = "",
                    details = "File parsed successfully. Structure conforms to official specifications."
                )
            }
        }
    }

    fun resetScanState() {
        _scanState.value = ScanUiState.Idle
    }

    // 2. Clear Log History
    fun clearLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }

    // 3. Quarantine actions
    fun restoreQuarantine(id: Long) {
        viewModelScope.launch {
            repository.restoreQuarantine(id)
        }
    }

    fun deleteQuarantine(id: Long) {
        viewModelScope.launch {
            repository.deleteQuarantine(id)
        }
    }

    // 4. Force Emergency Vulnerability Database Synchronization
    fun synchronizeDatabase() {
        viewModelScope.launch {
            repository.insertLog(
                eventType = "SYNC",
                message = "Manual DB Synchronization Triggered",
                details = "Contacting security cloud to pull updated CVE vectors for zero-click exploits...",
                severity = "Info"
            )

            kotlinx.coroutines.delay(1000)

            val newVulns = listOf(
                VulnerabilityEntity(
                    id = "CVE-2023-4863",
                    fileType = "webp",
                    severity = "Critical",
                    description = "Heap buffer overflow in WebP image parsing library (libwebp). Allows remote code execution via malformed WebP lossless images.",
                    signaturePattern = "52 49 46 46 [..] 57 45 42 50 56 50 38 4c"
                ),
                VulnerabilityEntity(
                    id = "CVE-2024-27818",
                    fileType = "png",
                    severity = "Critical",
                    description = "WhatsApp media parsing vulnerability involving malformed chunk headers in iMessage-style cross-app media processing.",
                    signaturePattern = "89 50 4e 47 0d 0a 1a 0a [..] 49 45 4e 44"
                ),
                VulnerabilityEntity(
                    id = "CVE-2024-20017",
                    fileType = "mp4",
                    severity = "Critical",
                    description = "Buffer overflow vulnerability in MediaTek video decode pipeline during parsing of customized Atoms.",
                    signaturePattern = "00 00 00 [..] 66 74 79 70 6d 70 34 32"
                ),
                VulnerabilityEntity(
                    id = "CVE-2026-WAPP-POLY",
                    fileType = "jpg",
                    severity = "High",
                    description = "Polyglot WhatsApp exploit. A valid JPEG image containing an appended executable ZIP/APK payload mimicking stickers.",
                    signaturePattern = "ff d8 [..] ff d9 50 4b 03 04"
                ),
                VulnerabilityEntity(
                    id = "CVE-2026-WAPP-STEG",
                    fileType = "webp",
                    severity = "High",
                    description = "Steganographic command injection payload concealed within metadata tags or LSB pixel alterations.",
                    signaturePattern = "55 73 65 72 43 6f 6d 6d 65 6e 74 3d 62 61 73 65 36 34"
                ),
                // Freshly discovered 2026 exploit synced
                VulnerabilityEntity(
                    id = "CVE-2026-ZERO-STICKER",
                    fileType = "webp",
                    severity = "Critical",
                    description = "Newly discovered Zero-Click buffer overflow Vector in WhatsApp Animated Sticker processing pipeline.",
                    signaturePattern = "52 49 46 46 [..] 57 45 42 50 41 4e 49 4d" // RIFF...WEBPANIM
                )
            )

            repository.updateVulnerabilities(newVulns)
        }
    }
}
