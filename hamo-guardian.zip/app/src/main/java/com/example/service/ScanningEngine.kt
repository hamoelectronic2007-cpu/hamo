package com.example.service

import android.os.Environment
import android.util.Log
import com.example.data.repository.SecurityRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale

/**
 * Handles security scanning of file headers, bytes, metadata and file structures
 * to detect zero-click exploits, polyglots, steganography, and incorrect magic bytes.
 */
class ScanningEngine(private val repository: SecurityRepository) {

    private val scope = CoroutineScope(Dispatchers.IO)

    data class ScanResult(
        val isSafe: Boolean,
        val threatName: String = "",
        val details: String = "",
        val hexSnippet: String = "",
        val targetCve: String = ""
    )

    /**
     * Scan an incoming media file by reading its bytes and checking structures
     */
    fun scanFile(file: File, simulatedBytes: ByteArray? = null): ScanResult {
        try {
            val bytes = simulatedBytes ?: if (file.exists() && file.isFile) {
                file.readBytes()
            } else {
                return ScanResult(isSafe = true)
            }

            if (bytes.isEmpty()) return ScanResult(isSafe = true)

            // 1. EXTENSION VS MAGIC BYTES CHECK (Spoofing Check)
            val extension = file.extension.lowercase(Locale.ROOT)
            val magicBytesResult = verifyMagicBytes(extension, bytes)
            if (!magicBytesResult.isSafe) {
                return magicBytesResult
            }

            // 2. POLYGLOT CHECK (Appended payloads, like ZIP/APK at the end of JPEG)
            val polyglotResult = checkPolyglot(extension, bytes)
            if (!polyglotResult.isSafe) {
                return polyglotResult
            }

            // 3. STEGANOGRAPHY & METADATA EXPLOIT CHECK (Base64 or Shell scripts in comments)
            val stegResult = checkSteganographyAndMetadata(bytes)
            if (!stegResult.isSafe) {
                return stegResult
            }

            // 4. ZERO-CLICK EXPLOIT STRUCTURES (Buffer overflow headers, e.g. libwebp CVE-2023-4863)
            val zeroClickResult = checkZeroClickExploits(extension, bytes)
            if (!zeroClickResult.isSafe) {
                return zeroClickResult
            }

            return ScanResult(isSafe = true)

        } catch (e: Exception) {
            Log.e("ScanningEngine", "Error scanning file ${file.name}: ${e.message}")
            return ScanResult(isSafe = false, threatName = "Scan Error", details = "Failed to parse file: ${e.message}")
        }
    }

    /**
     * Verifies if the file's extension matches its actual magic bytes
     */
    private fun verifyMagicBytes(extension: String, bytes: ByteArray): ScanResult {
        if (bytes.size < 4) return ScanResult(isSafe = true)

        val hexHeader = bytes.take(4).joinToString("") { "%02x".format(it) }

        when (extension) {
            "jpg", "jpeg" -> {
                // JPEG must start with ffd8
                if (!hexHeader.startsWith("ffd8")) {
                    return ScanResult(
                        isSafe = false,
                        threatName = "Spoofed JPEG File",
                        details = "File claims to be JPG but starts with hex: $hexHeader",
                        hexSnippet = hexHeader,
                        targetCve = "SPOOF-01"
                    )
                }
            }
            "png" -> {
                // PNG must start with 89504e47
                if (hexHeader != "89504e47") {
                    return ScanResult(
                        isSafe = false,
                        threatName = "Spoofed PNG File",
                        details = "File claims to be PNG but starts with hex: $hexHeader",
                        hexSnippet = hexHeader,
                        targetCve = "SPOOF-02"
                    )
                }
            }
            "webp" -> {
                // WebP starts with RIFF (52494646) and WEBP (57454250) at offset 8
                val isRiff = hexHeader == "52494646"
                val isWebp = if (bytes.size >= 12) {
                    bytes.sliceArray(8..11).joinToString("") { "%02x".format(it) } == "57454250"
                } else false

                if (!isRiff || !isWebp) {
                    return ScanResult(
                        isSafe = false,
                        threatName = "Spoofed WebP File",
                        details = "File claims to be WebP but does not have valid RIFF/WEBP structure",
                        hexSnippet = hexHeader,
                        targetCve = "SPOOF-03"
                    )
                }
            }
            "mp4" -> {
                // MP4 files contain 'ftyp' (66747970) at index 4
                if (bytes.size >= 8) {
                    val ftyp = bytes.sliceArray(4..7).joinToString("") { "%02x".format(it) }
                    if (ftyp != "66747970") {
                        return ScanResult(
                            isSafe = false,
                            threatName = "Spoofed MP4 Video",
                            details = "File claims to be MP4 but does not contain standard ftyp box",
                            hexSnippet = ftyp,
                            targetCve = "SPOOF-04"
                        )
                    }
                }
            }
        }
        return ScanResult(isSafe = true)
    }

    /**
     * Checks if there's an executable or zip payload appended at the end of the image
     */
    private fun checkPolyglot(extension: String, bytes: ByteArray): ScanResult {
        // ZIP/APK header is 504b0304 (PK\u0003\u0004)
        val zipHeaderBytes = byteArrayOf(0x50, 0x4B, 0x03, 0x04)
        val zipHeaderHex = "504b0304"

        when (extension) {
            "jpg", "jpeg" -> {
                // Find JPEG EOIs (ff d9) and see if PK is appended after it
                val eoiIndex = findSequence(bytes, byteArrayOf(0xFF.toByte(), 0xD9.toByte()))
                if (eoiIndex != -1 && eoiIndex < bytes.size - 2) {
                    // There are bytes AFTER JPEG EOI. Let's see if we can find a ZIP/APK header.
                    val zipIndex = findSequence(bytes, zipHeaderBytes, eoiIndex)
                    if (zipIndex != -1) {
                        return ScanResult(
                            isSafe = false,
                            threatName = "Polyglot Exploit Payload",
                            details = "Detected Android APK/ZIP payload hidden after JPEG End-Of-Image marker (at offset $zipIndex). Attempting to deploy executable on WhatsApp auto-download.",
                            hexSnippet = zipHeaderHex,
                            targetCve = "CVE-2026-WAPP-POLY"
                        )
                    }
                }
            }
            "png" -> {
                // Find PNG End chunk (IEND) index
                val iendBytes = byteArrayOf(0x49, 0x45, 0x4E, 0x44)
                val iendIndex = findSequence(bytes, iendBytes)
                if (iendIndex != -1 && iendIndex < bytes.size - 8) {
                    val zipIndex = findSequence(bytes, zipHeaderBytes, iendIndex)
                    if (zipIndex != -1) {
                        return ScanResult(
                            isSafe = false,
                            threatName = "Polyglot Exploit Payload",
                            details = "Detected Android APK/ZIP payload appended after PNG IEND chunk (at offset $zipIndex). Attempting malicious installer hijack.",
                            hexSnippet = zipHeaderHex,
                            targetCve = "CVE-2026-WAPP-POLY"
                        )
                    }
                }
            }
        }

        // Search for general APK patterns in files that shouldn't have them
        if (extension != "apk" && extension != "zip") {
            val zipIndex = findSequence(bytes, zipHeaderBytes)
            if (zipIndex != -1 && zipIndex > 100) { // If it's embedded deeper
                return ScanResult(
                    isSafe = false,
                    threatName = "Embedded Executable Payload",
                    details = "Detected hidden ZIP/APK binary signature inside a non-archive format (offset: $zipIndex).",
                    hexSnippet = zipHeaderHex,
                    targetCve = "CVE-2026-WAPP-POLY"
                )
            }
        }

        return ScanResult(isSafe = true)
    }

    /**
     * Checks metadata comments and EXIF fields for hidden scripts, base64 payloads, or command injections
     */
    private fun checkSteganographyAndMetadata(bytes: ByteArray): ScanResult {
        // Convert a sample of bytes or comment areas into text to check patterns
        val contentString = String(bytes, Charsets.US_ASCII)

        // Common exploit injections: base64 scripts, shell executors, suspicious comments
        val suspiciousPatterns = listOf(
            "UserComment=base64" to "Base64 payload injected in EXIF UserComment tag",
            "bin/sh" to "UNIX shell command execution string detected",
            "cmd.exe" to "Windows command executable command string detected",
            "eval(base64" to "JavaScript / Node evaluation exploit code detected",
            "dalvik/system" to "Dalvik classloader execution attempt detected",
            "runtime.getruntime" to "JVM Runtime execution command injected"
        )

        for ((pattern, explanation) in suspiciousPatterns) {
            if (contentString.contains(pattern, ignoreCase = true)) {
                return ScanResult(
                    isSafe = false,
                    threatName = "Metadata Steganography Exploit",
                    details = "$explanation. This bypasses routine signature scanners.",
                    hexSnippet = pattern.map { "%02x".format(it.code) }.joinToString("").take(16),
                    targetCve = "CVE-2026-WAPP-STEG"
                )
            }
        }

        return ScanResult(isSafe = true)
    }

    /**
     * Checks for specific Zero-Click structure vulnerabilities (e.g., malformed headers causing heap buffer overflows)
     */
    private fun checkZeroClickExploits(extension: String, bytes: ByteArray): ScanResult {
        if (extension == "webp") {
            // CVE-2023-4863 libwebp Lossless Huffmann Huffman tree buffer overflow
            // Look for malformed VP8L lossless bitstream (VP8L signature + suspicious Huffman parameters)
            val vp8lSig = byteArrayOf(0x56, 0x50, 0x38, 0x4C) // VP8L
            val vp8lIndex = findSequence(bytes, vp8lSig)
            if (vp8lIndex != -1 && vp8lIndex + 4 < bytes.size) {
                // Read bitstream sizes
                // In CVE-2023-4863, Huffman codes with excessive sizes (e.g., recursive depths) are built.
                // We simulate detection of a malformed VP8L header with extreme dimensions or out-of-bounds huffman sizes.
                val nextByte = bytes[vp8lIndex + 4].toInt() and 0xFF
                if (nextByte == 0xFF) { // Simulated exploit flag
                    return ScanResult(
                        isSafe = false,
                        threatName = "Zero-Click libwebp Exploit",
                        details = "Detected malformed Huffman lookup table sizes inside VP8L lossless bitstream. Exploits CVE-2023-4863 heap buffer overflow.",
                        hexSnippet = "5650384cff",
                        targetCve = "CVE-2023-4863"
                    )
                }
            }
        }

        if (extension == "png") {
            // CVE-2024-27818: PNG malicious chunk header causing integer overflow
            val iHdrSig = byteArrayOf(0x49, 0x48, 0x44, 0x52) // IHDR chunk
            val ihdrIndex = findSequence(bytes, iHdrSig)
            if (ihdrIndex != -1 && ihdrIndex + 8 < bytes.size) {
                // If IHDR specifies impossible or extremely bloated height/width triggering overflow
                val width = bytes.sliceArray(ihdrIndex + 4..ihdrIndex + 7).joinToString("") { "%02x".format(it) }
                if (width == "ffffffff" || width == "7fffffff") {
                    return ScanResult(
                        isSafe = false,
                        threatName = "Zero-Click PNG Integer Overflow",
                        details = "Detected malformed PNG IHDR block with size integer overflow vector ($width). Exploits CVE-2024-27818.",
                        hexSnippet = width,
                        targetCve = "CVE-2024-27818"
                    )
                }
            }
        }

        return ScanResult(isSafe = true)
    }

    private fun findSequence(data: ByteArray, pattern: ByteArray, startIndex: Int = 0): Int {
        if (data.isEmpty() || pattern.isEmpty() || startIndex >= data.size) return -1
        for (i in startIndex..data.size - pattern.size) {
            var found = true
            for (j in pattern.indices) {
                if (data[i + j] != pattern[j]) {
                    found = false
                    break
                }
            }
            if (found) return i
        }
        return -1
    }

    /**
     * Executes simulated quarantine. Moves a file logically into local DB representation
     * and deletes the physical file.
     */
    fun processThreat(file: File, result: ScanResult, simulatedBytes: ByteArray? = null) {
        scope.launch {
            val size = simulatedBytes?.size?.toLong() ?: if (file.exists()) file.length() else 1024L
            repository.quarantineFile(
                originalName = file.name,
                originalPath = file.absolutePath,
                fileSize = size,
                threatType = result.threatName,
                hexSnippet = result.hexSnippet,
                simulatedContent = simulatedBytes?.joinToString(",") ?: ""
            )

            // Delete actual file to prevent auto-download from triggering the WhatsApp viewer
            if (file.exists() && file.isFile) {
                file.delete()
            }
        }
    }
}
