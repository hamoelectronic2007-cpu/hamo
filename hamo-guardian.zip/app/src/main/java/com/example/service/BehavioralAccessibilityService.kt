package com.example.service

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.example.data.database.AppDatabase
import com.example.data.repository.SecurityRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Modern simulated Accessibility service concept.
 * Tracks screen actions within the WhatsApp package structure to analyze behavioral anomaly detection.
 * Monitors message send frequency and group activity to warn about ban-risk behavior patterns.
 */
class BehavioralAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var repository: SecurityRepository? = null

    // Behavioral state variables
    private var lastSendTime: Long = 0
    private var sendCountInPeriod: Int = 0
    private val THROTTLE_PERIOD_MS = 60000 // 1 minute
    private val WARNING_SEND_LIMIT = 5 // Simulating threshold for WhatsApp automated spam detection

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getDatabase(this)
        repository = SecurityRepository(database.securityDao())
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent) {
        val packageName = event.packageName?.toString() ?: return

        // We only analyze interactions inside WhatsApp
        if (packageName == "com.whatsapp" || packageName == "com.whatsapp.w4b") {
            val eventType = event.eventType

            // Case A: User clicks buttons (like Send, Create Group, Join Group)
            if (eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                val nodeInfo = event.source ?: return
                analyzeNode(nodeInfo)
            }

            // Case B: Read window content or notifications for BAN warning notifications
            if (eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED) {
                val rootNode = rootInActiveWindow ?: return
                scanForBanWarnings(rootNode)
            }
        }
    }

    private fun analyzeNode(node: AccessibilityNodeInfo) {
        val resourceName = node.viewIdResourceName ?: ""
        val text = node.text?.toString() ?: ""

        // WhatsApp Send Button ID is typically "send" or displays text indicators
        if (resourceName.contains("send", ignoreCase = true) || text.contains("إرسال", ignoreCase = true) || text.contains("Send", ignoreCase = true)) {
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastSendTime < THROTTLE_PERIOD_MS) {
                sendCountInPeriod++
            } else {
                sendCountInPeriod = 1
                lastSendTime = currentTime
            }

            if (sendCountInPeriod >= WARNING_SEND_LIMIT) {
                triggerBehaviorWarning(
                    title = "Automated Spammer Warning",
                    message = "You have sent $sendCountInPeriod messages in 60s. WhatsApp algorithms flag rapid sending as spam bots, leading to temporary or permanent bans."
                )
            }
        }

        // WhatsApp New Group Creation ID
        if (text.contains("New group", ignoreCase = true) || text.contains("مجموعة جديدة", ignoreCase = true)) {
            logBehaviorEvent("Group Activity", "Clicked New Group button. Frequent group creation increases ban risk.")
        }
    }

    private fun scanForBanWarnings(node: AccessibilityNodeInfo) {
        val text = node.text?.toString() ?: ""
        if (text.contains("Your phone number is banned", ignoreCase = true) ||
            text.contains("تم حظر رقم هاتفك", ignoreCase = true) ||
            text.contains("temporarily banned", ignoreCase = true) ||
            text.contains("محظور مؤقتًا", ignoreCase = true)) {

            triggerBehaviorWarning(
                title = "ACCOUNT BAN DETECTED!",
                message = "WhatsApp has flagged your account with a ban message. Follow HamO Guardian guidelines immediately to request a formal appeal."
            )
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i)
            if (child != null) {
                scanForBanWarnings(child)
            }
        }
    }

    private fun triggerBehaviorWarning(title: String, message: String) {
        Log.w("BehavioralService", "🚨 WARNING: $title - $message")
        scope.launch {
            repository?.insertLog(
                eventType = "ALERT",
                message = title,
                details = message,
                severity = "Critical"
            )
        }
    }

    private fun logBehaviorEvent(category: String, message: String) {
        scope.launch {
            repository?.insertLog(
                eventType = "SCAN",
                message = "$category Monitor",
                details = message,
                severity = "Warning"
            )
        }
    }

    override fun onInterrupt() {
        Log.i("BehavioralService", "Service Interrupted")
    }
}
