package com.example.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.os.FileObserver
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.data.database.AppDatabase
import com.example.data.repository.SecurityRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File

/**
 * Foreground Service running the active shield.
 * Spawns a FileObserver pointing directly to the WhatsApp media folders on disk,
 * analyzing newly arrived files in real-time.
 */
class ActiveShieldService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO)
    private lateinit var repository: SecurityRepository
    private lateinit var scanner: ScanningEngine
    private var whatsappObserver: WhatsAppMediaObserver? = null

    private val CHANNEL_ID = "active_shield_channel"
    private val NOTIFICATION_ID = 918

    override fun onCreate() {
        super.onCreate()
        val database = AppDatabase.getDatabase(this)
        repository = SecurityRepository(database.securityDao())
        scanner = ScanningEngine(repository)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Active monitoring armed. Watching WhatsApp media directories."))

        // Start watching the common WhatsApp media directory
        setupFileObserver()
    }

    private fun setupFileObserver() {
        // Path on typical device is /storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/
        val sdcard = Environment.getExternalStorageDirectory()
        val whatsAppMediaDir = File(sdcard, "Android/media/com.whatsapp/WhatsApp/Media")

        if (!whatsAppMediaDir.exists()) {
            whatsAppMediaDir.mkdirs()
        }

        whatsappObserver = WhatsAppMediaObserver(whatsAppMediaDir.absolutePath) { file ->
            serviceScope.launch {
                Log.d("ActiveShield", "New file captured: ${file.absolutePath}")
                val result = scanner.scanFile(file)
                if (!result.isSafe) {
                    scanner.processThreat(file, result)
                    showThreatNotification(file.name, result)
                } else {
                    repository.insertLog(
                        eventType = "SCAN",
                        message = "Scanned file: ${file.name}",
                        details = "File is clean. Verified magic signatures, zero-click patterns, and polyglots.",
                        severity = "Info"
                    )
                }
            }
        }
        whatsappObserver?.startWatching()
    }

    private fun showThreatNotification(fileName: String, result: ScanningEngine.ScanResult) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val intent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_notify_error)
            .setContentTitle("🛡️ THREAT BLOCKED: $fileName")
            .setContentText("Isolated threat payload matching ${result.targetCve}. Click for details.")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    private fun buildNotification(text: String) = NotificationCompat.Builder(this, CHANNEL_ID)
        .setContentTitle("HamO Guardian Active Shield")
        .setContentText(text)
        .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
        .setOngoing(true)
        .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "Active Shield Monitoring Service Channel",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onDestroy() {
        whatsappObserver?.stopWatching()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    /**
     * FileObserver to watch folder creation or modification inside WhatsApp folders
     */
    private class WhatsAppMediaObserver(
        path: String,
        private val onFileAdded: (File) -> Unit
    ) : FileObserver(path, CREATE or MODIFY or MOVED_TO) {

        override fun onEvent(event: Int, path: String?) {
            if (path != null) {
                val file = File(path)
                onFileAdded(file)
            }
        }
    }
}
