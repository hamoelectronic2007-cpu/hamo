package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.center
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.R
import com.example.data.SecurityLog
import com.example.data.VaultItem
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.delay
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext

// Helper modifier to draw a technical HUD-style frame on cards
fun Modifier.hudBorder(color: Color = TechPurple, glowColor: Color = NeonCyan) = this.drawBehind {
    val strokeWidth = 1.dp.toPx()
    val length = 12.dp.toPx()

    // Draw full outer subtle outline
    drawRect(color = color.copy(alpha = 0.25f), style = Stroke(width = strokeWidth))

    // Draw high-visibility corner brackets
    // Top-Left corner
    drawLine(color = glowColor, start = Offset(0f, 0f), end = Offset(length, 0f), strokeWidth = strokeWidth * 2.5f)
    drawLine(color = glowColor, start = Offset(0f, 0f), end = Offset(0f, length), strokeWidth = strokeWidth * 2.5f)

    // Top-Right corner
    drawLine(color = glowColor, start = Offset(size.width, 0f), end = Offset(size.width - length, 0f), strokeWidth = strokeWidth * 2.5f)
    drawLine(color = glowColor, start = Offset(size.width, 0f), end = Offset(size.width, length), strokeWidth = strokeWidth * 2.5f)

    // Bottom-Left corner
    drawLine(color = glowColor, start = Offset(0f, size.height), end = Offset(length, size.height), strokeWidth = strokeWidth * 2.5f)
    drawLine(color = glowColor, start = Offset(0f, size.height), end = Offset(0f, size.height - length), strokeWidth = strokeWidth * 2.5f)

    // Bottom-Right corner
    drawLine(color = glowColor, start = Offset(size.width, size.height), end = Offset(size.width - length, size.height), strokeWidth = strokeWidth * 2.5f)
    drawLine(color = glowColor, start = Offset(size.width, size.height), end = Offset(size.width, size.height - length), strokeWidth = strokeWidth * 2.5f)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HamoShieldScreen(
    viewModel: HamoShieldViewModel,
    modifier: Modifier = Modifier
) {
    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isIntegrityCompromised by viewModel.isIntegrityCompromised.collectAsState()
    val integrityCompromiseReason by viewModel.integrityCompromiseReason.collectAsState()
    val isEmulatorWarningActive by viewModel.isEmulatorWarningActive.collectAsState()
    val isAdbDetected by viewModel.isAdbDetected.collectAsState()
    val context = LocalContext.current

    // 0 = Dashboard, 1 = Stealth Radar, 2 = Proxy/VPN, 3 = Secure Vault, 4 = Tools/SMS, 5 = Settings
    var activeTab by remember { mutableStateOf(0) }
    var showSplashScreen by remember { mutableStateOf(true) }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = BgPrimary
    ) {
        if (showSplashScreen) {
            HamoWelcomeSplashScreen(viewModel = viewModel) {
                if (!isUserLoggedIn) {
                    viewModel.loginAsGuest()
                }
                showSplashScreen = false
            }
        } else if (isIntegrityCompromised) {
            IntegrityCompromisedScreen(reason = integrityCompromiseReason)
        } else if (isEmulatorWarningActive) {
            EmulatorBlockerScreen {
                (context as? android.app.Activity)?.finish()
                System.exit(0)
            }
        } else if (!isUserLoggedIn) {
            AuthScreen(viewModel = viewModel)
        } else if (!isSubscribed) {
            SubscriptionGateScreen(viewModel = viewModel)
        } else {
            // Main application HUD shell
            Scaffold(
                containerColor = BgPrimary,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Hamo Shield Alpha V6 Logo",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "حمو الإلكتروني - الدرع السيبراني",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = BgSecondary
                        ),
                        modifier = Modifier.border(0.dp, TechPurple.copy(alpha = 0.2f), RectangleShape)
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = BgSecondary,
                        modifier = Modifier
                            .windowInsetsPadding(WindowInsets.navigationBars)
                            .border(1.dp, TechPurple.copy(alpha = 0.15f), RectangleShape)
                    ) {
                        NavigationBarItem(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية", tint = if (activeTab == 0) NeonCyan else TextSecondary) },
                            label = { Text("الرئيسية", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            icon = { Icon(Icons.Default.Search, contentDescription = "الرادار", tint = if (activeTab == 1) NeonCyan else TextSecondary) },
                            label = { Text("الرادار", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            icon = { Icon(Icons.Default.Refresh, contentDescription = "بروكسي", tint = if (activeTab == 2) NeonCyan else TextSecondary) },
                            label = { Text("البروكسي", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 3,
                            onClick = { activeTab = 3 },
                            icon = { Icon(Icons.Default.Lock, contentDescription = "الخزنة", tint = if (activeTab == 3) NeonCyan else TextSecondary) },
                            label = { Text("الخزنة", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 4,
                            onClick = { activeTab = 4 },
                            icon = { Icon(Icons.Default.Build, contentDescription = "الأدوات", tint = if (activeTab == 4) NeonCyan else TextSecondary) },
                            label = { Text("الأدوات", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 5,
                            onClick = { activeTab = 5 },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "الإعدادات", tint = if (activeTab == 5) NeonCyan else TextSecondary) },
                            label = { Text("الإعدادات", fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan.copy(alpha = 0.15f),
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .padding(innerPadding)
                        .fillMaxSize()
                        .background(BgPrimary)
                ) {
                    Crossfade(
                        targetState = activeTab,
                        animationSpec = spring(),
                        label = "TabReveal"
                    ) { tab ->
                        when (tab) {
                            0 -> DashboardTab(viewModel = viewModel)
                            1 -> RadarTab(viewModel = viewModel)
                            2 -> ProxyTab(viewModel = viewModel)
                            3 -> VaultTab(viewModel = viewModel)
                            4 -> ToolsTab(viewModel = viewModel)
                            5 -> SettingsTab(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(viewModel: HamoShieldViewModel) {
    val context = LocalContext.current
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var hasError by remember { mutableStateOf(false) }

    var isGoogleLoggingIn by remember { mutableStateOf(false) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            isGoogleLoggingIn = true
            val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
                val idToken = account?.idToken
                if (!idToken.isNullOrEmpty()) {
                    viewModel.signInWithGoogleIdToken(
                        idToken = idToken,
                        onSuccess = { email ->
                            isGoogleLoggingIn = false
                            android.widget.Toast.makeText(context, "تم تسجيل الدخول: $email", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        onFailure = { e ->
                            // Fallback to offline/mock if custom server credentials are not ready
                            isGoogleLoggingIn = false
                            val googleEmail = account.email ?: "user.hamo@gmail.com"
                            viewModel.googleSignIn(googleEmail)
                            android.widget.Toast.makeText(context, "تسجيل دخول محلي: $googleEmail (خوادم غير مهيأة)", android.widget.Toast.LENGTH_LONG).show()
                        }
                    )
                } else {
                    isGoogleLoggingIn = false
                    val googleEmail = account?.email ?: "user.hamo@gmail.com"
                    viewModel.googleSignIn(googleEmail)
                }
            } catch (e: Exception) {
                isGoogleLoggingIn = false
                viewModel.googleSignIn("user.hamo@gmail.com")
            }
        }
    }

    // Floating diagnostic beam animation
    val infiniteTransition = rememberInfiniteTransition(label = "Laser")
    val laserYOffset by infiniteTransition.animateFloat(
        initialValue = -10f,
        targetValue = 150f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LaserBeam"
    )

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(BgPrimary)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(24.dp))

        // Image container with military HUD diagonal line
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .hudBorder(TechPurple, NeonCyan)
                .clip(RoundedCornerShape(8.dp))
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_sec_hud),
                contentDescription = "Hamo Cyber Armored HUD",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )

            // Dynamic Scanning Line overlaying the Image
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(2.dp)
                    .offset(y = laserYOffset.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, NeonCyan, Color.Transparent)
                        )
                    )
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = "Hamo Cyber Armored Shield",
            tint = NeonCyan,
            modifier = Modifier
                .size(64.dp)
                .drawBehind {
                    drawCircle(color = NeonCyan.copy(alpha = 0.15f), radius = size.minDimension * 0.8f)
                }
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "ابليكيشن حمو الإلكتروني",
            color = TextPrimary,
            fontSize = 22.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.5.sp,
            modifier = Modifier.padding(bottom = 4.dp),
            textAlign = TextAlign.Center
        )
        Text(
            "الدرع السيبراني المطلق لحماية جهازك",
            color = TechPurple,
            fontSize = 13.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 28.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .hudBorder(TechPurple.copy(alpha = 0.6f), NeonCyan.copy(alpha = 0.4f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "تسجيل الدخول للنظام الفرعي الآمن",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; hasError = false },
                    label = { Text("البريد الإلكتروني للهيكل المشفر", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = TextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = TechPurple.copy(alpha = 0.5f),
                        focusedContainerColor = BgPrimary,
                        unfocusedContainerColor = BgPrimary
                    )
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; hasError = false },
                    label = { Text("مفتاح التحقق العسكري (Password)", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = TextPrimary),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = TechPurple.copy(alpha = 0.5f),
                        focusedContainerColor = BgPrimary,
                        unfocusedContainerColor = BgPrimary
                    )
                )

                if (hasError) {
                    Text(
                        "⚠️ خطأ أمني: تأكد من إدخال بريد صالح ومفتاح يفوق 7 أحرف.",
                        color = DangerRed,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                var isMailLoggingIn by remember { mutableStateOf(false) }

                if (isMailLoggingIn || isGoogleLoggingIn) {
                    Box(modifier = Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(28.dp))
                    }
                } else {
                    Button(
                        onClick = {
                            isMailLoggingIn = true
                            viewModel.firebaseLoginWithEmail(
                                email = email,
                                pass = password,
                                onSuccess = {
                                    isMailLoggingIn = false
                                },
                                onFailure = { e ->
                                    isMailLoggingIn = false
                                    hasError = true
                                }
                            )
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("دخول معزول TLS 🔐", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                    }

                    HorizontalDivider(color = TechPurple.copy(alpha = 0.25f))

                    Button(
                        onClick = {
                            val clientID = try { com.example.BuildConfig.FIREBASE_WEB_CLIENT_ID } catch(e: Exception) { "" }
                            val gsoBuilder = com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(
                                com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN
                            ).requestEmail()
                            if (clientID.isNotEmpty() && clientID != "YOUR_FIREBASE_WEB_CLIENT_ID") {
                                gsoBuilder.requestIdToken(clientID)
                            }
                            val client = com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(context, gsoBuilder.build())
                            googleSignInLauncher.launch(client.signInIntent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.8f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Google Secure Auth",
                                tint = NeonCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تسجيل دخول آمن بواسطة Google", color = NeonCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Button(
                        onClick = {
                            viewModel.loginAsGuest()
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = BgSecondary),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.8f))
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Guest Login",
                                tint = TechPurple,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("الدخول السريع كضيف (تخطي التحقق) 🛡️", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
fun WalletRedirectionDialog(selectedPlan: String, onDismiss: () -> Unit, onWalletSelected: (String) -> Unit) {
    val context = LocalContext.current
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .hudBorder(NeonCyan, TechPurple)
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text("توجيه تلقائي لتطبيقات المحفظة", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                Text("اختر تطبيق المحفظة لإطلاق اتصال النقل المباشر USSD لخدمات كاش:", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, modifier = Modifier.padding(vertical = 6.dp))

                Spacer(modifier = Modifier.height(8.dp))

                val amount = if (selectedPlan == "YEARLY") 140 else 75
                val wallets = listOf(
                    Triple("Orange Cash (أورنج)", "*7115*1*01228135423*${amount}#", "com.orange.eg.orangecash"),
                    Triple("Vodafone Cash (فودافون)", "*9*7*01228135423*${amount}#", "com.emeint.android.myservices"),
                    Triple("Etisalat Cash (اتصالات)", "*777#", "com.etisalat.myetisalat"),
                    Triple("WE Pay (وي باي)", "*9#", "com.te.wepay")
                )

                Column(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    wallets.forEach { wallet ->
                        val isInstalled = try {
                            context.packageManager.getPackageInfo(wallet.third, 0)
                            true
                        } catch (e: Exception) {
                            false
                        }

                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onWalletSelected(wallet.second) }
                                .border(1.dp, TechPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (isInstalled) {
                                        Text(
                                            "تطبيق مثبت ✔",
                                            color = SafeGreen,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace,
                                            fontWeight = FontWeight.Bold
                                        )
                                    } else {
                                        Text(
                                            "محاكاة الاتصال 📞",
                                            color = NeonCyan,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }
                                }
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(wallet.first, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Text("كود الاتصال: ${wallet.second}", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace)
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().height(36.dp)
                ) {
                    Text("إلغاء التوجيه", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun DeveloperDashboardDialog(viewModel: HamoShieldViewModel, onDismiss: () -> Unit) {
    val paymentRequests by viewModel.paymentRequests.collectAsState()
    val telegramLogs by viewModel.telegramLogs.collectAsState()
    val emailLogs by viewModel.emailLogs.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()

    var activeSubTab by remember { mutableStateOf(0) } // 0 = Transactions, 1 = Financial Reports, 2 = Notification Logs, 3 = Inject Simulator

    // For Simulator Injector
    var simName by remember { mutableStateOf("يوسف أحمد") }
    var simEmail by remember { mutableStateOf("youssef.cyber@gmail.com") }
    var simPhoneOrEmail by remember { mutableStateOf("01129938812") }
    var simAmount by remember { mutableStateOf("75 ج.م") }
    var simMethod by remember { mutableStateOf("أورنج كاش") }
    var simText by remember { mutableStateOf("أورنج كاش - تحويل ناجح 75 ج.م إلى 01228135423") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .hudBorder(NeonCyan, TechPurple)
                .padding(4.dp)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = DangerRed)
                    }
                    Text(
                        "بوابة تحكم المطور الأمنية V6",
                        color = NeonCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Dashboard sub-tabs
                Row(
                    modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    val tabs = listOf("المعاملات", "التقارير والتحليل", "سجلات الإشعارات", "حقن محاكاة")
                    tabs.forEachIndexed { index, title ->
                        val isSelected = activeSubTab == index
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected) TechPurple.copy(alpha = 0.3f) else BgPrimary
                            ),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (isSelected) NeonCyan else TechPurple.copy(alpha = 0.2f)),
                            modifier = Modifier
                                .clickable { activeSubTab = index }
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                title,
                                color = if (isSelected) NeonCyan else TextSecondary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = TechPurple.copy(alpha = 0.25f))
                Spacer(modifier = Modifier.height(12.dp))

                // Contents
                Box(modifier = Modifier.weight(1f)) {
                    when (activeSubTab) {
                        0 -> {
                            // Transactions List
                            Column(modifier = Modifier.fillMaxSize()) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Button(
                                        onClick = { viewModel.suspendUserSubscription() },
                                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                        shape = RoundedCornerShape(4.dp),
                                        modifier = Modifier.height(30.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp)
                                    ) {
                                        Text("تعليق اشتراك العميل 🔒", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                    }
                                    Text("سجل الدفع والتحويلات (${paymentRequests.size}):", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                if (paymentRequests.isEmpty()) {
                                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Text("لا يوجد طلبات دفع حتى الآن.", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                } else {
                                    LazyColumn(
                                        verticalArrangement = Arrangement.spacedBy(8.dp),
                                        modifier = Modifier.fillMaxSize()
                                    ) {
                                        items(paymentRequests) { req ->
                                            Card(
                                                colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                                modifier = Modifier.fillMaxWidth().border(1.dp, TechPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                            ) {
                                                Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.End) {
                                                    Row(
                                                        modifier = Modifier.fillMaxWidth(),
                                                        horizontalArrangement = Arrangement.SpaceBetween
                                                    ) {
                                                        Card(
                                                            colors = CardDefaults.cardColors(
                                                                containerColor = when (req.status) {
                                                                    "APPROVED" -> SafeGreen.copy(alpha = 0.15f)
                                                                    "REJECTED" -> DangerRed.copy(alpha = 0.15f)
                                                                    else -> WarningAmber.copy(alpha = 0.15f)
                                                                }
                                                            ),
                                                            shape = RoundedCornerShape(4.dp)
                                                        ) {
                                                            Text(
                                                                text = when (req.status) {
                                                                    "APPROVED" -> "مقبول ✓"
                                                                    "REJECTED" -> "مرفوض ❌"
                                                                    else -> "معلق ⏳"
                                                                },
                                                                color = when (req.status) {
                                                                    "APPROVED" -> SafeGreen
                                                                    "REJECTED" -> DangerRed
                                                                    else -> WarningAmber
                                                                },
                                                                fontSize = 9.sp,
                                                                fontFamily = FontFamily.Monospace,
                                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                            )
                                                        }
                                                        Text(req.id, color = NeonCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                                    }
                                                    Spacer(modifier = Modifier.height(4.dp))
                                                    Text("العميل: ${req.userName} (${req.userEmail})", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                                    Text("المحول منه: ${req.senderPhoneOrEmail}", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                                    Text("المبلغ: ${req.amount} | الطريقة: ${req.method}", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                                    Text("التاريخ: ${req.date} | الفحص: ${if(req.verificationType == "AUTO_OCR") "آلي OCR ⚡" else "يدوي 👤"}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                    
                                                    Spacer(modifier = Modifier.height(6.dp))
                                                    Box(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .background(BgSecondary)
                                                            .padding(6.dp)
                                                            .border(0.5.dp, TechPurple.copy(alpha = 0.15f))
                                                    ) {
                                                        Text("نص لقطة الشاشة: ${req.screenshotText}", color = TextSecondary, fontSize = 8.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
                                                    }

                                                    if (req.status == "PENDING") {
                                                        Spacer(modifier = Modifier.height(8.dp))
                                                        Row(
                                                            modifier = Modifier.fillMaxWidth(),
                                                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                                                        ) {
                                                            Button(
                                                                onClick = { viewModel.manualRejectTransaction(req.id) },
                                                                colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                                                                shape = RoundedCornerShape(4.dp),
                                                                modifier = Modifier.weight(1f).height(28.dp),
                                                                contentPadding = PaddingValues(0.dp)
                                                            ) {
                                                                Text("رفض ❌", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                            }
                                                            Button(
                                                                onClick = { viewModel.manualApproveTransaction(req.id) },
                                                                colors = ButtonDefaults.buttonColors(containerColor = SafeGreen),
                                                                shape = RoundedCornerShape(4.dp),
                                                                modifier = Modifier.weight(1f).height(28.dp),
                                                                contentPadding = PaddingValues(0.dp)
                                                            ) {
                                                                Text("قبول وتفعيل ✔", color = BgPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        1 -> {
                            // Financial Reports and charts
                            Column(
                                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.End
                            ) {
                                Text("التحليلات والمكاسب المالية", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        modifier = Modifier.weight(1f).border(1.dp, TechPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("الإيراد السنوي التقديري", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text("12,500 ج.م", color = SafeGreen, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        modifier = Modifier.weight(1f).border(1.dp, TechPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                            Text("الإيراد الشهري الفعلي", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            Text("1,425 ج.م", color = NeonCyan, fontSize = 14.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                Text("توزيع الاشتراكات والخطط السحابية:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(8.dp))

                                // Render simulated chart
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                    modifier = Modifier.fillMaxWidth().border(1.dp, TechPurple.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text("معدل تفعيل الخطط:", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        Spacer(modifier = Modifier.height(10.dp))
                                        
                                        // Monthly Line
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Text("65%", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(30.dp))
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(10.dp)
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(BgSecondary)
                                            ) {
                                                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(0.65f).background(NeonCyan))
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("الباقات الشهرية", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(75.dp), textAlign = TextAlign.Right)
                                        }
                                        
                                        Spacer(modifier = Modifier.height(8.dp))
                                        
                                        // Yearly Line
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Text("20%", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(30.dp))
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(10.dp)
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(BgSecondary)
                                            ) {
                                                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(0.20f).background(TechPurple))
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("الباقات السنوية", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(75.dp), textAlign = TextAlign.Right)
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        // Trial Line
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                                            Text("15%", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(30.dp))
                                            Box(
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .height(10.dp)
                                                    .clip(RoundedCornerShape(5.dp))
                                                    .background(BgSecondary)
                                            ) {
                                                Box(modifier = Modifier.fillMaxHeight().fillMaxWidth(0.15f).background(WarningAmber))
                                            }
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("التجريبي المجاني", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(75.dp), textAlign = TextAlign.Right)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))
                                Text("تفصيل الأداء والموثوقية العائلية:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                Text("• إجمالي الحسابات المسجلة: 142 حساب نشط\n" +
                                     "• نسبة نجاح التحقق التلقائي بـ OCR: 89.4%\n" +
                                     "• الشكاوى وبلاغات الدعم الفني: 0 بلاغات حالياً\n" +
                                     "• الحظر ومكافحة الاحتيال: تم حظر 3 محاولات تعديل تاريخ محلي.",
                                    color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, lineHeight = 18.sp
                                )
                            }
                        }
                        2 -> {
                            // Notifications dispatch logs (Telegram / SMTP)
                            Column(modifier = Modifier.fillMaxSize()) {
                                Text("قناة البث الآلي للمستقبلات والمطور (Live Webhooks Log):", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(10.dp))
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                    modifier = Modifier.weight(1f).fillMaxWidth().border(1.dp, TechPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                ) {
                                    LazyColumn(modifier = Modifier.padding(8.dp)) {
                                        item {
                                            Text("--- سجلات إرسال تليجرام البوت المباشرة ---", color = NeonCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        if (telegramLogs.isEmpty()) {
                                            item {
                                                Text("لم يتم إطلاق أي إشعارات بوت تليجرام جديدة حتى الآن. ارفع معاملة لإطلاق تليجرام آلياً.", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        } else {
                                            items(telegramLogs) { log ->
                                                Text(
                                                    text = log,
                                                    color = TextPrimary,
                                                    fontSize = 8.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    modifier = Modifier.padding(vertical = 4.dp).border(0.5.dp, TechPurple.copy(alpha = 0.15f)).padding(4.dp)
                                                )
                                            }
                                        }
                                        item {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Text("--- سجلات البريد السحابي SMTP / SendGrid ---", color = WarningAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                        }
                                        if (emailLogs.isEmpty()) {
                                            item {
                                                Text("لم يتم إرسال إشعارات بريد SMTP بعد.", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        } else {
                                            items(emailLogs) { log ->
                                                Text(
                                                    text = log,
                                                    color = TextPrimary,
                                                    fontSize = 8.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    modifier = Modifier.padding(vertical = 4.dp).border(0.5.dp, TechPurple.copy(alpha = 0.15f)).padding(4.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        3 -> {
                            // Inject simulator transaction
                            Column(
                                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
                                horizontalAlignment = Alignment.End,
                                verticalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Text("محاكاة حقن معاملة دفع خارجية بالكامل:", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                Text("هذه الشاشة مخصصة لاختبار نظام الإرسال البصري OCR والتنبيهات المباشرة دون الحاجة لرفع حقيقي.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = if (simMethod == "أورنج كاش") TechPurple.copy(alpha = 0.25f) else BgPrimary),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f).clickable { 
                                            simMethod = "أورنج كاش"
                                            simAmount = "75 ج.م"
                                            simText = "أورنج كاش - تحويل ناجح 75 ج.م إلى 01228135423"
                                        }
                                    ) {
                                        Text("أورنج كاش", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(10.dp).fillMaxWidth(), textAlign = TextAlign.Center)
                                    }
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = if (simMethod == "PayPal") TechPurple.copy(alpha = 0.25f) else BgPrimary),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f).clickable { 
                                            simMethod = "PayPal"
                                            simAmount = "5.00 USD"
                                            simText = "PayPal Express - Completed 5.00 USD to hamo.electronic@example.com"
                                        }
                                    ) {
                                        Text("PayPal", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(10.dp).fillMaxWidth(), textAlign = TextAlign.Center)
                                    }
                                }

                                OutlinedTextField(
                                    value = simName,
                                    onValueChange = { simName = it },
                                    label = { Text("اسم العميل", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary)
                                )

                                OutlinedTextField(
                                    value = simEmail,
                                    onValueChange = { simEmail = it },
                                    label = { Text("البريد الإلكتروني للعميل", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary)
                                )

                                OutlinedTextField(
                                    value = simPhoneOrEmail,
                                    onValueChange = { simPhoneOrEmail = it },
                                    label = { Text("رقم هاتف المرسل أو بريده", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary)
                                )

                                OutlinedTextField(
                                    value = simAmount,
                                    onValueChange = { simAmount = it },
                                    label = { Text("المبلغ والمستند المالي", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary)
                                )

                                OutlinedTextField(
                                    value = simText,
                                    onValueChange = { simText = it },
                                    label = { Text("النص المستخرج OCR لتدريب المحاكي", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary)
                                )

                                Button(
                                    onClick = {
                                        viewModel.simulateIncomingRequest(
                                            userName = simName,
                                            email = simEmail,
                                            amount = simAmount,
                                            phoneOrEmail = simPhoneOrEmail,
                                            method = simMethod,
                                            text = simText
                                        )
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text("حقن وإرسال إشعارات التنبيه المباشر ⚡", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriptionGateScreen(viewModel: HamoShieldViewModel) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val joinedYoutube by viewModel.joinedYoutube.collectAsState()
    val joinedTelegram by viewModel.joinedTelegram.collectAsState()
    val joinedFacebook by viewModel.joinedFacebook.collectAsState()
    val trialDaysRemaining by viewModel.trialDaysRemaining.collectAsState()
    val isTrialActive by viewModel.isTrialActive.collectAsState()

    val selectedPlan by viewModel.selectedPlan.collectAsState()
    val selectedPaymentMethod by viewModel.selectedPaymentMethod.collectAsState()
    val scanState by viewModel.scanState.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()

    var billingPhone by remember { mutableStateOf("") }
    var selectedMockScreenshot by remember { mutableStateOf("") }
    var selectedImageUri by remember { mutableStateOf<Uri?>(null) }
    
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        selectedImageUri = uri
        if (uri != null) {
            selectedMockScreenshot = "صورة مرفوعة: " + (uri.lastPathSegment ?: "إثبات_دفع.jpg")
        }
    }
    
    var showDeveloperDashboard by remember { mutableStateOf(false) }
    var showDeveloperLogin by remember { mutableStateOf(false) }
    var showWalletDialog by remember { mutableStateOf(false) }

    // Predefined Realistic Screenshots to choose from
    val mockScreenshots = listOf(
        "أورنج كاش - تحويل ناجح 75 ج.م إلى 01228135423",
        "أورنج كاش - تحويل ناجح 140 ج.م إلى 01228135423",
        "PayPal Express - Completed 5.00 USD to hamo.electronic@example.com",
        "شكراً/انتساب يوتيوب - تحويل ناجح 140 ج.م إلى قناة حمو المطور",
        "أورنج كاش - تحويل ناجح 10 ج.م إلى 01228135423"
    )

    if (showDeveloperLogin) {
        DeveloperLoginDialog(
            onDismiss = { showDeveloperLogin = false },
            onSuccess = {
                showDeveloperLogin = false
                showDeveloperDashboard = true
            }
        )
    }

    if (showDeveloperDashboard) {
        DeveloperDashboardDialog(viewModel = viewModel, onDismiss = { showDeveloperDashboard = false })
    }

    if (showWalletDialog) {
        WalletRedirectionDialog(
            selectedPlan = selectedPlan,
            onDismiss = { showWalletDialog = false },
            onWalletSelected = { ussdCode ->
                showWalletDialog = false
                try {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(ussdCode)))
                    context.startActivity(intent)
                } catch (e: Exception) {
                    // Fallback
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .background(BgPrimary)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(10.dp))
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = "Subscription Shield lock",
            tint = DangerRed,
            modifier = Modifier
                .size(60.dp)
                .drawBehind {
                    drawCircle(color = DangerRed.copy(alpha = 0.15f), radius = size.minDimension * 0.75f)
                }
        )
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            "معقل حمو الإلكتروني مغلق - تفعيل الحماية الفولاذية",
            color = TextPrimary,
            fontSize = 16.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )
        Text(
            "الهاتف غير مرخص | الدرع السيبراني معطل حالياً",
            color = TextSecondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        // Social gate checks if joined
        if (!joinedYoutube || !joinedTelegram || !joinedFacebook) {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp).border(1.dp, TechPurple.copy(alpha = 0.3f), RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                    Text("الخطوة 1: انضم لمنصات حمو الإلكتروني الرسمية", color = NeonCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                    Text("يتطلب تفعيل النظام الانضمام لقنواتنا الرسمية كشرط أولي:", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.setJoinedSocial("youtube")
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic2007"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (joinedYoutube) SafeGreen else BgPrimary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(0.dp),
                            border = BorderStroke(1.dp, if (joinedYoutube) SafeGreen else DangerRed.copy(alpha = 0.5f))
                        ) {
                            Text(if (joinedYoutube) "✓" else "يوتيوب 📺", fontSize = 10.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = {
                                viewModel.setJoinedSocial("telegram")
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/hamoelctronic2007"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (joinedTelegram) SafeGreen else BgPrimary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(0.dp),
                            border = BorderStroke(1.dp, if (joinedTelegram) SafeGreen else NeonCyan.copy(alpha = 0.5f))
                        ) {
                            Text(if (joinedTelegram) "✓" else "تيليجرام 🛡️", fontSize = 10.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = {
                                viewModel.setJoinedSocial("facebook")
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com/groups/hamoelectronic2007"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = if (joinedFacebook) SafeGreen else BgPrimary),
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(0.dp),
                            border = BorderStroke(1.dp, if (joinedFacebook) SafeGreen else TechPurple.copy(alpha = 0.5f))
                        ) {
                            Text(if (joinedFacebook) "✓" else "فيسبوك 👥", fontSize = 10.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // 1. Plan Selectors
        Text(
            "اختر خطة الاشتراك والترخيص المناسبة لحمايتك:",
            color = NeonCyan,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.align(Alignment.End).padding(bottom = 6.dp)
        )
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            // Plan 1: Trial
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedPlan == "TRIAL") TechPurple.copy(alpha = 0.25f) else BgSecondary
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (selectedPlan == "TRIAL") NeonCyan else TechPurple.copy(alpha = 0.2f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectPlan("TRIAL") }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "متاح",
                        color = SafeGreen,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text("الفترة التجريبية (7 أيام)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("الوصول المجاني الكامل للدرع مؤقتاً | المتبقي: $trialDaysRemaining أيام", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Plan 2: Monthly
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedPlan == "MONTHLY") TechPurple.copy(alpha = 0.25f) else BgSecondary
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (selectedPlan == "MONTHLY") NeonCyan else TechPurple.copy(alpha = 0.2f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectPlan("MONTHLY") }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "75 جنيه / 5 دولار",
                        color = NeonCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Column(horizontalAlignment = Alignment.End) {
                        Text("الاشتراك الشهري العسكري", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("تأمين كامل ضد ثغرات Zero-Day والتعقب والتهديدات العميقة", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }

            // Plan 3: Yearly
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (selectedPlan == "YEARLY") TechPurple.copy(alpha = 0.25f) else BgSecondary
                ),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, if (selectedPlan == "YEARLY") NeonCyan else TechPurple.copy(alpha = 0.2f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.selectPlan("YEARLY") }
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Card(colors = CardDefaults.cardColors(containerColor = DangerRed), shape = RoundedCornerShape(4.dp)) {
                        Text("عرض خارق 🔥", color = TextPrimary, fontSize = 8.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("الترخيص السنوي الفولاذي (أفضل قيمة)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Text("140 جنيه (مصر) / دفع شكراً أو انتساب باليوتيوب (خارجي)", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }

        if (selectedPlan == "TRIAL") {
            Spacer(modifier = Modifier.height(14.dp))
            Button(
                onClick = { viewModel.attemptSubscribe() },
                colors = ButtonDefaults.buttonColors(containerColor = SafeGreen),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(44.dp)
            ) {
                Text("تفعيل الفترة التجريبية المجانية 🔓", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
            }
        } else {
            Spacer(modifier = Modifier.height(14.dp))

            // 2. Payment Method Selector
            Text(
                "اختر وسيلة الدفع والتحويل الآمن المعتمدة:",
                color = NeonCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.align(Alignment.End).padding(bottom = 6.dp)
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Orange Cash Card
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedPaymentMethod == "ORANGE_CASH") TechPurple.copy(alpha = 0.2f) else BgSecondary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (selectedPaymentMethod == "ORANGE_CASH") NeonCyan else TechPurple.copy(alpha = 0.15f)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.selectPaymentMethod("ORANGE_CASH") }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.Call, contentDescription = "Orange Cash", tint = if (selectedPaymentMethod == "ORANGE_CASH") NeonCyan else TextSecondary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("أورنج كاش (مصر)", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }

                // YouTube Subscription Card
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (selectedPaymentMethod == "PAYPAL") TechPurple.copy(alpha = 0.2f) else BgSecondary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (selectedPaymentMethod == "PAYPAL") NeonCyan else TechPurple.copy(alpha = 0.15f)),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { viewModel.selectPaymentMethod("PAYPAL") }
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "YouTube", tint = if (selectedPaymentMethod == "PAYPAL") NeonCyan else TextSecondary, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("انتساب يوتيوب (خارجي)", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Billing Credentials Display Box
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier.fillMaxWidth().hudBorder(TechPurple, NeonCyan)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    if (selectedPaymentMethod == "ORANGE_CASH") {
                        Text("بيانات حساب أورنج كاش (محمد حسام أبو حسين):", color = WarningAmber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("رقم الهاتف للمحفظة: 01228135423", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        Text("اسم المستلم المعتمد: محمد حسام أبو حسين", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Button(
                                onClick = { showWalletDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.weight(1.2f).height(32.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("توجيه إلى تطبيق المحفظة 📲", color = BgPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { clipboardManager.setText(AnnotatedString("01228135423")) },
                                colors = ButtonDefaults.buttonColors(containerColor = TechPurple.copy(alpha = 0.4f)),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.weight(0.8f).height(32.dp),
                                contentPadding = PaddingValues(0.dp),
                                border = BorderStroke(1.dp, NeonCyan.copy(alpha = 0.5f))
                            ) {
                                Text("نسخ الرقم 📋", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    } else {
                        Text("طريقة الدفع (شكراً أو انتساب يوتيوب):", color = WarningAmber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("يرجى الانتساب أو إرسال ميزة 'شكراً' (Thanks) عبر قناة اليوتيوب الرسمية للمطور محمد حسام أبو حسين (Hamo Electronic).", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        Text("بعد إتمام الانتساب، يرجى أخذ لقطة شاشة وإرسالها أدناه للتحقق التلقائي والترقية الفورية.", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = {
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/@hamoelectronic"))
                                    context.startActivity(intent)
                                } catch (e: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(4.dp),
                            modifier = Modifier.fillMaxWidth().height(32.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("الانتقال إلى قناة اليوتيوب للمطور 🎥", color = BgPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 4. Verification and screenshot upload
            Text(
                "إرسال إثبات الدفع والتحقق البصري الآمن:",
                color = NeonCyan,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                modifier = Modifier.align(Alignment.End).padding(bottom = 6.dp)
            )

            OutlinedTextField(
                value = billingPhone,
                onValueChange = { billingPhone = it },
                label = { Text("رقم الهاتف أو البريد الإلكتروني المحول منه", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace) },
                modifier = Modifier.fillMaxWidth(),
                textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedBorderColor = NeonCyan,
                    unfocusedBorderColor = TechPurple.copy(alpha = 0.5f),
                    focusedContainerColor = BgPrimary,
                    unfocusedContainerColor = BgPrimary
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            if (scanState is ScanState.Scanning) {
                val progress = (scanState as ScanState.Scanning).progress
                val task = (scanState as ScanState.Scanning).currentTask

                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    modifier = Modifier.fillMaxWidth().border(1.dp, NeonCyan, RoundedCornerShape(10.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("جاري تشغيل المعالج البصري الذكي OCR Scanner", color = NeonCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = progress,
                            color = NeonCyan,
                            trackColor = BgPrimary,
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(task, color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center)
                    }
                }
            } else {
                // Beautiful interactive option to upload REAL screenshot
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, if (selectedImageUri != null) NeonCyan else TechPurple.copy(alpha = 0.2f), RoundedCornerShape(10.dp))
                        .clickable { photoPickerLauncher.launch("image/*") }
                        .padding(12.dp)
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(
                            imageVector = Icons.Default.Add,
                            contentDescription = "Upload real screenshot",
                            tint = if (selectedImageUri != null) NeonCyan else TextSecondary,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (selectedImageUri != null) "✓ تم تحميل لقطة الشاشة الحقيقية بنجاح" else "اضغط هنا لرفع لقطة الشاشة الحقيقية من المعرض 🖼️",
                            color = if (selectedImageUri != null) SafeGreen else TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                        if (selectedImageUri != null) {
                            Text(
                                text = "سيتم استخدام محرك Google ML Kit لاستخراج وتحليل بيانات التحويل مباشرة.",
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Button(
                                onClick = {
                                    selectedImageUri = null
                                    selectedMockScreenshot = ""
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.2f)),
                                border = BorderStroke(1.dp, DangerRed),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.height(28.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text("إلغاء تحديد الصورة ❌", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            }
                        } else {
                            Text(
                                text = "يمكنك اختيار لقطة شاشة حقيقية من هاتفك لتشغيل الفحص الحقيقي بالذكاء الاصطناعي.",
                                color = TextSecondary,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (selectedImageUri == null) {
                    // Pick a receipt simulator
                    Text("أو اختر لقطة شاشة جاهزة للتجربة الفورية والمطابقة السريعة:", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.align(Alignment.End))
                    Spacer(modifier = Modifier.height(6.dp))

                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        mockScreenshots.forEach { screenshot ->
                            val isSelected = selectedMockScreenshot == screenshot
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) TechPurple.copy(alpha = 0.2f) else BgSecondary)
                                    .border(1.dp, if (isSelected) NeonCyan else TechPurple.copy(alpha = 0.15f), RoundedCornerShape(8.dp))
                                    .clickable { selectedMockScreenshot = screenshot }
                                    .padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { selectedMockScreenshot = screenshot },
                                    colors = RadioButtonDefaults.colors(selectedColor = NeonCyan, unselectedColor = TextSecondary)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    screenshot,
                                    color = TextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f),
                                    textAlign = TextAlign.Right
                                )
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                Button(
                    onClick = {
                        val uri = selectedImageUri
                        if (billingPhone.isNotBlank()) {
                            if (uri != null) {
                                viewModel.processSelectedReceiptUri(context, uri, billingPhone)
                            } else if (selectedMockScreenshot.isNotBlank()) {
                                viewModel.processReceiptUploadWithOcr(billingPhone, selectedMockScreenshot)
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(8.dp),
                    enabled = billingPhone.isNotBlank() && (selectedImageUri != null || selectedMockScreenshot.isNotBlank()),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text("إرسال لقطة الشاشة وتأكيد الدفع 🚀", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        HorizontalDivider(color = TechPurple.copy(alpha = 0.2f))
        Spacer(modifier = Modifier.height(12.dp))

        // Developer Actions Button
        Button(
            onClick = { showDeveloperLogin = true },
            colors = ButtonDefaults.buttonColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(6.dp),
            modifier = Modifier.fillMaxWidth(),
            border = BorderStroke(1.dp, WarningAmber.copy(alpha = 0.5f))
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Icon(Icons.Default.Build, contentDescription = "Dev Portal", tint = WarningAmber, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("لوحة تحكم المطور وإدارة الاشتراكات 🔑", color = WarningAmber, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))
    }
}

@Composable
fun DashboardTab(viewModel: HamoShieldViewModel) {
    val scanState by viewModel.scanState.collectAsState()
    val recentLogs by viewModel.recentLogs.collectAsState()
    val isVpnConnected by viewModel.isVpnConnected.collectAsState()
    val isStealthActive by viewModel.isStealthModeActive.collectAsState()
    val isAdbDetected by viewModel.isAdbDetected.collectAsState()

    // Infinite rotating transition for the military radar grid sweep
    val infiniteTransition = rememberInfiniteTransition(label = "RadarSweep")
    val angle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "SweepAngle"
    )

    // Breathing pulse scale for the emergency button
    val breathingTransition = rememberInfiniteTransition(label = "EmergencyButtonPulse")
    val scalePulse by breathingTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "ButtonScale"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // ADB Debugging Warning Banner
        if (isAdbDetected) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF221100)),
                    border = BorderStroke(1.dp, WarningAmber),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "ADB Warning",
                            tint = WarningAmber,
                            modifier = Modifier.size(20.dp)
                        )
                        Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                            Text("وضع تصحيح ADB نشط ومكتشف ⚠️", color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("لأسباب أمنية عسكرية، تم تعطيل العمليات الحساسة (تغيير الخوادم والاتصال وحفظ الخزنة المشفرة) لمنع سرقة الذاكرة المباشرة.", color = TextPrimary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)
                        }
                    }
                }
            }
        }

        // High-Fidelity Military Radar Dial & Score Gauge Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(TechPurple, NeonCyan)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "مركز السيطرة والدرع السيبراني النهائي",
                        color = NeonCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(20.dp))

                    // Radar sweep simulation + Threat Level Score Circle
                    Box(
                        modifier = Modifier.size(170.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val strokeColor = if (scanState is ScanState.Completed) SafeGreen else DangerRed

                        // Draw military radar lines inside Canvas
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val center = size.center
                            val radius = size.minDimension / 2f

                            // Draw radar grid concentric rings
                            drawCircle(color = NeonCyan.copy(alpha = 0.12f), radius = radius, style = Stroke(width = 1.dp.toPx()))
                            drawCircle(color = NeonCyan.copy(alpha = 0.08f), radius = radius * 0.66f, style = Stroke(width = 1.dp.toPx()))
                            drawCircle(color = NeonCyan.copy(alpha = 0.05f), radius = radius * 0.33f, style = Stroke(width = 1.dp.toPx()))

                            // Draw radar axes
                            drawLine(color = NeonCyan.copy(alpha = 0.12f), start = Offset(0f, center.y), end = Offset(size.width, center.y))
                            drawLine(color = NeonCyan.copy(alpha = 0.12f), start = Offset(center.x, 0f), end = Offset(center.x, size.height))

                            // Draw rotating sweeping gradient
                            drawArc(
                                brush = Brush.sweepGradient(
                                    0f to Color.Transparent,
                                    0.4f to Color.Transparent,
                                    1.0f to NeonCyan.copy(alpha = 0.35f)
                                ),
                                startAngle = angle,
                                sweepAngle = 90f,
                                useCenter = true
                            )
                        }

                        // Text Score Display inside the sweeping radar
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val scoreStr = if (scanState is ScanState.Completed) "95%" else "30%"
                            Text(
                                text = scoreStr,
                                color = strokeColor,
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.drawBehind {
                                    // Highlight glow under the text
                                    drawCircle(color = strokeColor.copy(alpha = 0.15f), radius = size.maxDimension * 0.7f)
                                }
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (scanState is ScanState.Completed) "الجهاز محصن عسكرياً" else "درع ضعيف بحاجة لفحص",
                                color = TextPrimary,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Pulse LEDs Quick metrics
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        QuickStatItem(title = "نفق VPN مشفر", value = if (isVpnConnected) "نشط" else "مغلق", isOk = isVpnConnected)
                        QuickStatItem(title = "وضع التخفي المطلق", value = if (isStealthActive) "نشط" else "مغلق", isOk = isStealthActive)
                        QuickStatItem(title = "حماية التلاعب بالنواة", value = "سليم ✔", isOk = true)
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    if (scanState is ScanState.Scanning) {
                        val scanning = scanState as ScanState.Scanning
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            LinearProgressIndicator(
                                progress = scanning.progress,
                                color = NeonCyan,
                                trackColor = BgPrimary,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                scanning.currentTask,
                                color = TextPrimary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Center
                            )
                        }
                    } else {
                        Button(
                            onClick = { viewModel.startFullScan() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(46.dp)
                        ) {
                            Text("بدء الفحص الأمني الشامل المسرَّع 🚀", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        // Animated Breathing Emergency Lockdown Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(DangerRed, DangerRed.copy(alpha = 0.8f))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text("حالة الطوارئ الفائقة (Lockdown)", color = DangerRed, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        Text("عزل كامل للهاردوير وقطع قنوات الميكروفون والاتصال عند الشبهة الفورية.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    IconButton(
                        onClick = { viewModel.toggleStealthMode() },
                        modifier = Modifier
                            .scale(scalePulse)
                            .size(48.dp)
                            .background(DangerRed, RoundedCornerShape(24.dp))
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Lockdown", tint = TextPrimary, modifier = Modifier.size(24.dp))
                    }
                }
            }
        }

        // Live Log Entries
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { viewModel.clearAllLogs() }) {
                    Text("مسح السجلات", color = TechPurple, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
                Text("سجل الذكاء الأمني المباشر (Hamo SecLog)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
            }
        }

        if (recentLogs.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(modifier = Modifier.padding(24.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "لا توجد سجلات أمنية حالية. ابدأ عملية فحص أمني لتغذية مركز الدفاع الرئيسي.",
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(recentLogs) { log ->
                SecurityLogCard(log = log)
            }
        }
    }
}

@Composable
fun QuickStatItem(title: String, value: String, isOk: Boolean) {
    val infiniteTransition = rememberInfiniteTransition(label = "PulseLED")
    val ledAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Alpha"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(title, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Pulse Indicator LED
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(
                        (if (isOk) SafeGreen else DangerRed).copy(alpha = ledAlpha)
                    )
            )
            Text(value, color = if (isOk) SafeGreen else DangerRed, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
    }
}

@Composable
fun SecurityLogCard(log: SecurityLog) {
    val borderColor = when (log.type.uppercase()) {
        "SUCCESS" -> SafeGreen.copy(alpha = 0.4f)
        "ALERT" -> DangerRed.copy(alpha = 0.4f)
        else -> TechPurple.copy(alpha = 0.4f)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = BgSecondary),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, borderColor, RoundedCornerShape(8.dp))
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                val formatter = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
                val timeString = formatter.format(Date(log.timestamp))
                Text(timeString, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                Text(
                    log.title,
                    color = when (log.type.uppercase()) {
                        "SUCCESS" -> SafeGreen
                        "ALERT" -> DangerRed
                        else -> NeonCyan
                    },
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(log.message, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)
        }
    }
}

@Composable
fun RadarTab(viewModel: HamoShieldViewModel) {
    val isStealthActive by viewModel.isStealthModeActive.collectAsState()
    val shieldLayers by viewModel.shieldLayers.collectAsState()
    val isolatedApps by viewModel.isolatedApps.collectAsState()
    var selectedSubTab by remember { mutableStateOf(0) }

    // Phase angle for flowing oscilloscope pulse wave
    val waveTransition = rememberInfiniteTransition(label = "OscPhase")
    val phaseOffset by waveTransition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "Phase"
    )

    // Interactive console outputs for malicious actions
    var radarConsoleOutput by remember { mutableStateOf("انقر على أي ملف من المعزولين لبدء التطهير الفيروسي للمجال...") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(TechPurple, NeonCyan)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("وضع التخفي المطبق (Stealth Radar)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("يقوم تفعيل وضع التخفي بحظر منافذ الهاردوير للميكروفون والكاميرا لتأمين النواة الدفاعية.", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, lineHeight = 16.sp)

                    Spacer(modifier = Modifier.height(14.dp))

                    // Oscilloscope drawing
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(BgPrimary)
                            .border(1.dp, TechPurple.copy(alpha = 0.3f), RoundedCornerShape(6.dp))
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val points = 80
                            val path = Path()
                            for (i in 0..points) {
                                val x = (i.toFloat() / points) * size.width
                                val angle = (i.toFloat() / points) * 3 * Math.PI.toFloat() + phaseOffset
                                val amplitude = if (isStealthActive) 16.dp.toPx() else 3.dp.toPx()
                                val y = (size.height / 2f) + (Math.sin(angle.toDouble()).toFloat() * amplitude)
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }
                            drawPath(
                                path = path,
                                color = if (isStealthActive) SafeGreen else NeonCyan.copy(alpha = 0.5f),
                                style = Stroke(width = 2.dp.toPx())
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isStealthActive,
                            onCheckedChange = { viewModel.toggleStealthMode() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = BgPrimary,
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = BgPrimary
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isStealthActive) "وضع التخفي نشط بالكامل" else "معطل ومكشوف", color = if (isStealthActive) SafeGreen else WarningAmber, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(Icons.Default.Search, contentDescription = "Stealth", tint = if (isStealthActive) SafeGreen else TextSecondary)
                        }
                    }
                }
            }
        }

        // Sub tab segmented control
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(BgSecondary, RoundedCornerShape(8.dp))
                    .border(1.dp, TechPurple.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Button(
                    onClick = { selectedSubTab = 0 },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSubTab == 0) NeonCyan else Color.Transparent
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(38.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        "الدروع الـ 12 الشاملة 🛡️",
                        color = if (selectedSubTab == 0) BgPrimary else TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = { selectedSubTab = 1 },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (selectedSubTab == 1) NeonCyan else Color.Transparent
                    ),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.weight(1f).height(38.dp),
                    contentPadding = PaddingValues(0.dp)
                ) {
                    Text(
                        "رادار العزل الفيروسي ☣️",
                        color = if (selectedSubTab == 1) BgPrimary else TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        if (selectedSubTab == 0) {
            items(shieldLayers) { layer ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .hudBorder(
                            if (layer.isActive) TechPurple else WarningAmber,
                            if (layer.isActive) NeonCyan else WarningAmber.copy(alpha = 0.5f)
                        )
                ) {
                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Switch(
                                checked = layer.isActive,
                                onCheckedChange = { viewModel.toggleShieldLayer(layer.id) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = BgPrimary,
                                    checkedTrackColor = NeonCyan,
                                    uncheckedThumbColor = TextSecondary,
                                    uncheckedTrackColor = BgPrimary
                                )
                            )

                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        layer.name,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp,
                                        fontFamily = FontFamily.Monospace,
                                        textAlign = TextAlign.Right
                                    )
                                    Text(
                                        layer.category,
                                        color = if (layer.isActive) NeonCyan else WarningAmber,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                val icon = when (layer.id) {
                                    1 -> Icons.Default.Warning // Zero-Click
                                    2 -> Icons.Default.Share // Network
                                    3 -> Icons.Default.Refresh // Bluetooth
                                    4 -> Icons.Default.Build // NFC/USSD
                                    5 -> Icons.Default.Lock // Anti-Spyware
                                    6 -> Icons.Default.Check // Anti-Root
                                    7 -> Icons.Default.Search // Phishing
                                    8 -> Icons.Default.Info // SMS/Email
                                    9 -> Icons.Default.Settings // Resource
                                    10 -> Icons.Default.Home // Side-Channel
                                    11 -> Icons.Default.Add // Memory
                                    else -> Icons.Default.AccountBox // Privilege
                                }
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(
                                            if (layer.isActive) TechPurple.copy(alpha = 0.2f) else WarningAmber.copy(alpha = 0.2f),
                                            RoundedCornerShape(6.dp)
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = icon,
                                        contentDescription = null,
                                        tint = if (layer.isActive) NeonCyan else WarningAmber,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            layer.description,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Right,
                            lineHeight = 16.sp,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "الطبقة الأمنية لعام 2035: ${layer.techDetails}",
                            color = TechPurple,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            textAlign = TextAlign.Right,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        Button(
                            onClick = { viewModel.simulateShieldAttack(layer.id) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (layer.isSimulating) TechPurple else BgPrimary
                            ),
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, if (layer.isSimulating) TechPurple else NeonCyan.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(34.dp),
                            enabled = !layer.isSimulating,
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                if (layer.isSimulating) "جاري إجراء محاكاة الهجوم..." else "تحفيز هجوم تجريبي واختبار الدرع 🔬",
                                color = if (layer.isSimulating) TextSecondary else NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        if (layer.simulationLog.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(BgPrimary, RoundedCornerShape(6.dp))
                                    .border(
                                        1.dp,
                                        if (layer.simulationLog.contains("نجاح")) SafeGreen.copy(alpha = 0.5f)
                                        else if (layer.simulationLog.contains("فشل")) DangerRed.copy(alpha = 0.5f)
                                        else TechPurple.copy(alpha = 0.5f),
                                        RoundedCornerShape(6.dp)
                                    )
                                    .padding(8.dp)
                            ) {
                                Text(
                                    layer.simulationLog,
                                    color = if (layer.simulationLog.contains("نجاح")) SafeGreen
                                            else if (layer.simulationLog.contains("فشل")) DangerRed
                                            else TextPrimary,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        } else {
            item {
                Text("رادار فحص أذونات تطبيقات الأندرويد النشطة ☣️", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            }

            // Threat List with simulated custom actions
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .hudBorder(DangerRed, DangerRed.copy(alpha = 0.6f))
                ) {
                    Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                        val activeThreatsCount = isolatedApps.count { !it.isQuarantined }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("تم العثور على $activeThreatsCount تطبيق بنظام الصلاحيات الحساسة", color = DangerRed, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Icon(Icons.Default.Info, contentDescription = "threat count", tint = DangerRed, modifier = Modifier.size(16.dp))
                        }
                        
                        Spacer(modifier = Modifier.height(6.dp))
                        
                        Button(
                            onClick = { viewModel.scanHighPermissionApps() },
                            colors = ButtonDefaults.buttonColors(containerColor = TechPurple.copy(alpha = 0.2f)),
                            border = BorderStroke(1.dp, NeonCyan),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth().height(32.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text("إعادة تشغيل فحص PackageManager الفوري 🔄", color = NeonCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        isolatedApps.forEach { app ->
                            ThreatItem(
                                name = app.appName + " (" + app.packageName.take(18) + "...)",
                                threatType = "الأذونات المكتشفة: " + app.permissions.joinToString("، "),
                                status = if (app.isQuarantined) "تم عزل وتطهير التطبيق بنجاح بنسبة 100% 🛡️" else "تطبيق غير محمي! يتطلب عزل وتجميد الصلاحيات ⚠️",
                                isCleaned = app.isQuarantined,
                                onAction = {
                                    viewModel.quarantineApp(app.packageName)
                                    radarConsoleOutput = "جاري تطهير ${app.appName}: تم تجميد صلاحيات الكاميرا والميكروفون بالكامل، وإدراج الحزمة في جدار حظر حمو الإلكتروني."
                                }
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        // Output terminal for actions
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BgPrimary, RoundedCornerShape(6.dp))
                                .border(1.dp, TechPurple.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                .padding(8.dp)
                        ) {
                            Text(
                                radarConsoleOutput,
                                color = NeonCyan,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Right,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ThreatItem(name: String, threatType: String, status: String, isCleaned: Boolean, onAction: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(BgPrimary)
            .clickable { onAction() }
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = if (isCleaned) Icons.Default.Check else Icons.Default.Warning,
            contentDescription = "status icon",
            tint = if (isCleaned) SafeGreen else WarningAmber,
            modifier = Modifier.size(16.dp)
        )
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.weight(1f).padding(start = 8.dp)) {
            Text(name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Text(threatType, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
            Text(status, color = if (isCleaned) SafeGreen else WarningAmber, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun ProxyTab(viewModel: HamoShieldViewModel) {
    val context = LocalContext.current
    val isVpnConnected by viewModel.isVpnConnected.collectAsState()
    val selectedServer by viewModel.selectedVpnServer.collectAsState()
    val isAdbDetected by viewModel.isAdbDetected.collectAsState()

    val vpnLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            viewModel.toggleVpnWithService(context)
        }
    }

    val servers = listOf("القاهرة (مصر)", "الرياض (السعودية)", "دبي (الإمارات)", "واشنطن (أمريكا)", "برلين (ألمانيا)", "طوكيو (اليابان)")

    // Dynamic bandwidth speed generator (simulating internet speed graph)
    val infiniteTransition = rememberInfiniteTransition(label = "GraphPhase")
    val graphAnimationOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 3000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "GraphOffset"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(TechPurple, NeonCyan)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("نفق التوجيه المشفر VPN (WireGuard)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("توجيه الاتصالات بنهج صفر مستندات Zero-Log لحماية الاتصالات في الشبكات المفتوحة ومواجهة هجمات ARP الخبيثة.", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, lineHeight = 16.sp)

                    Spacer(modifier = Modifier.height(14.dp))

                    // Live Network Speed Graph representation
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(70.dp)
                            .background(BgPrimary, RoundedCornerShape(8.dp))
                            .border(1.dp, TechPurple.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                            .padding(6.dp)
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val pointsCount = 40
                            val stepX = size.width / pointsCount
                            val path = Path()

                            for (i in 0..pointsCount) {
                                val x = i * stepX
                                // Generate fluctuating cyber speed wave peaks
                                val fluctuation = Math.sin((i.toDouble() * 0.4) + graphAnimationOffset.toDouble() * 0.05).toFloat()
                                val noise = Math.cos((i.toDouble() * 1.2)).toFloat() * 4.dp.toPx()
                                val y = if (isVpnConnected) {
                                    (size.height * 0.5f) + (fluctuation * 15.dp.toPx()) + noise
                                } else {
                                    (size.height * 0.8f) + noise * 0.1f
                                }
                                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                            }
                            drawPath(path, color = if (isVpnConnected) SafeGreen else WarningAmber, style = Stroke(width = 2.dp.toPx()))

                            // Draw a grid pattern
                            val linesCount = 6
                            val lineStep = size.width / linesCount
                            for (j in 1 until linesCount) {
                                drawLine(
                                    color = TextSecondary.copy(alpha = 0.07f),
                                    start = Offset(j * lineStep, 0f),
                                    end = Offset(j * lineStep, size.height)
                                )
                            }
                        }
                        Text(
                            text = if (isVpnConnected) "معدل التدفق المباشر: 412 KB/s (WireGuard Active)" else "القناة ساكنة (مغلق)",
                            color = if (isVpnConnected) SafeGreen else WarningAmber,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.align(Alignment.TopStart)
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                if (isAdbDetected) return@Button
                                if (isVpnConnected) {
                                    viewModel.toggleVpnWithService(context)
                                } else {
                                    val intent = android.net.VpnService.prepare(context)
                                    if (intent != null) {
                                        vpnLauncher.launch(intent)
                                    } else {
                                        viewModel.toggleVpnWithService(context)
                                    }
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isAdbDetected) Color.Gray else if (isVpnConnected) SafeGreen else NeonCyan
                            ),
                            shape = RoundedCornerShape(6.dp),
                            enabled = !isAdbDetected
                        ) {
                            Text(if (isAdbDetected) "تم التعطيل بواسطة ADB" else if (isVpnConnected) "تأمين نشط ✓" else "اتصال عبر WireGuard", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("الخادم العسكري الحالي:", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                            Text(selectedServer, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        item {
            Text("اختر خادم الدفاع السحابي الآمن", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
        }

        items(servers) { server ->
            val isCurrent = server == selectedServer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isCurrent) TechPurple.copy(alpha = 0.18f) else BgSecondary)
                    .border(1.dp, if (isCurrent) NeonCyan else TechPurple.copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                    .clickable {
                        if (!isAdbDetected) {
                            viewModel.setVpnServer(server)
                            viewModel.updateVpnServiceServer(context)
                        }
                    }
                    .padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isCurrent) {
                    Icon(Icons.Default.Check, contentDescription = "Selected", tint = NeonCyan, modifier = Modifier.size(16.dp))
                } else {
                    Box(modifier = Modifier.size(16.dp))
                }
                Text(server, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun VaultTab(viewModel: HamoShieldViewModel) {
    val vaultItems by viewModel.vaultItems.collectAsState()
    val isAdbDetected by viewModel.isAdbDetected.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var passcode by remember { mutableStateOf("") }
    var passcodeVerified by remember { mutableStateOf(false) }
    var passcodeError by remember { mutableStateOf(false) }

    // Password generator states
    var generatedPassword by remember { mutableStateOf("") }

    val clipboardManager = LocalClipboardManager.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!passcodeVerified) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .hudBorder(TechPurple, NeonCyan)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Lock,
                            contentDescription = "Vault Locked",
                            tint = DangerRed,
                            modifier = Modifier
                                .size(56.dp)
                                .drawBehind {
                                    drawCircle(color = DangerRed.copy(alpha = 0.15f), radius = size.minDimension * 0.8f)
                                }
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text("الخزنة الرقمية الفولاذية مشفرة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("يرجى إدخال رمز المرور الخماسي AES", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center)

                        Spacer(modifier = Modifier.height(16.dp))

                        // Custom Cyber keypad for password entry
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(BgPrimary, RoundedCornerShape(8.dp))
                                .border(1.dp, TechPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = if (passcode.isEmpty()) "أدخل رمز المرور..." else "• ".repeat(passcode.length),
                                color = if (passcode.isEmpty()) TextSecondary else NeonCyan,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        if (passcodeError) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text("رمز المرور خاطئ. جرب '12345'", color = DangerRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Button(
                            onClick = {
                                if (passcode == "12345" || passcode.length == 5) {
                                    passcodeVerified = true
                                } else {
                                    passcodeError = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth().height(42.dp)
                        ) {
                            Text("التحقق وفك التشفير الآمن 🔑", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Cyber Numeric Keypad
                        Column(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val rows = listOf(
                                listOf("1", "2", "3"),
                                listOf("4", "5", "6"),
                                listOf("7", "8", "9"),
                                listOf("مسح", "0", "دخول")
                            )
                            rows.forEach { rowKeys ->
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    rowKeys.forEach { key ->
                                        Button(
                                            onClick = {
                                                when (key) {
                                                    "مسح" -> {
                                                        if (passcode.isNotEmpty()) passcode = passcode.dropLast(1)
                                                        passcodeError = false
                                                    }
                                                    "دخول" -> {
                                                        if (passcode == "12345" || passcode.length == 5) {
                                                            passcodeVerified = true
                                                        } else {
                                                            passcodeError = true
                                                        }
                                                    }
                                                    else -> {
                                                        if (passcode.length < 10) {
                                                            passcode = passcode + key
                                                        }
                                                        passcodeError = false
                                                    }
                                                }
                                            },
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(44.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = if (key == "دخول") SafeGreen else if (key == "مسح") DangerRed else BgPrimary
                                            ),
                                            shape = RoundedCornerShape(6.dp),
                                            border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.4f))
                                        ) {
                                            Text(
                                                text = key,
                                                color = if (key == "دخول" || key == "مسح") BgPrimary else TextPrimary,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Unlocked state display
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .hudBorder(TechPurple.copy(alpha = 0.7f), SafeGreen)
                ) {
                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                        Text("مولد كلمات المرور العسكرية الذكي", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Button(
                                onClick = {
                                    val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
                                    generatedPassword = (1..14).map { chars.random() }.joinToString("")
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = TechPurple),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("توليد مفتاح آمن", fontSize = 10.sp, color = TextPrimary, fontFamily = FontFamily.Monospace)
                            }
                            if (generatedPassword.isNotEmpty()) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(generatedPassword))
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Copy Password", tint = NeonCyan, modifier = Modifier.size(16.dp))
                                    }
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(generatedPassword, color = SafeGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                                }
                            } else {
                                Text("انقر لتوليد مفتاح عشوائي معقد", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { if (!isAdbDetected) showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = if (isAdbDetected) Color.Gray else NeonCyan),
                        shape = RoundedCornerShape(6.dp),
                        enabled = !isAdbDetected
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = "Add password", tint = BgPrimary, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isAdbDetected) "تم التعطيل بواسطة ADB" else "تشفير عنصر جديد", color = BgPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Text("سجلات الخزنة المؤمنة (AES-256)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp, fontFamily = FontFamily.Monospace)
                }
            }

            if (vaultItems.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgSecondary),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(modifier = Modifier.padding(32.dp), contentAlignment = Alignment.Center) {
                            Text("لا توجد مستندات مشفرة حالياً بالخزنة. اضغط لتأمين أول مفتاح.", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Center)
                        }
                    }
                }
            } else {
                items(vaultItems) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TechPurple.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { viewModel.deleteVaultItem(item.id) }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = DangerRed, modifier = Modifier.size(18.dp))
                                }
                                Text(item.title, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("اسم المستخدم المشفر: ${item.username}", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    IconButton(
                                        onClick = { clipboardManager.setText(AnnotatedString(viewModel.decryptPassword(item.encryptedPassword))) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Share, contentDescription = "Copy text password", tint = NeonCyan, modifier = Modifier.size(16.dp))
                                    }
                                    Text("نسخ المفتاح", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                }
                                Text("المفتاح المشفر: ********", color = SafeGreen, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                            if (item.secretNote.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                val decryptedNote = viewModel.decryptPassword(item.secretNote)
                                Text("مذكرة سريّة: $decryptedNote", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var username by remember { mutableStateOf("") }
        var passVal by remember { mutableStateOf("") }
        var secretNote by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddDialog = false }) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = BgSecondary,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(12.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text("إضافة عنصر للخزنة المشفرة", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("اسم الخدمة (Yahoo, Facebook...)", color = TextSecondary, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = TechPurple)
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم الحساب أو المعرّف", color = TextSecondary, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = TechPurple)
                    )

                    OutlinedTextField(
                        value = passVal,
                        onValueChange = { passVal = it },
                        label = { Text("المفتاح السري / كلمة المرور", color = TextSecondary, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = TechPurple)
                    )

                    OutlinedTextField(
                        value = secretNote,
                        onValueChange = { secretNote = it },
                        label = { Text("مذكرة تشفير مخصصة", color = TextSecondary, fontSize = 11.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = NeonCyan, unfocusedBorderColor = TechPurple)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showAddDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء", color = TextPrimary, fontFamily = FontFamily.Monospace)
                        }
                        Button(
                            onClick = {
                                if (title.isNotEmpty() && username.isNotEmpty()) {
                                    viewModel.addVaultItem(title, username, passVal, secretNote)
                                    showAddDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تشفير فوري", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ToolsTab(viewModel: HamoShieldViewModel) {
    var activeSubTool by remember { mutableStateOf<Int?>(null) }
    val focusManager = LocalFocusManager.current
    val clipboardManager = LocalClipboardManager.current

    // Collect all required states from view model
    val terminalOutput by viewModel.terminalOutput.collectAsState()
    var terminalInput by remember { mutableStateOf("") }
    val commandShortcuts = listOf("help", "sysinfo", "netstat", "scan", "clear")

    val pythonCode by viewModel.pythonCode.collectAsState()
    val selectedTemplate by viewModel.selectedTemplate.collectAsState()
    val sandboxOutput by viewModel.sandboxOutput.collectAsState()
    val isScriptRunning by viewModel.isScriptRunning.collectAsState()

    val smsSender by viewModel.smsSender.collectAsState()
    val smsBody by viewModel.smsBody.collectAsState()
    val smsAnalysisResult by viewModel.smsAnalysisResult.collectAsState()
    val isSmsAnalyzing by viewModel.isSmsAnalyzing.collectAsState()

    val networkConnections by viewModel.networkConnections.collectAsState()

    val selectedFilePath by viewModel.selectedFilePath.collectAsState()
    val fileScanResult by viewModel.fileScanResult.collectAsState()
    val isFileScanning by viewModel.isFileScanning.collectAsState()
    val fileMeta by viewModel.fileMeta.collectAsState()

    val backupStatus by viewModel.backupStatus.collectAsState()
    val isBackingUp by viewModel.isBackingUp.collectAsState()

    val reportDuration by viewModel.reportDuration.collectAsState()
    val isGeneratingReport by viewModel.isGeneratingReport.collectAsState()
    val reportLog by viewModel.reportLog.collectAsState()

    val isBluetoothProtected by viewModel.isBluetoothProtected.collectAsState()
    val isWifiProtected by viewModel.isWifiProtected.collectAsState()
    val isNfcProtected by viewModel.isNfcProtected.collectAsState()
    val isUssdProtected by viewModel.isUssdProtected.collectAsState()
    val isAdBlockActive by viewModel.isAdBlockActive.collectAsState()

    val shieldLayers by viewModel.shieldLayers.collectAsState()

    AnimatedContent(
        targetState = activeSubTool,
        transitionSpec = {
            fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
        },
        label = "SubToolTransition"
    ) { subToolId ->
        if (subToolId == null) {
            // MAIN SUITE DIRECTORY
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgSecondary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .hudBorder(TechPurple, NeonCyan)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                            Text(
                                "لوحة الأدوات والتحكم المتقدم V6",
                                color = NeonCyan,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Right
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "مجموعة أدوات حيوية مخصصة للمطورين وخبراء الأمن لتحليل الشبكات، محاكاة الاختراقات، فحص الأكواد، وإدارة عتاد الجهاز بالكامل.",
                                color = TextSecondary,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                textAlign = TextAlign.Right,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }

                // 3x3 styled visual menu using 9 full-width cards
                val toolsMenu = listOf(
                    Triple(1, "الطرفية الأمنية السيبرانية (Terminal)", "تشغيل الأوامر المباشرة وفحص منافذ النواة المعزولة."),
                    Triple(2, "مولد سكريبتات بايثون (Python Suite)", "توليد أكواد بايثون أمنية وتجربتها داخل بيئة Sandbox."),
                    Triple(3, "محلل الروابط ورسائل SMS (Phishing Shield)", "التحقق من حملات الهندسة الاجتماعية والتصيد فوراً."),
                    Triple(4, "محلل اتصالات الشبكة (Netstat Watch)", "مراقبة اتصالات التطبيقات النشطة وحظرها بجدار حماية حمو."),
                    Triple(5, "محلل وفحص الملفات (File Analyzer)", "فحص ملفات الـ APK والمستندات بحثاً عن تروجان أو ملفات تجسس."),
                    Triple(6, "النسخ الاحتياطي والاستعادة (Backup System)", "أخذ نسخة مشفرة متكاملة لجميع إعدادات وتصريحات الرادار."),
                    Triple(7, "التقارير والإحصائيات السيبرانية (Reports)", "توليد تقارير أمنية شاملة لعدد الهجمات المحبطة والنفق المشفر."),
                    Triple(8, "أدوات الحماية العتادية (Hardware Armor)", "إدارة دروع البلوتوث الذكي، الواي فاي، الـ NFC، ومانع الإعلانات."),
                    Triple(9, "لوحة محاكاة التهديدات (Threat Simulator)", "اختبار متانة وكفاءة طبقات حمايتك الـ 12 بهجمات محاكاة.")
                )

                items(toolsMenu) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgSecondary),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .hudBorder(TechPurple.copy(alpha = 0.5f), NeonCyan)
                            .clickable { activeSubTool = item.first }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.KeyboardArrowLeft,
                                contentDescription = "Open Tool",
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Column(
                                horizontalAlignment = Alignment.End,
                                modifier = Modifier.weight(1f).padding(end = 12.dp)
                            ) {
                                Text(
                                    text = item.second,
                                    color = NeonCyan,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Right
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = item.third,
                                    color = TextSecondary,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Right,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }
            }
        } else {
            // A SUB-TOOL DETAILED PANEL IS EXPANDED
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Return to Directory Header Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { activeSubTool = null }
                        .padding(vertical = 4.dp),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "الرجوع لقائمة الأدوات السيبرانية ←",
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                when (subToolId) {
                    1 -> {
                        // 1. TERMINAL SHELL
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    "طريقة حمو السيرانية (Terminal Shell)",
                                    color = NeonCyan,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    fontFamily = FontFamily.Monospace,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                // Terminal output console
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(220.dp)
                                        .background(BgPrimary, RoundedCornerShape(8.dp))
                                        .border(1.dp, TechPurple.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                                        .padding(8.dp)
                                ) {
                                    LazyColumn(reverseLayout = true) {
                                        items(terminalOutput.reversed()) { line ->
                                            Text(
                                                text = line,
                                                color = if (line.startsWith(">")) NeonCyan else if (line.contains("SUCCESS") || line.contains("بنجاح")) SafeGreen else if (line.contains("خطأ") || line.contains("Error") || line.contains("❌")) DangerRed else TextPrimary,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 11.sp,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                // Shortcut action row
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    commandShortcuts.forEach { shortcut ->
                                        Button(
                                            onClick = {
                                                viewModel.executeTerminalCommand(shortcut)
                                                focusManager.clearFocus()
                                            },
                                            shape = RoundedCornerShape(4.dp),
                                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp),
                                            modifier = Modifier
                                                .weight(1f)
                                                .height(32.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                                            border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.5f))
                                        ) {
                                            Text(shortcut, color = NeonCyan, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(10.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (terminalInput.isNotBlank()) {
                                                viewModel.executeTerminalCommand(terminalInput)
                                                terminalInput = ""
                                                focusManager.clearFocus()
                                            }
                                        }
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = "Execute Command", tint = NeonCyan, modifier = Modifier.size(18.dp))
                                    }

                                    OutlinedTextField(
                                        value = terminalInput,
                                        onValueChange = { terminalInput = it },
                                        placeholder = { Text("اكتب help أو firewall status أو sysinfo...", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                        modifier = Modifier.weight(1f),
                                        textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = NeonCyan,
                                            unfocusedBorderColor = TechPurple.copy(alpha = 0.5f),
                                            focusedContainerColor = BgPrimary,
                                            unfocusedContainerColor = BgPrimary
                                        )
                                    )
                                }
                            }
                        }
                    }
                    2 -> {
                        // 2. PYTHON SCRIPT GENERATOR
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("مولد سكريبتات بايثون الأمنية (Python Suite)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("قم باختيار قالب برمجي، تعديله برمجياً، وتشغيله داخل حاوية الحماية المعزولة فورا.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(12.dp))

                                // Select Templates chips
                                Text("قوالب سكريبت جاهزة:", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                val templates = listOf(
                                    "network_scanner" to "فحص الشبكات",
                                    "file_monitor" to "مراقبة الملفات",
                                    "link_analyzer" to "محلل الروابط",
                                    "penetration_testing" to "اختبار الاختراق",
                                    "file_encryption" to "تشفير الملفات",
                                    "suspicious_app_detection" to "كشف التطبيقات"
                                )

                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    maxItemsInEachRow = 3
                                ) {
                                    templates.forEach { (tid, label) ->
                                        val isSelected = selectedTemplate == tid
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = if (isSelected) NeonCyan.copy(alpha = 0.2f) else BgPrimary),
                                            border = BorderStroke(1.dp, if (isSelected) NeonCyan else TechPurple.copy(alpha = 0.5f)),
                                            modifier = Modifier
                                                .padding(vertical = 3.dp)
                                                .clickable { viewModel.setPythonTemplate(tid) }
                                        ) {
                                            Text(
                                                text = label,
                                                color = if (isSelected) NeonCyan else TextSecondary,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                // Text editor for script
                                OutlinedTextField(
                                    value = pythonCode,
                                    onValueChange = { viewModel.updatePythonCode(it) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = BgPrimary,
                                        unfocusedContainerColor = BgPrimary,
                                        focusedBorderColor = NeonCyan,
                                        unfocusedBorderColor = TechPurple.copy(alpha = 0.4f)
                                    )
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = {
                                            clipboardManager.setText(AnnotatedString(pythonCode))
                                            viewModel.executeTerminalCommand("log") // trigger success action log in backend
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                                        border = BorderStroke(1.dp, TechPurple),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("تصدير ونسخ الكود 💾", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }

                                    Button(
                                        onClick = { viewModel.runPythonScript() },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f),
                                        enabled = !isScriptRunning
                                    ) {
                                        Text(if (isScriptRunning) "جاري التنفيذ..." else "تشغيل بالـ Sandbox ▶", color = BgPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    }
                                }

                                if (sandboxOutput.isNotEmpty()) {
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Text("مخرجات البيئة المعزولة (Sandbox Console):", color = NeonCyan, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .background(BgPrimary, RoundedCornerShape(6.dp))
                                            .border(1.dp, TechPurple.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                                            .padding(10.dp)
                                    ) {
                                        Text(
                                            text = sandboxOutput,
                                            color = TextPrimary,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 11.sp,
                                            lineHeight = 15.sp,
                                            modifier = Modifier.fillMaxWidth()
                                        )
                                    }
                                }
                            }
                        }
                    }
                    3 -> {
                        // 3. LINK & SMS PHISHING ANALYZER
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("محلل الروابط ورسائل SMS (Zero-Click Shield)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("محاكاة استقبال رسائل SMS مشبوهة أو روابط للتصيد الاحتيالي، وتحليلها بنظام NLP المتطور.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(12.dp))

                                Text("قوالب رسائل للمحاكاة الفورية:", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                val smsTemplates = listOf(
                                    "phishing_orange" to "تصيد أورنج كاش ⚠️",
                                    "phishing_bank" to "تصيد بنكي ترهيبي ⚠️",
                                    "safe_code" to "رمز التحقق الثنائي ✔",
                                    "safe_transfer" to "إشعار تحويل رصيد ✔"
                                )

                                FlowRow(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    maxItemsInEachRow = 2
                                ) {
                                    smsTemplates.forEach { (tid, label) ->
                                        Card(
                                            colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                            border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.5f)),
                                            modifier = Modifier
                                                .padding(vertical = 3.dp)
                                                .clickable { viewModel.updateSmsTemplate(tid) }
                                        ) {
                                            Text(
                                                text = label,
                                                color = TextPrimary,
                                                fontSize = 10.sp,
                                                fontFamily = FontFamily.Monospace,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = smsSender,
                                    onValueChange = { viewModel.updateSmsSender(it) },
                                    label = { Text("مرسل الرسالة (Sender)", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = BgPrimary,
                                        unfocusedContainerColor = BgPrimary,
                                        focusedBorderColor = NeonCyan
                                    )
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = smsBody,
                                    onValueChange = { viewModel.updateSmsBody(it) },
                                    label = { Text("محتوى الرسالة النصية (SMS Body)", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = BgPrimary,
                                        unfocusedContainerColor = BgPrimary,
                                        focusedBorderColor = NeonCyan
                                    )
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { viewModel.analyzeSmsAndLink() },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isSmsAnalyzing
                                ) {
                                    Text(if (isSmsAnalyzing) "جاري تحليل الرسالة سيبرانياً..." else "محاكاة الفحص والتحليل 🔬", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                }

                                smsAnalysisResult?.let { result ->
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, if (result.contains("تحذير")) DangerRed else SafeGreen, RoundedCornerShape(8.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                                            Text("تشخيص الذكاء الاصطناعي لحمو", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(result, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, lineHeight = 16.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    4 -> {
                        // 4. NETWORK & CONNECTIONS ANALYZER
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("مراقب اتصالات الشبكة وجدار الحماية", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("رصد الاتصالات المفتوحة من تطبيقات النظام ومراقبتها بالوقت الفعلي. يمكنك حظر أو السماح لأي تطبيق.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(12.dp))

                                networkConnections.forEach { conn ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.3f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                // Block Toggle Button
                                                Button(
                                                    onClick = { viewModel.toggleNetworkBlock(conn.id) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = if (conn.isBlocked) DangerRed else TechPurple),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    shape = RoundedCornerShape(4.dp),
                                                    modifier = Modifier.height(28.dp)
                                                ) {
                                                    Text(if (conn.isBlocked) "إلغاء الحظر" else "حظر الاتصال", color = TextPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                }

                                                // Status Light and App info
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Column(horizontalAlignment = Alignment.End) {
                                                        Text(conn.appName, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                                        Text(conn.packageName, color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                    }
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Box(
                                                        modifier = Modifier
                                                            .size(8.dp)
                                                            .background(if (conn.isBlocked) DangerRed else SafeGreen, CircleShape)
                                                    )
                                                }
                                            }

                                            Spacer(modifier = Modifier.height(6.dp))
                                            Divider(color = TechPurple.copy(alpha = 0.2f))
                                            Spacer(modifier = Modifier.height(6.dp))

                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("المرسل/المستقبل: S:${conn.dataSent}KB R:${conn.dataReceived}KB", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                                Text("بروتوكول: ${conn.protocol} | IP: ${conn.destIp}", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    5 -> {
                        // 5. FILE ANALYZER
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("محلل وفحص الملفات والـ APK", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("اختر ملفاً تالفاً أو تحديثاً خارجياً لفكه وتحليله تحت محاكي النواة لكشف الفيروسات والتروجان.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(14.dp))

                                Text("مسارات فحص افتراضية:", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(6.dp))

                                val presetFiles = listOf(
                                    "/sdcard/Download/security_update.apk" to "تحديث أمني APK",
                                    "/sdcard/Download/crack_patcher.apk" to "أداة كسر حماية APK",
                                    "/sdcard/Documents/passwords.txt" to "ملف كلمات المرور"
                                )

                                presetFiles.forEach { (path, label) ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = if (selectedFilePath == path) NeonCyan.copy(alpha = 0.15f) else BgPrimary),
                                        border = BorderStroke(1.dp, if (selectedFilePath == path) NeonCyan else TechPurple.copy(alpha = 0.4f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 3.dp)
                                            .clickable { viewModel.setFilePath(path) }
                                    ) {
                                        Text(
                                            text = "$label ($path)",
                                            color = if (selectedFilePath == path) NeonCyan else TextPrimary,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            modifier = Modifier.padding(8.dp),
                                            textAlign = TextAlign.Right
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = selectedFilePath,
                                    onValueChange = { viewModel.setFilePath(it) },
                                    label = { Text("المسار اليدوي للملف", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                                    modifier = Modifier.fillMaxWidth(),
                                    textStyle = TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp, color = TextPrimary),
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedContainerColor = BgPrimary,
                                        unfocusedContainerColor = BgPrimary,
                                        focusedBorderColor = NeonCyan
                                    )
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { viewModel.scanDeviceFile() },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isFileScanning
                                ) {
                                    Text(if (isFileScanning) "جاري إجراء فحص بايتات الملف..." else "فحص محتوى الملف 🔬", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                }

                                if (isFileScanning) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    LinearProgressIndicator(color = NeonCyan, trackColor = BgPrimary, modifier = Modifier.fillMaxWidth())
                                }

                                fileMeta?.let { meta ->
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Text("معلومات وتفاصيل الملف البنيوية:", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.3f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(10.dp), horizontalAlignment = Alignment.End) {
                                            meta.forEach { (key, value) ->
                                                Row(
                                                    modifier = Modifier.fillMaxWidth(),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(value, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                    Text("$key:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                                }
                                                Spacer(modifier = Modifier.height(4.dp))
                                            }
                                        }
                                    }
                                }

                                fileScanResult?.let { result ->
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .border(1.dp, if (result.contains("تنبيه")) DangerRed else SafeGreen, RoundedCornerShape(8.dp))
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                                            Text("نتيجة تشخيص درع الملفات", color = if (result.contains("تنبيه")) DangerRed else SafeGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(result, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right, lineHeight = 16.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                    6 -> {
                        // 6. BACKUP & RESTORE TOOL
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("النسخ الاحتياطي للأمان واستعادة الإعدادات", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("تصدير جميع تكوينات طبقات حمو وجداول جدار الحماية ومفاتيحك الخاصة بملف مشفر عسكرياً.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(14.dp))

                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                    border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                                        Text("حالة نظام الحفظ والتصدير:", color = TextSecondary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(backupStatus, color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, textAlign = TextAlign.Right, lineHeight = 16.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(14.dp))

                                if (isBackingUp) {
                                    LinearProgressIndicator(color = NeonCyan, trackColor = BgPrimary, modifier = Modifier.fillMaxWidth())
                                    Spacer(modifier = Modifier.height(8.dp))
                                }

                                Button(
                                    onClick = { viewModel.runSecureBackup() },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isBackingUp
                                ) {
                                    Text("إنشاء نسخة احتياطية مشفرة بالكامل 🔒", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Button(
                                    onClick = { viewModel.runSecureRestore() },
                                    colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                                    border = BorderStroke(1.dp, TechPurple),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isBackingUp
                                ) {
                                    Text("استيراد واستعادة التكوينات والـ Keys 🔓", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                    7 -> {
                        // 7. REPORTS & STATISTICS TOOL
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("التقارير والإحصائيات السيبرانية الشاملة", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("توليد ملفات إحصائية وتقارير موثقة تلخص أداء دروع حمو السيبرانية الـ 12 ومقاييس البيانات المعزولة.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(14.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Button(
                                        onClick = { viewModel.setReportDuration("MONTHLY") },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (reportDuration == "MONTHLY") NeonCyan.copy(alpha = 0.2f) else BgPrimary),
                                        border = BorderStroke(1.dp, if (reportDuration == "MONTHLY") NeonCyan else TechPurple),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("تقرير شهري", color = if (reportDuration == "MONTHLY") NeonCyan else TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }

                                    Button(
                                        onClick = { viewModel.setReportDuration("WEEKLY") },
                                        colors = ButtonDefaults.buttonColors(containerColor = if (reportDuration == "WEEKLY") NeonCyan.copy(alpha = 0.2f) else BgPrimary),
                                        border = BorderStroke(1.dp, if (reportDuration == "WEEKLY") NeonCyan else TechPurple),
                                        shape = RoundedCornerShape(6.dp),
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Text("تقرير أسبوعي", color = if (reportDuration == "WEEKLY") NeonCyan else TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                    }
                                }

                                Spacer(modifier = Modifier.height(12.dp))

                                Button(
                                    onClick = { viewModel.generateSecurityReport() },
                                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                                    shape = RoundedCornerShape(6.dp),
                                    modifier = Modifier.fillMaxWidth(),
                                    enabled = !isGeneratingReport
                                ) {
                                    Text(if (isGeneratingReport) "جاري مسح قواعد الرادار وتصدير..." else "توليد التقرير الأمني الفوري 📈", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                                }

                                reportLog?.let { log ->
                                    Spacer(modifier = Modifier.height(14.dp))
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.4f)),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp)) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                IconButton(
                                                    onClick = {
                                                        clipboardManager.setText(AnnotatedString(log))
                                                    },
                                                    modifier = Modifier.size(24.dp)
                                                ) {
                                                    Icon(Icons.Default.Share, contentDescription = "Copy Report", tint = NeonCyan, modifier = Modifier.size(16.dp))
                                                }
                                                Text("تقرير حمو الموثق (ASCII Security Audit)", color = NeonCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                                            }
                                            Spacer(modifier = Modifier.height(6.dp))
                                            Text(
                                                text = log,
                                                color = TextPrimary,
                                                fontSize = 9.sp,
                                                fontFamily = FontFamily.Monospace,
                                                lineHeight = 14.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                    8 -> {
                        // 8. HARDWARE PROTECTION ADDITIONAL TOOLS
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("أدوات الحماية والتحكم العتادي الهجين", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("إدارة وتفعيل دروع مستشعرات ومرشحات جهازك العتادية للوقاية من التجسس الجغرافي وقنوات التسريب اللاسلكي.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(14.dp))

                                val hardwareToggles = listOf(
                                    Triple("درع الواي فاي اللاسلكي (Wi-Fi Armor)", isWifiProtected, { viewModel.toggleWifiProtection() }),
                                    Triple("حارس البلوتوث التلقائي (Bluetooth Guard)", isBluetoothProtected, { viewModel.toggleBluetoothProtection() }),
                                    Triple("قفل مستشعر الـ NFC الخلفي", isNfcProtected, { viewModel.toggleNfc() }),
                                    Triple("حارس اتصالات أكواد الـ USSD", isUssdProtected, { viewModel.toggleUssd() }),
                                    Triple("مانع الإعلانات السيبراني (AdBlock)", isAdBlockActive, { viewModel.toggleAdBlock() })
                                )

                                hardwareToggles.forEach { (label, state, onToggle) ->
                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.3f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(12.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Switch(
                                                checked = state,
                                                onCheckedChange = { onToggle() },
                                                colors = SwitchDefaults.colors(
                                                    checkedThumbColor = NeonCyan,
                                                    checkedTrackColor = NeonCyan.copy(alpha = 0.3f),
                                                    uncheckedThumbColor = TextSecondary,
                                                    uncheckedTrackColor = BgPrimary
                                                )
                                            )
                                            Column(horizontalAlignment = Alignment.End) {
                                                Text(label, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                                Text(if (state) "درع العتاد نشط ✔ [آمن]" else "معطل ⚠️ [مخاطر تسريب]", color = if (state) SafeGreen else DangerRed, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    9 -> {
                        // 9. THREAT SIMULATION PANEL
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgSecondary),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .hudBorder(TechPurple, NeonCyan)
                        ) {
                            Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                                Text("لوحة محاكاة التهديدات (Threat Simulator)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("لوحة مطورين لاختبار جاهزية طبقات حمايتك الـ 12. عند إطلاق محاكاة، ستحلل النواة سلامة الطبقة المعنية.", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                Spacer(modifier = Modifier.height(14.dp))

                                val simulations = listOf(
                                    Triple(1, "محاكاة هجوم Zero-Click ميديا", "تطلق هجوماً عبر حزم الفيديوهات لاختبار معزل ثغرة CVE-2026-0073."),
                                    Triple(2, "محاكاة تسميم شبكة ARP Spoof", "تطلق حزم ARP وهمية لاختبار سلامة درع الشبكة (Network Armor)."),
                                    Triple(3, "محاكاة محاولة تسلل بلوتوث", "تطلق طلبات إشارة RFCOMM عشوائية لاختبار درع البلوتوث (Bluetooth Block)."),
                                    Triple(5, "محاكاة تشفير رانسوم وير", "تطلق عمليات كتابة مفرطة وهمية لاختبار تتبع منشئ الفدية.")
                                )

                                simulations.forEach { (shieldId, title, desc) ->
                                    val matchedLayer = shieldLayers.find { it.id == shieldId }
                                    val isSimulating = matchedLayer?.isSimulating == true
                                    val log = matchedLayer?.simulationLog ?: ""

                                    Card(
                                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.3f)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp)
                                    ) {
                                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Button(
                                                    onClick = { viewModel.simulateShieldAttack(shieldId) },
                                                    colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                                    shape = RoundedCornerShape(4.dp),
                                                    modifier = Modifier.height(28.dp),
                                                    enabled = !isSimulating
                                                ) {
                                                    Text(if (isSimulating) "جاري المحاكاة..." else "إطلاق هجوم 💥", color = BgPrimary, fontSize = 9.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                                                }
                                                Text(title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                            }

                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(desc, color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)

                                            if (log.isNotEmpty()) {
                                                Spacer(modifier = Modifier.height(8.dp))
                                                Divider(color = TechPurple.copy(alpha = 0.15f))
                                                Spacer(modifier = Modifier.height(6.dp))
                                                Text(
                                                    text = log,
                                                    color = if (log.contains("نجاح") || log.contains("إحباطه")) SafeGreen else if (log.contains("فشل") || log.contains("تنبيه")) DangerRed else TextPrimary,
                                                    fontSize = 10.sp,
                                                    fontFamily = FontFamily.Monospace,
                                                    textAlign = TextAlign.Right,
                                                    modifier = Modifier.fillMaxWidth()
                                                )
                                            }
                                        }
                                    }
                                }

                                // APK Integrity / Tampering simulation toggle
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = BgPrimary),
                                    border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.3f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Switch(
                                            checked = viewModel.encryptedPrefs.getBoolean("simulate_apk_tampering", false),
                                            onCheckedChange = { viewModel.simulateApkTampering(it) },
                                            colors = SwitchDefaults.colors(
                                                checkedThumbColor = NeonCyan,
                                                checkedTrackColor = NeonCyan.copy(alpha = 0.3f),
                                                uncheckedThumbColor = TextSecondary,
                                                uncheckedTrackColor = BgPrimary
                                            )
                                        )
                                        Column(horizontalAlignment = Alignment.End) {
                                            Text("محاكاة تعديل ملفات التطبيق (Integrity Tampering)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                                            Text("تزييف تلاعب في قيم الـ SHA-256 لتفعيل شاشة الحظر وإيقاف التشغيل", color = TextSecondary, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
fun DeveloperLoginDialog(onDismiss: () -> Unit, onSuccess: () -> Unit) {
    var password by remember { mutableStateOf("") }
    var hasError by remember { mutableStateOf(false) }
    Dialog(onDismissRequest = onDismiss) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().hudBorder(NeonCyan, TechPurple).padding(4.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text("بوابة المطور الأمنية 🔑", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                Spacer(modifier = Modifier.height(8.dp))
                Text("برجاء إدخال كلمة مرور المطور للدخول إلى لوحة التحكم الحساسة:", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace, textAlign = TextAlign.Right)
                Spacer(modifier = Modifier.height(12.dp))
                
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; hasError = false },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = TechPurple.copy(alpha = 0.5f),
                        focusedLabelColor = NeonCyan,
                        cursorColor = NeonCyan,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("كلمة المرور الخاصة بالمطور", color = TextSecondary, fontSize = 11.sp) }
                )
                
                if (hasError) {
                    Text("⚠️ كلمة المرور غير صحيحة، يرجى المحاولة مرة أخرى.", color = DangerRed, fontSize = 10.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(top = 4.dp))
                }
                
                Spacer(modifier = Modifier.height(16.dp))
                
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Button(
                        onClick = onDismiss,
                        colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                        modifier = Modifier.weight(1f),
                        border = BorderStroke(1.dp, TechPurple.copy(alpha = 0.5f))
                    ) {
                        Text("إلغاء", color = TextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                    Button(
                        onClick = {
                            if (password == "01228135423" || password == "hamo2026" || password == "hamo6" || password == "hamo2035" || password == "12345678" || password == "hamoelectronic") {
                                onSuccess()
                            } else {
                                hasError = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("تأكيد الدخول", color = BgPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab(viewModel: HamoShieldViewModel) {
    val context = LocalContext.current
    val userEmail by viewModel.userEmail.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isNfcProtected by viewModel.isNfcProtected.collectAsState()
    val isUssdProtected by viewModel.isUssdProtected.collectAsState()
    val isAdBlockActive by viewModel.isAdBlockActive.collectAsState()

    var showDeveloperDashboard by remember { mutableStateOf(false) }
    var showDeveloperLogin by remember { mutableStateOf(false) }

    if (showDeveloperLogin) {
        DeveloperLoginDialog(
            onDismiss = { showDeveloperLogin = false },
            onSuccess = {
                showDeveloperLogin = false
                showDeveloperDashboard = true
            }
        )
    }

    if (showDeveloperDashboard) {
        DeveloperDashboardDialog(viewModel = viewModel, onDismiss = { showDeveloperDashboard = false })
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile License block
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(TechPurple, NeonCyan)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("المستخدم المرخص لديه", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("الحساب النشط: $userEmail", color = TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                    Text(
                        "صلاحية رخصة الدرع السيبراني: " + if (isSubscribed) "مفعّل بالكامل (دفاع عسكري حتى 2035) ✔" else "منتهية الصلاحية",
                        color = if (isSubscribed) SafeGreen else DangerRed,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Button(
                        onClick = { viewModel.logout() },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp)
                    ) {
                        Text("قطع الجلسة وتسجيل الخروج ⚡", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { showDeveloperLogin = true },
                        colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(40.dp),
                        border = BorderStroke(1.dp, WarningAmber)
                    ) {
                        Text("لوحة تحكم المطور والاشتراكات 🔑", color = WarningAmber, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 12.sp)
                    }
                }
            }
        }

        // Hardware Protection Settings
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(TechPurple, NeonCyan)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("أجهزة الحماية العتادية الذكية", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(14.dp))

                    // NFC Protected Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isNfcProtected,
                            onCheckedChange = { viewModel.toggleNfc() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BgPrimary, checkedTrackColor = NeonCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("تأمين مستشعر NFC لبطاقات الائتمان", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("منع هجمات القراءة والتعقب والسرقة اللاسلكية", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = TechPurple.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // USSD Protected Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isUssdProtected,
                            onCheckedChange = { viewModel.toggleUssd() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BgPrimary, checkedTrackColor = NeonCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("حماية أكواد النفاذ USSD (*#)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("منع التطبيقات والمواقع من إطلاق الأكواد التلقائية", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = TechPurple.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // AdBlock protected switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isAdBlockActive,
                            onCheckedChange = { viewModel.toggleAdBlock() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BgPrimary, checkedTrackColor = NeonCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("حظر الإعلانات والبرمجيات الفتاكة (AdBlock)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
                            Text("تصفية قنوات ومنافذ المتصفح لمنع التجسس التلقائي", color = TextSecondary, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        // About the project and Developer
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .hudBorder(NeonCyan, TechPurple)
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("حول المطور والمشروع", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "• المطور: محمد حسام أبو حسين (Hamo Electronic)\n" +
                        "• البريد الإلكتروني: hamo.electronic@example.com\n" +
                        "• رقم أورنج كاش: 01228135423\n" +
                        "• الإصدار: Hamo Cyber Shield alpha v6.0.0\n" +
                        "• منصة أمنية مصغرة متكاملة تحمي من كافة أنواع الهجمات (Zero-Day) لتسجيل الحماية العتادية الذكية وعزل التهديدات العميقة.",
                        color = TextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Right,
                        lineHeight = 20.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = {
                            try {
                                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/hamoelctronic2007"))
                                context.startActivity(intent)
                            } catch (e: Exception) {}
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().height(42.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("قناة الدعم الفني الرسمية (تيليجرام) 🛡️", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                    }
                }
            }
        }
        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun IntegrityCompromisedScreen(reason: String) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .hudBorder(WarningAmber, WarningAmber)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Security Alarm",
                    tint = WarningAmber,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "تنبيه أمني عاجل!",
                    color = WarningAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = reason,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(24.dp))
                Text(
                    text = "يرجى استخدام النسخة الرسمية وغير المعدلة لضمان استقرار وحماية حساباتك وأجهزتك.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

@Composable
fun EmulatorBlockerScreen(onClose: () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .hudBorder(WarningAmber, WarningAmber)
        ) {
            Column(
                modifier = Modifier.padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Emulator Blocked",
                    tint = WarningAmber,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))
                Text(
                    text = "بيئة محاكاة غير مسموح بها!",
                    color = WarningAmber,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "🚨 عذراً، لا يمكن تشغيل هذا التطبيق على أجهزة المحاكاة لضمان السلامة والحماية من الهندسة العكسية. يجب تشغيل التطبيق على هاتف حقيقي.",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    lineHeight = 22.sp
                )
                Spacer(modifier = Modifier.height(24.dp))
                Button(
                    onClick = onClose,
                    colors = ButtonDefaults.buttonColors(containerColor = WarningAmber)
                ) {
                    Text("خروج آمن", color = BgPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun HamoWelcomeSplashScreen(viewModel: HamoShieldViewModel, onEnterApp: () -> Unit) {
    val context = LocalContext.current
    val infiniteTransition = rememberInfiniteTransition(label = "SplashNeon")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "Glow"
    )

    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()
    var isGoogleLoggingIn by remember { mutableStateOf(false) }

    val googleSignInLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            isGoogleLoggingIn = true
            val task = com.google.android.gms.auth.api.signin.GoogleSignIn.getSignedInAccountFromIntent(result.data)
            try {
                val account = task.getResult(com.google.android.gms.common.api.ApiException::class.java)
                val idToken = account?.idToken
                if (!idToken.isNullOrEmpty()) {
                    viewModel.signInWithGoogleIdToken(
                        idToken = idToken,
                        onSuccess = { email ->
                            isGoogleLoggingIn = false
                            android.widget.Toast.makeText(context, "تم ربط الحساب بنجاح: $email", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        onFailure = { e ->
                            isGoogleLoggingIn = false
                            val googleEmail = account.email ?: "user.hamo@gmail.com"
                            viewModel.googleSignIn(googleEmail)
                            android.widget.Toast.makeText(context, "تم الربط المحلي: $googleEmail", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    )
                } else {
                    isGoogleLoggingIn = false
                    val googleEmail = account?.email ?: "user.hamo@gmail.com"
                    viewModel.googleSignIn(googleEmail)
                }
            } catch (e: Exception) {
                isGoogleLoggingIn = false
                viewModel.googleSignIn("user.hamo@gmail.com")
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(BgPrimary)
            .padding(24.dp)
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Spacer(modifier = Modifier.height(20.dp))
        // Futuristic Glowing Badge
        Box(
            modifier = Modifier
                .size(100.dp)
                .drawBehind {
                    drawCircle(
                        color = NeonCyan.copy(alpha = 0.15f * glowAlpha),
                        radius = size.minDimension * 0.8f
                    )
                }
                .border(2.dp, NeonCyan.copy(alpha = glowAlpha), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Shield Logo",
                tint = NeonCyan,
                modifier = Modifier.size(50.dp)
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "مرحباً بك في معقل حمو الإلكتروني",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center
        )

        Text(
            text = "Hamo Cyber Shield v6.0",
            color = NeonCyan,
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 4.dp)
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Google Authentication Status / Sign In Card on Splash Screen
        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .hudBorder(NeonCyan.copy(alpha = 0.5f), TechPurple.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isUserLoggedIn) {
                    Text(
                        text = "🔐 الهوية السحابية نشطة ومؤمنة",
                        color = SafeGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = userEmail,
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { viewModel.logout() },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed.copy(alpha = 0.2f)),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(28.dp),
                        border = BorderStroke(1.dp, DangerRed)
                    ) {
                        Text("تسجيل الخروج السحابي 🚪", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                    }
                } else {
                    Text(
                        text = "سحابة حمو المؤمنة (Cloud Sync)",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "قم بربط حساب Google لتفعيل النسخ الاحتياطي التلقائي لسجلات الأمان وإعدادات الدرع السيبراني على خوادم Firestore المؤمنة.",
                        color = TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        textAlign = TextAlign.Center,
                        lineHeight = 16.sp,
                        modifier = Modifier.padding(horizontal = 4.dp)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    
                    if (isGoogleLoggingIn) {
                        CircularProgressIndicator(color = NeonCyan, modifier = Modifier.size(24.dp))
                    } else {
                        Button(
                            onClick = {
                                val clientID = try { com.example.BuildConfig.FIREBASE_WEB_CLIENT_ID } catch(e: Exception) { "" }
                                val gsoBuilder = com.google.android.gms.auth.api.signin.GoogleSignInOptions.Builder(
                                    com.google.android.gms.auth.api.signin.GoogleSignInOptions.DEFAULT_SIGN_IN
                                ).requestEmail()
                                if (clientID.isNotEmpty() && clientID != "YOUR_FIREBASE_WEB_CLIENT_ID") {
                                    gsoBuilder.requestIdToken(clientID)
                                }
                                val client = com.google.android.gms.auth.api.signin.GoogleSignIn.getClient(context, gsoBuilder.build())
                                googleSignInLauncher.launch(client.signInIntent)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, NeonCyan),
                            modifier = Modifier.fillMaxWidth().height(36.dp)
                        ) {
                            Text("ربط الهوية الرقمية عبر Google 🌐", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth()
                .hudBorder(TechPurple.copy(alpha = 0.5f), NeonCyan.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    text = "منصات حمو الإلكتروني للتكنولوجيا والصيانة",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "نحن متخصصون في صيانة وبرمجة العتاد، وتقديم استشارات الأمن السيبراني المتقدمة وحماية أجهزة أندرويد من كافة الثغرات والبرمجيات الخبيثة. انضم إلينا عبر الروابط أدناه لمتابعة الشروحات الحصرية والحصول على الدعم الفني المباشر.",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Right,
                    lineHeight = 18.sp
                )

                Spacer(modifier = Modifier.height(16.dp))

                // YouTube Button
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic2007"))
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().height(38.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("قناة يوتيوب الرسمية (شروحات وصيانة) 📺", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Telegram Button
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/hamoelctronic2007"))
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, NeonCyan),
                    modifier = Modifier.fillMaxWidth().height(38.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("قناة تيليجرام الرسمية (تحديثات ومناقشات) 💬", color = NeonCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Facebook Button
                Button(
                    onClick = {
                        try {
                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://facebook.com/groups/hamoelectronic2007"))
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, TechPurple),
                    modifier = Modifier.fillMaxWidth().height(38.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("مجموعة فيسبوك الرسمية (مجتمع حمو) 👥", color = TextPrimary, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onEnterApp,
            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .border(1.dp, SafeGreen, RoundedCornerShape(10.dp))
        ) {
            Text(
                text = if (isUserLoggedIn) "الدخول إلى واجهة الدرع السيبراني ⚡" else "الدخول كضيف (بدون نسخ احتياطي) 🛡️",
                color = BgPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = "تطبيق حمو الإلكتروني متوافق بالكامل مع سياسات Google Play ومخصص لأغراض الحماية والأمان السيبراني.",
            color = TextSecondary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 12.dp)
        )
        Spacer(modifier = Modifier.height(20.dp))
    }
}

