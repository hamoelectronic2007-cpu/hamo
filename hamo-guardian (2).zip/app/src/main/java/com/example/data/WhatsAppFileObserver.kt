package com.example.data

import android.os.FileObserver
import android.util.Log
import java.io.File

/**
 * Monitors the simulated WhatsApp folder for incoming media.
 * Uses the modern FileObserver APIs introduced in Android 10+ (using List of files).
 */
class WhatsAppFileObserver(
    private val directory: File,
    private val onFileCreated: (File) -> Unit
) : FileObserver(directory.path, CREATE) {

    override fun onEvent(event: Int, path: String?) {
        if (event == CREATE && path != null) {
            val file = File(directory, path)
            Log.d("GuardianFileObserver", "Detected new file in observed directory: ${file.absolutePath}")
            onFileCreated(file)
        }
    }
}
