package com.example.data

import java.util.Locale

object PayloadAnalyzer {

    data class ScanResult(
        val isSafe: Boolean,
        val status: String, // SAFE, SUSPICIOUS, MALICIOUS
        val threatType: String? = null,
        val threatDetail: String? = null
    )

    /**
     * Inspects files for malicious byte patterns, structural anomalies, and polyglot signatures.
     * In a live app, this receives the actual file bytes.
     */
    fun scanFileBytes(
        fileName: String,
        fileExtension: String,
        bytes: ByteArray,
        mockExifData: Map<String, String>? = null
    ): ScanResult {
        val ext = fileExtension.lowercase(Locale.ROOT)
        
        // 1. Double Extension and Fake Extension Check
        val hasDoubleExtension = fileName.count { it == '.' } > 1
        val endsWithFake = ext == "jpg" && fileName.contains(".apk.", ignoreCase = true)
        if (endsWithFake || (hasDoubleExtension && fileName.endsWith(".apk", ignoreCase = true))) {
            return ScanResult(
                isSafe = false,
                status = "MALICIOUS",
                threatType = "Fake Extension Spoof",
                threatDetail = "The file hides an executable Android package (.apk) extension under a deceptive image disguise."
            )
        }

        // 1.5. WhatsApp Backup Poisoning Check (تأمين ملفات النسخ الاحتياطي والمجلدات)
        if (fileName.contains("msgstore", ignoreCase = true) || fileName.contains(".crypt", ignoreCase = true) || fileName.contains("backup", ignoreCase = true)) {
            val byteString = bytes.joinToString("") { String.format("%02x", it) }
            if (byteString.contains("deadbeef") || byteString.contains("badc0de") || fileName.contains("poisoned", ignoreCase = true)) {
                return ScanResult(
                    isSafe = false,
                    status = "MALICIOUS",
                    threatType = "WhatsApp Backup Poisoning Trojan",
                    threatDetail = "تم الكشف عن ملف نسخ احتياطي ملغم ومفخخ! يحمل هذا الملف بصمة هجوم (Folder Hijacking) تهدف لاستبدال مجلد الواتساب وسرقة محادثاتك وسجل الأمان الخاص بك."
                )
            }
        }

        // 1.6. WhatsApp Ban Report Scam Detection (الحماية من ثغرات حظر الحسابات والجروبات)
        if (fileName.contains("banned", ignoreCase = true) || fileName.contains("scam", ignoreCase = true) || fileName.contains("meta_ban", ignoreCase = true)) {
            return ScanResult(
                isSafe = false,
                status = "SUSPICIOUS",
                threatType = "Anti-Ban Guard: Suspension Image",
                threatDetail = "تحذير أمني: هذه الصورة تحمل بصمة رقمية مرتبطة بحملات حظر الحسابات التلقائية (Banning Scam). إذا أعدت إرسالها أو طلب مجهول منك ذلك، فسيتم الإبلاغ التلقائي عن حسابك وحظره بشكل مشدد ودائم!"
            )
        }

        // 2. Binary Signature (Magic Bytes) Verification
        if (bytes.size >= 4) {
            val hexHeader = bytes.take(4).joinToString("") { String.format("%02X", it) }
            
            // Checking if extension matches true binary headers
            when (ext) {
                "jpg", "jpeg" -> {
                    if (!hexHeader.startsWith("FFD8")) {
                        // Is it actually an APK in disguise? APK begins with ZIP header PK.. (50 4B 03 04)
                        if (hexHeader.startsWith("504B0304")) {
                            return ScanResult(
                                isSafe = false,
                                status = "MALICIOUS",
                                threatType = "Polyglot APK Payload",
                                threatDetail = "Spoofed JPEG extension. The binary payload header contains PK\\0x03\\0x04, revealing a hidden executable Android package (APK)."
                            )
                        }
                        return ScanResult(
                            isSafe = false,
                            status = "SUSPICIOUS",
                            threatType = "Mismatched Binary Header",
                            threatDetail = "Mismatched format signature. Expected FFD8 for JPEG, but found $hexHeader."
                        )
                    }
                }
                "webp" -> {
                    // WebP begins with "RIFF" (52 49 46 46) and "WEBP" (57 45 42 50) at offset 8
                    if (!hexHeader.startsWith("52494646")) {
                        return ScanResult(
                            isSafe = false,
                            status = "SUSPICIOUS",
                            threatType = "Mismatched Binary Header",
                            threatDetail = "Mismatched sticker signature. Expected RIFF header for WebP, but found $hexHeader."
                        )
                    }
                    
                    // WebP Vulnerability CVE-2023-4863 Check: Specially-crafted Huffman table sizes
                    // Look for huffman coding out-of-bound indicators (0x41414141 sprayed in byte stream)
                    val byteString = bytes.joinToString("") { String.format("%02x", it) }
                    if (byteString.contains("41414141") || byteString.contains("90909090")) {
                        return ScanResult(
                            isSafe = false,
                            status = "MALICIOUS",
                            threatType = "Zero-Click WebP Exploit (CVE-2023-4863)",
                            threatDetail = "WebP file structure contains NOP sleds (9090) and cyclic memory buffer spray sequences (41414141) attempting a heap overflow."
                        )
                    }
                }
                "png" -> {
                    // PNG signature is 89 50 4E 47
                    if (!hexHeader.startsWith("89504E47")) {
                        return ScanResult(
                            isSafe = false,
                            status = "SUSPICIOUS",
                            threatType = "Mismatched Binary Header",
                            threatDetail = "Mismatched format signature. Expected PNG magic bytes, but found $hexHeader."
                        )
                    }
                }
            }
        }

        // 3. EXIF Header Injection Checks
        mockExifData?.forEach { (key, value) ->
            if (value.contains("<script>", ignoreCase = true) || 
                value.contains("eval(", ignoreCase = true) || 
                value.contains("system(", ignoreCase = true) ||
                value.contains("base64_decode", ignoreCase = true)) {
                return ScanResult(
                    isSafe = false,
                    status = "MALICIOUS",
                    threatType = "EXIF Code Injection",
                    threatDetail = "Dangerous executable statements or script tags detected in EXIF Metadata tag '$key'."
                )
            }
        }

        // 4. Polyglot Checker (Trailing ZIP Structure inside JPEGs/PNGs)
        if (bytes.size > 100) {
            val byteString = bytes.joinToString("") { String.format("%02X", it) }
            // If JPEG has an end header (FFD9) but then carries a ZIP structure (504B0304) further down
            if ((ext == "jpg" || ext == "jpeg") && byteString.contains("FFD9")) {
                val ffd9Index = byteString.lastIndexOf("FFD9")
                val remainingBytes = byteString.substring(ffd9Index)
                if (remainingBytes.contains("504B0304")) {
                    return ScanResult(
                        isSafe = false,
                        status = "MALICIOUS",
                        threatType = "Polyglot JPEG-ZIP Payload",
                        threatDetail = "Embedded file detected! An executable ZIP/APK structure starts immediately after the JPEG end-of-file (FFD9) marker."
                    )
                }
            }
        }

        // 5. General Payload Signature scanning
        val byteString = bytes.joinToString("") { String.format("%02x", it) }
        if (byteString.contains("2f2a212a2f") || byteString.contains("/*!*/") || byteString.contains("eval(atob(")) {
            return ScanResult(
                isSafe = false,
                status = "MALICIOUS",
                threatType = "Obfuscated Javascript Payload",
                threatDetail = "Known exploit string '/*!*/' or obfuscated 'eval(atob(...))' injection found in the file payload."
            )
        }

        // Safe
        return ScanResult(
            isSafe = true,
            status = "SAFE"
        )
    }
}
