package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface GuardianDao {
    // Vulnerabilities
    @Query("SELECT * FROM vulnerabilities ORDER BY dateAdded DESC")
    fun getAllVulnerabilities(): Flow<List<Vulnerability>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVulnerabilities(vulnerabilities: List<Vulnerability>)

    @Query("DELETE FROM vulnerabilities")
    suspend fun clearVulnerabilities()

    // Scanned Files
    @Query("SELECT * FROM scanned_files ORDER BY timestamp DESC")
    fun getAllScannedFiles(): Flow<List<ScannedFile>>

    @Query("SELECT * FROM scanned_files WHERE status = 'QUARANTINED' ORDER BY timestamp DESC")
    fun getQuarantinedFiles(): Flow<List<ScannedFile>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScannedFile(scannedFile: ScannedFile): Long

    @Update
    suspend fun updateScannedFile(scannedFile: ScannedFile)

    @Query("DELETE FROM scanned_files WHERE id = :id")
    suspend fun deleteScannedFileById(id: Long)

    @Query("DELETE FROM scanned_files")
    suspend fun clearAllScannedFiles()

    // Behavior Logs
    @Query("SELECT * FROM behavior_logs ORDER BY timestamp DESC")
    fun getAllBehaviorLogs(): Flow<List<BehaviorLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBehaviorLog(log: BehaviorLog): Long

    @Query("DELETE FROM behavior_logs")
    suspend fun clearBehaviorLogs()
}
