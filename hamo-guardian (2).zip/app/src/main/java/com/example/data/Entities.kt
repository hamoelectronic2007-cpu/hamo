package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vulnerabilities")
data class Vulnerability(
    @PrimaryKey val id: String, // e.g. "CVE-2023-4863"
    val title: String,
    val fileType: String, // WEBP, PNG, JPG, MP4, GIF
    val signaturePattern: String, // Hex string or pattern
    val description: String,
    val severity: String, // CRITICAL, HIGH, MEDIUM
    val dateAdded: Long = System.currentTimeMillis()
)

@Entity(tableName = "scanned_files")
data class ScannedFile(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val fileName: String,
    val filePath: String,
    val fileType: String, // WEBP, PNG, JPG, MP4, ZIP, APK
    val fileSize: Long,
    val status: String, // SAFE, SUSPICIOUS, MALICIOUS, QUARANTINED
    val threatType: String? = null, // "Zero-Click Exploit", "Polyglot Payload", "EXIF Code Injection", "Malicious Sticker"
    val threatDetail: String? = null, // Explanatory text of the threat signature
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "behavior_logs")
data class BehaviorLog(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val actionType: String, // "MESSAGE_SPAM", "MASS_GROUP_JOIN", "PROFILE_STORM", "UNKNOWN_CONNECTION"
    val description: String,
    val riskScore: Int, // 1 to 100
    val timestamp: Long = System.currentTimeMillis()
)
