package com.example.data

import kotlinx.coroutines.flow.Flow

class GuardianRepository(private val dao: GuardianDao) {

    val allVulnerabilities: Flow<List<Vulnerability>> = dao.getAllVulnerabilities()
    val allScannedFiles: Flow<List<ScannedFile>> = dao.getAllScannedFiles()
    val quarantinedFiles: Flow<List<ScannedFile>> = dao.getQuarantinedFiles()
    val allBehaviorLogs: Flow<List<BehaviorLog>> = dao.getAllBehaviorLogs()

    suspend fun insertVulnerabilities(vulnerabilities: List<Vulnerability>) {
        dao.insertVulnerabilities(vulnerabilities)
    }

    suspend fun clearVulnerabilities() {
        dao.clearVulnerabilities()
    }

    suspend fun addScannedFile(scannedFile: ScannedFile): Long {
        return dao.insertScannedFile(scannedFile)
    }

    suspend fun updateScannedFile(scannedFile: ScannedFile) {
        dao.updateScannedFile(scannedFile)
    }

    suspend fun deleteScannedFile(id: Long) {
        dao.deleteScannedFileById(id)
    }

    suspend fun clearAllScannedFiles() {
        dao.clearAllScannedFiles()
    }

    suspend fun logBehavior(log: BehaviorLog): Long {
        return dao.insertBehaviorLog(log)
    }

    suspend fun clearBehaviorLogs() {
        dao.clearBehaviorLogs()
    }
}
