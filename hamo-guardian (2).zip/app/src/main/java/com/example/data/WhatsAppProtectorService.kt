package com.example.data

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import java.io.File

/**
 * A Foreground Service representing the background continuous scanner that watches WhatsApp media folders.
 * Uses a Notification to keep the service running smoothly without system interruption.
 */
class WhatsAppProtectorService : Service() {

    private var fileObserver: WhatsAppFileObserver? = null

    companion object {
        const val CHANNEL_ID = "guardian_service_channel"
        const val NOTIFICATION_ID = 2026
        
        fun startService(context: Context) {
            val intent = Intent(context, WhatsAppProtectorService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, WhatsAppProtectorService::class.java)
            context.stopService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("HamO Guardian is Active")
            .setContentText("WhatsApp real-time media protection shield is running.")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        startForeground(NOTIFICATION_ID, notification)

        // Set up directory monitoring
        val mockWhatsAppMediaDir = File(filesDir, "mock_whatsapp/media")
        if (!mockWhatsAppMediaDir.exists()) {
            mockWhatsAppMediaDir.mkdirs()
        }

        fileObserver = WhatsAppFileObserver(mockWhatsAppMediaDir) { file ->
            // In a real application, this triggers ScanIncomingFileUseCase
            // For safety and visibility, ViewModel handles simulations and notifications.
        }
        fileObserver?.startWatching()

        return START_STICKY
    }

    override fun onDestroy() {
        fileObserver?.stopWatching()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val serviceChannel = NotificationChannel(
                CHANNEL_ID,
                "HamO Guardian Shield",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Monitors incoming files to guard against zero-click and malicious media."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(serviceChannel)
        }
    }
}
