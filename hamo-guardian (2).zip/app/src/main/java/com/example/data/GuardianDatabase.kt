package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [Vulnerability::class, ScannedFile::class, BehaviorLog::class],
    version = 1,
    exportSchema = false
)
abstract class GuardianDatabase : RoomDatabase() {
    abstract fun guardianDao(): GuardianDao

    companion object {
        @Volatile
        private var INSTANCE: GuardianDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): GuardianDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GuardianDatabase::class.java,
                    "guardian_database"
                )
                .addCallback(DatabaseCallback(scope))
                .build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : RoomDatabase.Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialVulnerabilities(database.guardianDao())
                }
            }
        }

        private suspend fun populateInitialVulnerabilities(dao: GuardianDao) {
            val initialList = listOf(
                Vulnerability(
                    id = "CVE-2023-4863",
                    title = "WebP Buffer Overflow Exploit",
                    fileType = "WEBP",
                    signaturePattern = "RIFF....WEBPVP8X",
                    description = "A critical heap buffer overflow vulnerability in libwebp, exploited via crafted WebP images to trigger Zero-Click arbitrary code execution.",
                    severity = "CRITICAL"
                ),
                Vulnerability(
                    id = "CVE-2024-27818",
                    title = "iMessage & Media Decoder RCE",
                    fileType = "PNG",
                    signaturePattern = "89504E470D0A1A0A",
                    description = "Out-of-bounds write vulnerability in image format parsers that allows memory corruption during processing of media files without user interaction.",
                    severity = "CRITICAL"
                ),
                Vulnerability(
                    id = "CVE-2024-20017",
                    title = "MediaTek APU Memory Corruption",
                    fileType = "MP4",
                    signaturePattern = "0000001866747970",
                    description = "A heap overflow vulnerability in the audio/video decoder processor. Can be triggered by sending malformed media payloads to crash or take over WhatsApp services.",
                    severity = "HIGH"
                ),
                Vulnerability(
                    id = "CVE-2025-0104",
                    title = "WhatsApp Sticker Engine Crash & Hijack",
                    fileType = "GIF",
                    signaturePattern = "474946383961",
                    description = "An unhandled exception in the WhatsApp animated sticker renderer. Specially configured GIF files can overflow image boundaries, causing app hangs or service exploits.",
                    severity = "HIGH"
                ),
                Vulnerability(
                    id = "POLYGLOT-APK-01",
                    title = "Polyglot Hidden APK Payload",
                    fileType = "JPG",
                    signaturePattern = "FFD8FFE0.*504B0304",
                    description = "An image containing a concealed zip-compressed Android package (APK) embedded at the tail of JPEG headers, designed to sneak Trojans past system verifiers.",
                    severity = "HIGH"
                ),
                Vulnerability(
                    id = "EXIF-SCRIPT-INJECT",
                    title = "EXIF Header Script Injection",
                    fileType = "JPG",
                    signaturePattern = "UserComment=<script>.*</script>",
                    description = "Malicious executable code or javascript statements concealed inside EXIF headers like 'UserComment' or 'GPSInfo' targeting insecure web wrappers.",
                    severity = "MEDIUM"
                )
            )
            dao.insertVulnerabilities(initialList)
        }
    }
}
