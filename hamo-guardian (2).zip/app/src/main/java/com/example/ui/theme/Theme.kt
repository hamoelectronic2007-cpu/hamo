package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = CyberCyan,
    onPrimary = OnCyberCyan,
    secondary = CyberCyan,
    onSecondary = OnCyberCyan,
    tertiary = CyberGreen,
    onTertiary = CyberBlack,
    background = CyberBlack,
    onBackground = OnCyberBlack,
    surface = CyberGrey,
    onSurface = OnCyberBlack,
    error = CyberRed,
    onError = OnCyberBlack
  )

private val LightColorScheme = DarkColorScheme // Always use cyber-neon dark style

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true, // Force Dark mode for a cyber feel
  dynamicColor: Boolean = false, // Disable dynamic colors to preserve our themed branding
  content: @Composable () -> Unit,
) {
  val colorScheme = DarkColorScheme
  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}
