package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBlack = Color(0xFF0A0A0A)
val CyberGrey = Color(0xFF111111)
val CyberLightGrey = Color(0xFF222222)

val CyberCyan = Color(0xFF00E5FF)       // Primary action & glow
val CyberRed = Color(0xFFFF0055)        // Critical threats & alerts
val CyberGreen = Color(0xFF00FF88)      // Protected & safe status
val CyberYellow = Color(0xFFFFD600)     // Warnings & suspicious files

val CyberCyanDim = Color(0x1F00E5FF)
val CyberRedDim = Color(0x1FFF0055)
val CyberGreenDim = Color(0x1F00FF88)
val CyberYellowDim = Color(0x1FFFD600)

val OnCyberBlack = Color(0xFFFFFFFF)
val OnCyberCyan = Color(0xFF0A0A0A)
