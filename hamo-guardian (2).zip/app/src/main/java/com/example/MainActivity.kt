package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.content.Intent
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import com.example.data.*
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            Toast.makeText(this, "Notification permissions granted", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(this, "Continuous background notifications may be limited", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Ask for Android 13+ Notification Permissions dynamically
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Initialize local Room database and Repository
        val database = GuardianDatabase.getDatabase(applicationContext, lifecycleScope)
        val repository = GuardianRepository(database.guardianDao())
        
        // Setup ViewModel using factory
        val viewModel: GuardianViewModel by viewModels {
            GuardianViewModelFactory(application, repository)
        }

        setContent {
            MyApplicationTheme {
                val context = LocalContext.current
                val isActivated by viewModel.isActivated.collectAsStateWithLifecycle()
                
                // Real package name tampering check (Anti-reverse engineering protection)
                val isTampered = context.packageName != "com.aistudio.hamoguardian.vscqwe" && context.packageName != "com.example"
                
                if (isTampered) {
                    TamperOverlayView()
                } else if (!isActivated) {
                    SubscriptionGateView(viewModel)
                } else {
                    Scaffold(
                        modifier = Modifier.fillMaxSize()
                    ) { innerPadding ->
                        MainScreenContent(viewModel, modifier = Modifier.padding(innerPadding))
                    }
                }
            }
        }
    }
}

@Composable
fun MainScreenContent(viewModel: GuardianViewModel, modifier: Modifier = Modifier) {
    var selectedTab by remember { mutableStateOf("dashboard") } // "dashboard", "quarantine", "behavior", "cves", "logs"
    
    val status by viewModel.protectionStatus.collectAsStateWithLifecycle()
    val isEmergencyActive by viewModel.isEmergencyMode.collectAsStateWithLifecycle()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            HeaderBar(status = status, isEmergency = isEmergencyActive)

            // Dynamic view based on selected navigation tab
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                // Background Matrix digital grid effect
                MatrixBackgroundEffect()

                AnimatedContent(
                    targetState = selectedTab,
                    transitionSpec = {
                        fadeIn(animationSpec = tween(220)) togetherWith fadeOut(animationSpec = tween(220))
                    },
                    label = "tabChange"
                ) { targetTab ->
                    when (targetTab) {
                        "dashboard" -> DashboardView(viewModel)
                        "quarantine" -> QuarantineView(viewModel)
                        "behavior" -> BehaviorView(viewModel)
                        "cves" -> CVEsView(viewModel)
                        "logs" -> LogsView(viewModel)
                    }
                }
            }

            // High-fidelity Custom Bottom Navigation
            CyberBottomNavigation(
                selectedTab = selectedTab,
                onTabSelected = { selectedTab = it },
                viewModel = viewModel
            )
        }
    }
}

@Composable
fun HeaderBar(status: String, isEmergency: Boolean) {
    val glowColor = when {
        isEmergency -> CyberRed
        status == "ALERT" -> CyberRed
        status == "WARNING" -> CyberYellow
        else -> CyberGreen
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBlack)
            .drawBehind {
                drawLine(
                    color = Color.White.copy(alpha = 0.05f),
                    start = Offset(0f, size.height),
                    end = Offset(size.width, size.height),
                    strokeWidth = 1.dp.toPx()
                )
            }
            .padding(horizontal = 24.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column {
            Text(
                text = "SYSTEM PROTOCOL 2.6",
                style = TextStyle(
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 10.sp,
                    color = CyberCyan,
                    letterSpacing = 2.sp
                )
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "HamO Guardian",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontStyle = FontStyle.Italic,
                fontSize = 20.sp,
                textDecoration = TextDecoration.Underline
            )
        }

        // Sophisticated Dark status circle & label
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = (if (isEmergency) "EMERGENCY" else if (status == "ALERT") "ALERT" else if (status == "WARNING") "WARNING" else "SECURED").uppercase(),
                color = glowColor,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 9.sp,
                letterSpacing = 1.sp
            )

            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(CyberGrey)
                    .border(1.dp, glowColor.copy(alpha = 0.3f), CircleShape)
                    .shadow(15.dp, CircleShape, spotColor = glowColor),
                contentAlignment = Alignment.Center
            ) {
                val infiniteTransition = rememberInfiniteTransition(label = "pulse")
                val pulseScale by infiniteTransition.animateFloat(
                    initialValue = 0.8f,
                    targetValue = 1.2f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = FastOutSlowInEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulseScale"
                )
                val pulseAlpha by infiniteTransition.animateFloat(
                    initialValue = 0.4f,
                    targetValue = 1.0f,
                    animationSpec = infiniteRepeatable(
                        animation = tween(1000, easing = LinearEasing),
                        repeatMode = RepeatMode.Reverse
                    ),
                    label = "pulseAlpha"
                )

                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .graphicsLayer {
                            scaleX = pulseScale
                            scaleY = pulseScale
                            alpha = pulseAlpha
                        }
                        .clip(CircleShape)
                        .background(glowColor)
                )
            }
        }
    }
}

@Composable
fun CyberBottomNavigation(
    selectedTab: String,
    onTabSelected: (String) -> Unit,
    viewModel: GuardianViewModel
) {
    val statsQuarantined by viewModel.statsQuarantined.collectAsStateWithLifecycle()

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF0F0F0F))
            .drawBehind {
                drawLine(
                    color = Color.White.copy(alpha = 0.05f),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 1.dp.toPx()
                )
            }
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(vertical = 12.dp, horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        BottomTabItem(
            label = "Monitor",
            icon = Icons.Default.Shield,
            isSelected = selectedTab == "dashboard",
            onClick = { onTabSelected("dashboard") },
            tag = "tab_dashboard"
        )
        BottomTabItem(
            label = "Quarantine",
            icon = Icons.Default.Dangerous,
            isSelected = selectedTab == "quarantine",
            onClick = { onTabSelected("quarantine") },
            badgeCount = statsQuarantined,
            tag = "tab_quarantine"
        )
        BottomTabItem(
            label = "Behavior",
            icon = Icons.Default.Timeline,
            isSelected = selectedTab == "behavior",
            onClick = { onTabSelected("behavior") },
            tag = "tab_behavior"
        )
        BottomTabItem(
            label = "CVE DB",
            icon = Icons.Default.Terminal,
            isSelected = selectedTab == "cves",
            onClick = { onTabSelected("cves") },
            tag = "tab_cves"
        )
        BottomTabItem(
            label = "Logs",
            icon = Icons.Default.List,
            isSelected = selectedTab == "logs",
            onClick = { onTabSelected("logs") },
            tag = "tab_logs"
        )
    }
}

@Composable
fun BottomTabItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    badgeCount: Int = 0,
    tag: String
) {
    val opacity = if (isSelected) 1.0f else 0.4f
    val activeColor = if (isSelected) CyberCyan else Color.White
    val borderColor = if (isSelected) CyberCyan else Color.White

    Column(
        modifier = Modifier
            .testTag(tag)
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 4.dp)
            .graphicsLayer { alpha = opacity },
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Box(contentAlignment = Alignment.TopEnd) {
            Box(
                modifier = Modifier
                    .size(26.dp)
                    .border(
                        width = 1.5.dp,
                        color = borderColor,
                        shape = RoundedCornerShape(4.dp)
                    )
                    .padding(3.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = label,
                    tint = activeColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            if (badgeCount > 0) {
                Box(
                    modifier = Modifier
                        .size(14.dp)
                        .clip(CircleShape)
                        .background(CyberRed)
                        .align(Alignment.TopEnd)
                        .offset(x = 6.dp, y = (-4).dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = badgeCount.toString(),
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Text(
            text = label.uppercase(),
            fontSize = 8.sp,
            color = activeColor,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

@Composable
fun DashboardView(viewModel: GuardianViewModel) {
    val status by viewModel.protectionStatus.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()
    val scanProgress by viewModel.scanProgress.collectAsStateWithLifecycle()
    
    val statsScanned by viewModel.statsScanned.collectAsStateWithLifecycle()
    val statsThreats by viewModel.statsThreats.collectAsStateWithLifecycle()
    val statsQuarantined by viewModel.statsQuarantined.collectAsStateWithLifecycle()
    val isServiceActive by viewModel.isServiceActive.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safe Shield Gauge
        item {
            ShieldGaugeSection(status = status, isScanning = isScanning, progress = scanProgress, onScanClick = {
                viewModel.startComprehensiveScan()
            })
        }

        // Active Toggle Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberGrey),
                border = BorderStroke(1.dp, CyberCyanDim),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Icon(
                            imageVector = if (isServiceActive) Icons.Default.Lock else Icons.Default.LockOpen,
                            tint = if (isServiceActive) CyberGreen else CyberRed,
                            contentDescription = "Protection status"
                        )
                        Column {
                            Text(
                                text = "الحماية المستمرة بالخلفية",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "Continuous Background Shield",
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                    Switch(
                        checked = isServiceActive,
                        onCheckedChange = { viewModel.toggleService(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = CyberCyan,
                            checkedTrackColor = CyberCyanDim,
                            uncheckedThumbColor = Color.Gray,
                            uncheckedTrackColor = Color.Black
                        )
                    )
                }
            }
        }

        // Stats Counters
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatsCounterCard(
                    modifier = Modifier.weight(1f),
                    titleAr = "المفحوصة",
                    titleEn = "SCANNED",
                    count = statsScanned,
                    color = CyberCyan
                )
                StatsCounterCard(
                    modifier = Modifier.weight(1f),
                    titleAr = "التهديدات المصدودة",
                    titleEn = "BLOCKED",
                    count = statsThreats,
                    color = if (statsThreats > 0) CyberRed else CyberGreen
                )
                StatsCounterCard(
                    modifier = Modifier.weight(1f),
                    titleAr = "المحجوزة",
                    titleEn = "QUARANTINE",
                    count = statsQuarantined,
                    color = if (statsQuarantined > 0) CyberYellow else CyberCyan
                )
            }
        }

        // Attacker Attack Simulator Section (CRITICAL FOR DECONSTRUCTING THREATS)
        item {
            AttackerSimulatorCard(onSimulateThreat = { threatType ->
                viewModel.simulateMaliciousIncomingFile(threatType)
            })
        }
    }
}

@Composable
fun ShieldGaugeSection(status: String, isScanning: Boolean, progress: Float, onScanClick: () -> Unit) {
    val statusColor = when (status) {
        "ALERT" -> CyberRed
        "WARNING" -> CyberYellow
        else -> CyberGreen
    }

    val statusTextAr = when (status) {
        "ALERT" -> "تم صد هجمات خبيثة"
        "WARNING" -> "تحذير: سلوك مشبوه"
        else -> "واتساب محمي بالكامل"
    }

    val statusTextEn = when (status) {
        "ALERT" -> "ACTIVE PAYLOADS QUARANTINED"
        "WARNING" -> "SUSPICIOUS ACTIVITY LIMIT"
        else -> "WHATSAPP END-TO-END SECURED"
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Box(
            modifier = Modifier
                .height(260.dp)
                .fillMaxWidth(),
            contentAlignment = Alignment.Center
        ) {
            // Sophisticated concentric outer circles from the design HTML
            Box(
                modifier = Modifier
                    .size(256.dp)
                    .border(1.dp, CyberCyan.copy(alpha = 0.1f), CircleShape)
            )

            Box(
                modifier = Modifier
                    .size(208.dp)
                    .border(1.dp, CyberCyan.copy(alpha = 0.2f), CircleShape)
            )

            // Inner circle: w-40 h-40 (160.dp), border-4 with glow/shadow
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .shadow(
                        elevation = 20.dp,
                        shape = CircleShape,
                        ambientColor = statusColor.copy(alpha = 0.4f),
                        spotColor = statusColor.copy(alpha = 0.4f)
                    )
                    .background(CyberBlack, CircleShape)
                    .border(4.dp, statusColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    if (isScanning) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            modifier = Modifier.size(32.dp),
                            strokeWidth = 3.dp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "${(progress * 100).toInt()}%",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = CyberCyan
                        )
                    } else {
                        Text(
                            text = if (status == "ALERT") "⚠" else if (status == "WARNING") "⚡" else "✓",
                            color = statusColor,
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (status == "ALERT") "ALERT" else if (status == "WARNING") "WARNING" else "SECURED",
                            color = statusColor.copy(alpha = 0.7f),
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp
                        )
                    }
                }
            }
        }

        // Title and description under the gauge
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Text(
                text = if (status == "ALERT") "WhatsApp Under Threat" else if (status == "WARNING") "WhatsApp Suspicious" else "WhatsApp Protected",
                color = Color.White,
                fontWeight = FontWeight.Light,
                fontSize = 24.sp,
                textAlign = TextAlign.Center
            )
            
            Text(
                text = if (isScanning) "SCANNING PAYLOAD CHUNKS IN SYSTEM BUFFER..." else "LAST ENTRY ANALYZED: IMAGE_7721.WEBP",
                color = Color.Gray,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Normal,
                letterSpacing = 0.5.sp,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = statusTextAr,
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = statusTextEn,
                color = statusColor,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )
        }

        // Action button (Instant Scan) Styled exactly like the HTML:
        Button(
            onClick = onScanClick,
            enabled = !isScanning,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .shadow(
                    elevation = 12.dp,
                    shape = RoundedCornerShape(16.dp),
                    spotColor = CyberCyan.copy(alpha = 0.4f)
                )
                .testTag("scan_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = CyberCyan,
                contentColor = CyberBlack,
                disabledContainerColor = CyberGrey
            ),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Scan icon",
                    modifier = Modifier.size(16.dp)
                )
                Text(
                    text = (if (isScanning) "فحص وتأمين النشاط..." else "فحص فوري شامل للواتساب").uppercase(),
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
fun StatsCounterCard(modifier: Modifier, titleAr: String, titleEn: String, count: Int, color: Color) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberGrey),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = titleEn.uppercase(),
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = Color.Gray,
                letterSpacing = 1.sp,
                textAlign = TextAlign.Center
            )
            Text(
                text = titleAr,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color.LightGray,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 1.dp, bottom = 4.dp)
            )
            Text(
                text = count.toString(),
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = color
            )
        }
    }
}

@Composable
fun AttackerSimulatorCard(onSimulateThreat: (String) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberGrey),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.BugReport,
                    tint = CyberRed,
                    contentDescription = "Bug"
                )
                Column {
                    Text(
                        text = "محاكاة هجوم سيبراني لاختبار محرك الفحص",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Attack Simulator (Threat Injection)",
                        color = CyberRed,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Text(
                text = "اختر أحد الهجمات السيبرانية لعام 2026 لتوليد ملف ملغم آمن داخل ذاكرة التطبيق واختبار قدرة محرك الفحص وعزل التهديد فوراً في الحجر الصحي:",
                color = Color.LightGray,
                fontSize = 11.sp,
                lineHeight = 16.sp
            )

            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SimulatorButton(
                    labelAr = "حقن استغلال ثغرة WebP (Zero-Click) CVE-2023-4863",
                    labelEn = "Inject WebP Zero-Click Exploit",
                    onClick = { onSimulateThreat("webp_exploit") },
                    accentColor = CyberRed
                )
                SimulatorButton(
                    labelAr = "ملف ملغم APK مخفي داخل صورة Polyglot (JPEG-ZIP)",
                    labelEn = "Inject Polyglot Hidden APK Payload",
                    onClick = { onSimulateThreat("polyglot_apk") },
                    accentColor = CyberYellow
                )
                SimulatorButton(
                    labelAr = "حقن أكواد برمجية خبيثة في ترويسة EXIF للملفات",
                    labelEn = "Inject EXIF Header Code Script",
                    onClick = { onSimulateThreat("exif_injection") },
                    accentColor = CyberCyan
                )
                SimulatorButton(
                    labelAr = "حقن تروجان خبيث لاستبدال مجلد النسخ الاحتياطي للواتساب",
                    labelEn = "Simulate Backup Poisoning Trojan",
                    onClick = { onSimulateThreat("backup_poisoning") },
                    accentColor = CyberRed
                )
                SimulatorButton(
                    labelAr = "توليد صورة الإبلاغ المخادعة لثغرة حظر الحسابات",
                    labelEn = "Simulate Meta Auto-Suspension Image Scam",
                    onClick = { onSimulateThreat("ban_scam") },
                    accentColor = CyberYellow
                )
            }
        }
    }
}

@Composable
fun SimulatorButton(labelAr: String, labelEn: String, onClick: () -> Unit, accentColor: Color) {
    OutlinedButton(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.5f)),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = Color.White,
            containerColor = CyberBlack.copy(alpha = 0.4f)
        )
    ) {
        Column(horizontalAlignment = Alignment.Start, modifier = Modifier.fillMaxWidth()) {
            Text(
                text = labelAr,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Text(
                text = labelEn,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = accentColor,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun QuarantineView(viewModel: GuardianViewModel) {
    val quarantined by viewModel.quarantinedFiles.collectAsStateWithLifecycle()
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Column {
            Text(
                text = "ملفات الحجر الصحي والتهديدات المعزولة",
                color = Color.White,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "SANDBOX QUARANTINE MANAGER",
                color = CyberYellow,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }

        if (quarantined.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, CyberCyanDim, RoundedCornerShape(8.dp))
                    .background(CyberGrey.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.padding(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        tint = CyberGreen,
                        modifier = Modifier.size(48.dp),
                        contentDescription = "Empty quarantine"
                    )
                    Text(
                        text = "مجلد الحجر فارغ تماماً",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "No threats quarantined. Your media folder is currently pristine.",
                        color = Color.Gray,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(quarantined, key = { it.id }) { file ->
                    QuarantinedFileCard(
                        file = file,
                        onDestroyClick = { viewModel.deleteFileCompletely(file.id) },
                        onRestoreClick = { 
                            viewModel.restoreFileFromQuarantine(file)
                            Toast.makeText(context, "File restored safely to local storage", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
}

@Composable
fun QuarantinedFileCard(
    file: ScannedFile,
    onDestroyClick: () -> Unit,
    onRestoreClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberGrey),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(
                        imageVector = Icons.Default.Dangerous,
                        tint = CyberRed,
                        modifier = Modifier.size(24.dp),
                        contentDescription = "Infected"
                    )
                    Column {
                        Text(
                            text = file.fileName,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = "Size: ${file.fileSize} bytes | Format: ${file.fileType}",
                            fontSize = 10.sp,
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(CyberRedDim)
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = "QUARANTINED",
                        color = CyberRed,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Exploit / Payload Description Box
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberBlack)
                    .border(1.dp, CyberRedDim, RoundedCornerShape(4.dp))
                    .padding(10.dp)
            ) {
                Text(
                    text = file.threatType ?: "تهديد غير معروف",
                    fontWeight = FontWeight.Bold,
                    color = CyberRed,
                    fontSize = 12.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = file.threatDetail ?: "تم عزل هذا الملف نظراً لمخالفته ترويسات الأمان الأساسية.",
                    color = Color.LightGray,
                    fontSize = 10.sp,
                    lineHeight = 14.sp
                )
            }

            // Quick Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRestoreClick,
                    border = BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = "Restore", modifier = Modifier.size(16.dp))
                        Text("استعادة للملف", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Button(
                    onClick = onDestroyClick,
                    shape = RoundedCornerShape(4.dp),
                    modifier = Modifier.weight(1.5f),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed, contentColor = Color.White)
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.DeleteForever, contentDescription = "Destroy", modifier = Modifier.size(16.dp))
                        Text("حذف وتدمير نهائي", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun BehaviorView(viewModel: GuardianViewModel) {
    val messagesCount by viewModel.messagesSentCount.collectAsStateWithLifecycle()
    val groupsCount by viewModel.groupsJoinedCount.collectAsStateWithLifecycle()
    val isEmergencyActive by viewModel.isEmergencyMode.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column {
                Text(
                    text = "مراقبة النشاط وتفادي حظر الحساب",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "WHATSAPP BEHAVIOR LIMIT METERS",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Emergency Shield Lock Mode (Matrix Screen effect!)
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isEmergencyActive) CyberRedDim else CyberGrey
                ),
                border = BorderStroke(1.dp, if (isEmergencyActive) CyberRed else CyberCyanDim),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isEmergencyActive) Icons.Default.GppBad else Icons.Default.GppGood,
                                tint = if (isEmergencyActive) CyberRed else CyberGreen,
                                contentDescription = "Shield"
                            )
                            Column {
                                Text(
                                    text = "درع الطوارئ لمنع الحظر",
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "Anti-Ban Emergency Mute Shield",
                                    color = if (isEmergencyActive) CyberRed else Color.LightGray,
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                        
                        Switch(
                            checked = isEmergencyActive,
                            onCheckedChange = { viewModel.toggleEmergencyMode(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = CyberRed,
                                checkedTrackColor = CyberRedDim
                            )
                        )
                    }

                    Text(
                        text = "عند تشغيل وضع الطوارئ، سيقوم التطبيق بتعطيل بث اتصالات حزم الميديا لشبكة واتساب مؤقتاً لتفادي عمليات الفحص الآلي لمزود الخدمة (Meta AI Spam Detector) التي قد تؤدي لحظر حسابك فوراً.",
                        color = Color.LightGray,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    if (isEmergencyActive) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color.Black)
                                .border(1.dp, CyberRed, RoundedCornerShape(4.dp))
                                .padding(12.dp)
                        ) {
                            Text(
                                text = ">>> MATRIX LOCKED: ANTI-BAN TRANSMISSION BROADCASTS SUSPENDED. DEVICE VECTOR INSECURE BUT METRICS FROZEN.",
                                color = CyberRed,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Message storm limit meter
        item {
            BehaviorMeterCard(
                titleAr = "معدل الرسائل المرسلة (خلال 5 دقائق)",
                titleEn = "Message storm rate limit (5m)",
                currentCount = messagesCount,
                maxLimit = 40,
                color = if (messagesCount > 40) CyberRed else if (messagesCount > 25) CyberYellow else CyberGreen
            )
        }

        // Group join limits
        item {
            BehaviorMeterCard(
                titleAr = "معدل الانضمام للمجموعات (خلال ساعة)",
                titleEn = "Group addition storm limit (1h)",
                currentCount = groupsCount,
                maxLimit = 8,
                color = if (groupsCount > 8) CyberRed else if (groupsCount > 5) CyberYellow else CyberGreen
            )
        }

        // Activity simulator actions
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberGrey),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "محاكاة سلوك مستخدم واتساب",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.simulateWhatsAppActivity("send_message") },
                            enabled = !isEmergencyActive,
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack)
                        ) {
                            Text("إرسال رسالة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = { viewModel.simulateWhatsAppActivity("join_groups") },
                            enabled = !isEmergencyActive,
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBlack)
                        ) {
                            Text("انضمام لمجموعة", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        OutlinedButton(
                            onClick = { viewModel.simulateWhatsAppActivity("reset") },
                            modifier = Modifier.weight(1f).height(40.dp),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                        ) {
                            Text("تصفير العداد", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun BehaviorMeterCard(
    titleAr: String,
    titleEn: String,
    currentCount: Int,
    maxLimit: Int,
    color: Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CyberGrey),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column {
                Text(
                    text = titleAr,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    fontSize = 13.sp
                )
                Text(
                    text = titleEn,
                    color = Color.Gray,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Bottom
            ) {
                Text(
                    text = "$currentCount / $maxLimit",
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = color,
                    fontSize = 18.sp
                )
                Text(
                    text = if (currentCount > maxLimit) "DANGER VECTOR" else "SAFE PROFILE",
                    color = color,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 9.sp
                )
            }

            // Linear gauge progress bar
            val animatedProgress by animateFloatAsState(
                targetValue = (currentCount.toFloat() / maxLimit.toFloat()).coerceIn(0f, 1.2f),
                animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow),
                label = "progress"
            )

            LinearProgressIndicator(
                progress = { animatedProgress.coerceIn(0f, 1f) },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = color,
                trackColor = CyberBlack
            )
        }
    }
}

@Composable
fun CVEsView(viewModel: GuardianViewModel) {
    val vulnerabilities by viewModel.vulnerabilities.collectAsStateWithLifecycle()
    val isScanning by viewModel.isScanning.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "قاعدة بيانات توقيع الثغرات",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "EXPLOIT VULNERABILITY CVE SIGNATURES",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Sync with Cloud Button
            IconButton(
                onClick = { viewModel.syncVulnerabilities() },
                enabled = !isScanning,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCyanDim)
                    .border(1.dp, CyberCyan, RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.Sync,
                    contentDescription = "Cloud update sync",
                    tint = CyberCyan
                )
            }
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(vulnerabilities, key = { it.id }) { cve ->
                CVECard(cve = cve)
            }
        }
    }
}

@Composable
fun CVECard(cve: Vulnerability) {
    val severityColor = when (cve.severity) {
        "CRITICAL" -> CyberRed
        "HIGH" -> CyberRed
        "MEDIUM" -> CyberYellow
        else -> CyberCyan
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = CyberGrey),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = cve.id,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyan,
                        fontSize = 14.sp
                    )
                    Text(
                        text = cve.title,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 12.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(severityColor.copy(alpha = 0.15f))
                        .border(1.dp, severityColor, RoundedCornerShape(4.dp))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = cve.severity,
                        color = severityColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Divider(color = Color.DarkGray.copy(alpha = 0.5f))

            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "TARGET FORMAT:",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = cve.fileType,
                        fontFamily = FontFamily.Monospace,
                        color = Color.White,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "SIGNATURE RAW:",
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color.Gray,
                        fontSize = 10.sp
                    )
                    Text(
                        text = cve.signaturePattern,
                        fontFamily = FontFamily.Monospace,
                        color = CyberCyan,
                        fontSize = 10.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            Text(
                text = cve.description,
                color = Color.LightGray,
                fontSize = 11.sp,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
fun LogsView(viewModel: GuardianViewModel) {
    val behaviorLogs by viewModel.behaviorLogs.collectAsStateWithLifecycle()
    val scannedFiles by viewModel.scannedFiles.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "سجل الأحداث والعمليات النشطة",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "PROTECTIVE SYSTEM SECURITY LOGS",
                    color = CyberCyan,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }

            // Clear Log Button
            IconButton(
                onClick = { viewModel.clearLogs() },
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberRedDim)
                    .border(1.dp, CyberRed, RoundedCornerShape(8.dp))
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = "Clear all database logs",
                    tint = CyberRed
                )
            }
        }

        // Consolidated List of log events
        if (behaviorLogs.isEmpty() && scannedFiles.isEmpty()) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .border(1.dp, CyberCyanDim, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = ">>> LOG SHELL SECURE. NO EVENTS RECORDED.",
                    fontFamily = FontFamily.Monospace,
                    color = Color.Gray,
                    fontSize = 12.sp
                )
            }
        } else {
            val format = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
            
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Render behavior logs
                items(behaviorLogs) { log ->
                    LogEventLine(
                        time = format.format(Date(log.timestamp)),
                        category = log.actionType,
                        message = log.description,
                        isDanger = log.riskScore > 50
                    )
                }

                // Render scanner file results
                items(scannedFiles) { file ->
                    LogEventLine(
                        time = format.format(Date(file.timestamp)),
                        category = if (file.status == "SAFE") "SCAN_PASS" else "MALWARE_ALERT",
                        message = "Scanned file '${file.fileName}' -> Result: ${file.status}" + (if (file.threatType != null) " [${file.threatType}]" else ""),
                        isDanger = file.status == "QUARANTINED"
                    )
                }
            }
        }
    }
}

@Composable
fun LogEventLine(time: String, category: String, message: String, isDanger: Boolean) {
    val termColor = if (isDanger) CyberRed else CyberCyan
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(CyberBlack)
            .border(1.dp, if (isDanger) CyberRedDim else CyberCyanDim, RoundedCornerShape(4.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.Top
    ) {
        Column(modifier = Modifier.width(60.dp)) {
            Text(
                text = time,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.Gray
            )
        }
        
        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(3.dp))
                        .background(termColor.copy(alpha = 0.15f))
                        .border(1.dp, termColor.copy(alpha = 0.5f), RoundedCornerShape(3.dp))
                        .padding(horizontal = 4.dp, vertical = 1.dp)
                ) {
                    Text(
                        text = category,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = termColor
                    )
                }
            }
            Text(
                text = message,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                color = Color.White,
                lineHeight = 15.sp
            )
        }
    }
}

@Composable
fun MatrixBackgroundEffect() {
    // Elegant background Canvas to render a digital cyber security layout grid
    Canvas(modifier = Modifier.fillMaxSize()) {
        val gridSpacing = 20.dp.toPx()
        
        // Draw vertical lines
        var x = 0f
        while (x < size.width) {
            drawLine(
                color = CyberCyan.copy(alpha = 0.03f),
                start = Offset(x, 0f),
                end = Offset(x, size.height),
                strokeWidth = 1f
            )
            x += gridSpacing
        }

        // Draw horizontal lines
        var y = 0f
        while (y < size.height) {
            drawLine(
                color = CyberCyan.copy(alpha = 0.03f),
                start = Offset(0f, y),
                end = Offset(size.width, y),
                strokeWidth = 1f
            )
            y += gridSpacing
        }
    }
}

@Composable
fun SubscriptionGateView(viewModel: GuardianViewModel) {
    val context = LocalContext.current
    var hasClickedYoutube by remember { mutableStateOf(false) }
    var hasClickedTelegram by remember { mutableStateOf(false) }
    var hasClickedFacebook by remember { mutableStateOf(false) }
    
    var isVerifying by remember { mutableStateOf(false) }
    var verifyProgress by remember { mutableStateOf(0f) }
    var verificationStep by remember { mutableStateOf("") }
    
    val scope = rememberCoroutineScope()
    
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberBlack),
        contentAlignment = Alignment.Center
    ) {
        MatrixBackgroundEffect()
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 10.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(CyberGrey)
                        .border(1.5.dp, CyberCyan, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = "Shield Logo",
                        tint = CyberCyan,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "بوابة التنشيط والأمان ⚡",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 22.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "HamO Guardian - حمو الإلكتروني",
                    color = CyberCyan,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "لتفعيل وتنشيط حماية الواتساب بشكل كامل ومجاني ضد كافة أنواع التجسس وسحب الجلسات واختراق الرومات وحظر الحسابات، يرجى الاشتراك في قنوات الدعم والمتابعة الرسمية للمطور حمو الإلكتروني أدناه:",
                    color = Color.LightGray,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 18.sp
                )
            }
            
            // Channel Buttons
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Youtube Card
                SubscriptionCard(
                    title = "قناة اليوتيوب (الشروحات التقنية والأمنية)",
                    subtitle = "youtube.com/@hamoelectronic",
                    icon = Icons.Default.PlayCircle,
                    statusText = if (hasClickedYoutube) "تم الفحص الأولي ✓" else "اضغط للاشتراك الآن 🔴",
                    statusColor = if (hasClickedYoutube) CyberGreen else CyberRed,
                    onClick = {
                        hasClickedYoutube = true
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://youtube.com/@hamoelectronic?si=evP0mtha18f5I0_I"))
                        context.startActivity(intent)
                    }
                )

                // Telegram Card
                SubscriptionCard(
                    title = "قناة التليجرام (تحديثات الثغرات الأمنية)",
                    subtitle = "t.me/hamoelctronic2007",
                    icon = Icons.Default.Send,
                    statusText = if (hasClickedTelegram) "تم الفحص الأولي ✓" else "اضغط للانضمام الآن 🔴",
                    statusColor = if (hasClickedTelegram) CyberGreen else CyberRed,
                    onClick = {
                        hasClickedTelegram = true
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/hamoelctronic2007"))
                        context.startActivity(intent)
                    }
                )

                // Facebook Card
                SubscriptionCard(
                    title = "حساب الفيسبوك الرسمي للمطور",
                    subtitle = "facebook.com/profile.php?id=100093514551810",
                    icon = Icons.Default.Person,
                    statusText = if (hasClickedFacebook) "تم الفحص الأولي ✓" else "اضغط للمتابعة الآن 🔴",
                    statusColor = if (hasClickedFacebook) CyberGreen else CyberRed,
                    onClick = {
                        hasClickedFacebook = true
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.facebook.com/profile.php?id=100093514551810"))
                        context.startActivity(intent)
                    }
                )
            }
            
            // Verify / Action Button
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (isVerifying) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        LinearProgressIndicator(
                            progress = { verifyProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(6.dp)
                                .clip(RoundedCornerShape(3.dp)),
                            color = CyberCyan,
                            trackColor = CyberGrey
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = verificationStep,
                            color = CyberCyan,
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center
                        )
                    }
                } else {
                    val isAllClicked = hasClickedYoutube && hasClickedTelegram && hasClickedFacebook
                    Button(
                        onClick = {
                            if (isAllClicked) {
                                isVerifying = true
                                scope.launch {
                                    verificationStep = "📡 جاري الاتصال بخادم حمو الإلكتروني..."
                                    verifyProgress = 0.1f
                                    delay(800)
                                    
                                    verificationStep = "🔍 فحص هوية المشترك عبر المعرفات الرقمية..."
                                    verifyProgress = 0.35f
                                    delay(1000)
                                    
                                    verificationStep = "⚡ التحقق من تفعيل التنبيهات والاشتراك الفعلي..."
                                    verifyProgress = 0.65f
                                    delay(1000)
                                    
                                    verificationStep = "🛡️ التحقق من سلامة كود التطبيق وتوقيع APK..."
                                    verifyProgress = 0.85f
                                    delay(800)
                                    
                                    verificationStep = "✅ تم التحقق والربط بنجاح! جاري تفعيل الحماية..."
                                    verifyProgress = 1.0f
                                    delay(600)
                                    
                                    viewModel.setActivated(true)
                                    isVerifying = false
                                }
                            } else {
                                Toast.makeText(context, "يرجى فتح جميع قنوات الاشتراك والمتابعة أولاً لتفعيل الخدمة!", Toast.LENGTH_LONG).show()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(56.dp)
                            .shadow(
                                elevation = 12.dp,
                                shape = RoundedCornerShape(16.dp),
                                spotColor = if (isAllClicked) CyberCyan.copy(alpha = 0.4f) else Color.Transparent
                            ),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isAllClicked) CyberCyan else CyberGrey,
                            contentColor = if (isAllClicked) CyberBlack else Color.Gray
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text(
                            text = "التحقق الأمني وتفعيل الحماية 🛡️",
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "تنبيه: يتم التحقق دورياً من حالة الاشتراك. إلغاء أي متابعة سيؤدي لتعطيل الفحص التلقائي.",
                        color = Color.Gray,
                        fontSize = 9.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
fun SubscriptionCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    statusText: String,
    statusColor: Color,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = CyberGrey),
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberBlack),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = "Social Icon",
                        tint = statusColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Column {
                    Text(
                        text = title,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    Text(
                        text = subtitle,
                        color = Color.Gray,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 9.sp
                    )
                }
            }
            Text(
                text = statusText,
                color = statusColor,
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun TamperOverlayView() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF070000)),
        contentAlignment = Alignment.Center
    ) {
        MatrixBackgroundEffect()
        
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(CyberGrey)
                    .border(2.dp, CyberRed, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ReportProblem,
                    contentDescription = "Tamper Detected",
                    tint = CyberRed,
                    modifier = Modifier.size(40.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(24.dp))
            
            Text(
                text = "تم الكشف عن هندسة عكسية وتعديل برمجّي! 🚨",
                color = CyberRed,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "SECURITY INTEGRITY VIOLATION DETECTED",
                color = Color.Gray,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                textAlign = TextAlign.Center,
                letterSpacing = 1.sp
            )
            
            Spacer(modifier = Modifier.height(20.dp))
            
            Card(
                colors = CardDefaults.cardColors(containerColor = CyberGrey),
                border = BorderStroke(1.dp, CyberRed.copy(alpha = 0.3f)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "عذراً، هذا التطبيق محمي بالكامل برمجياً ضد العبث أو فك التجميع أو التعديل على الكود الأصلي وتعديل الباكيج نيم (Package Name) من قبل المطور حمو الإلكتروني.\n\nلقد تم قفل كافة خدمات تأمين وفحص الواتساب تلقائياً كإجراء أمني لحماية خصوصية وسرية بياناتك الحيوية.",
                    color = Color.White,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    lineHeight = 20.sp,
                    modifier = Modifier.padding(20.dp)
                )
            }
            
            Spacer(modifier = Modifier.height(30.dp))
            
            Text(
                text = "المطور: حمو الإلكتروني",
                color = CyberCyan,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}
