package com.example.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.SecurityLog
import com.example.data.VaultItem
import com.example.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HamoShieldScreen(
    viewModel: HamoShieldViewModel,
    modifier: Modifier = Modifier
) {
    val isUserLoggedIn by viewModel.isUserLoggedIn.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()

    // 0 = Dashboard, 1 = Protection (Stealth + Spyware Radar), 2 = Proxy/VPN, 3 = Vault, 4 = Tools/SMS, 5 = Settings
    var activeTab by remember { mutableStateOf(0) }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = BgPrimary
    ) {
        if (!isUserLoggedIn) {
            AuthScreen(viewModel = viewModel)
        } else if (!isSubscribed) {
            SubscriptionGateScreen(viewModel = viewModel)
        } else {
            // Main application shell
            Scaffold(
                containerColor = BgPrimary,
                topBar = {
                    CenterAlignedTopAppBar(
                        title = {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Lock,
                                    contentDescription = "Hamo Shield Alpha V5 Logo",
                                    tint = NeonCyan,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "حمو الإلكتروني V5",
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                            }
                        },
                        colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                            containerColor = BgSecondary
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = BgSecondary,
                        modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
                    ) {
                        NavigationBarItem(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            icon = { Icon(Icons.Default.Home, contentDescription = "الرئيسية") },
                            label = { Text("الرئيسية", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            icon = { Icon(Icons.Default.Search, contentDescription = "الرادار") },
                            label = { Text("الرادار", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            icon = { Icon(Icons.Default.Refresh, contentDescription = "بروكسي") },
                            label = { Text("البروكسي", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 3,
                            onClick = { activeTab = 3 },
                            icon = { Icon(Icons.Default.Lock, contentDescription = "الخزنة") },
                            label = { Text("الخزنة", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 4,
                            onClick = { activeTab = 4 },
                            icon = { Icon(Icons.Default.Build, contentDescription = "الأدوات") },
                            label = { Text("الأدوات", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                        NavigationBarItem(
                            selected = activeTab == 5,
                            onClick = { activeTab = 5 },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "بروتوكول") },
                            label = { Text("إعدادات", fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BgPrimary,
                                selectedTextColor = NeonCyan,
                                indicatorColor = NeonCyan,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .padding(innerPadding)
                        .fillMaxSize()
                        .background(BgPrimary)
                ) {
                    Crossfade(
                        targetState = activeTab,
                        animationSpec = spring(),
                        label = "TabReveal"
                    ) { tab ->
                        when (tab) {
                            0 -> DashboardTab(viewModel = viewModel)
                            1 -> RadarTab(viewModel = viewModel)
                            2 -> ProxyTab(viewModel = viewModel)
                            3 -> VaultTab(viewModel = viewModel)
                            4 -> ToolsTab(viewModel = viewModel)
                            5 -> SettingsTab(viewModel = viewModel)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AuthScreen(viewModel: HamoShieldViewModel) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var hasError by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(BgPrimary),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = "Hamo Cyber Armored Shield",
            tint = NeonCyan,
            modifier = Modifier.size(80.dp)
        )
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            "حمو الإلكتروني V5",
            color = TextPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        Text(
            "الدرع السيبراني المطلق لحماية أندرويد 2035",
            color = TechPurple,
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    "تسجيل الدخول للنظام الفرعي الآمن",
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it; hasError = false },
                    label = { Text("البريد الإلكتروني", color = TextSecondary) },
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = TechPurple,
                        focusedContainerColor = BgPrimary,
                        unfocusedContainerColor = BgPrimary
                    )
                )

                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it; hasError = false },
                    label = { Text("كلمة المرور المشفرة", color = TextSecondary) },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    modifier = Modifier.fillMaxWidth(),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = TechPurple,
                        focusedContainerColor = BgPrimary,
                        unfocusedContainerColor = BgPrimary
                    )
                )

                if (hasError) {
                    Text(
                        "⚠️ يرجى إدخال البريد الإلكتروني وكلمة مرور من 8 أحرف على الأقل",
                        color = DangerRed,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                Button(
                    onClick = {
                        val success = viewModel.login(email, password)
                        if (!success) {
                            hasError = true
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("دخول معزول TLS", color = BgPrimary, fontWeight = FontWeight.Bold)
                }

                HorizontalDivider(color = TechPurple.copy(alpha = 0.3f))

                Button(
                    onClick = { viewModel.googleSignIn() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, NeonCyan)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Google Secure Auth", tint = NeonCyan, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تسجيل دخول آمن بواسطة Google", color = NeonCyan)
                    }
                }
            }
        }
    }
}

@Composable
fun SubscriptionGateScreen(viewModel: HamoShieldViewModel) {
    val joinedYoutube by viewModel.joinedYoutube.collectAsState()
    val joinedTelegram by viewModel.joinedTelegram.collectAsState()
    val joinedFacebook by viewModel.joinedFacebook.collectAsState()
    val userEmail by viewModel.userEmail.collectAsState()

    var billingPhone by remember { mutableStateOf("") }
    var isSubmittedToVerify by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp)
            .background(BgPrimary),
        verticalArrangement = Arrangement.Top,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(20.dp))
        Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = "Subscription Shield lock",
            tint = DangerRed,
            modifier = Modifier.size(64.dp)
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text(
            "معقل حمو الإلكتروني مغلق",
            color = TextPrimary,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            "تفعيل تكنولوجيا الحماية الفولاذية المطلقة",
            color = TextSecondary,
            fontSize = 11.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 20.dp)
        )

        Card(
            colors = CardDefaults.cardColors(containerColor = BgSecondary),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalAlignment = Alignment.End
            ) {
                Text(
                    "بوابة التنشيط والدرع المالي",
                    color = NeonCyan,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp
                )

                Text(
                    "يتطلب ترخيص هذا الهاتف اشتراكاً شهرياً بقيمة 75 جنيه مصري (داخل مصر) أو 5 دولار أمريكي (خارج مصر) لتأمين النواة الدفاعية ضد كافة هجمات Zero-Day و Zero-Click.",
                    color = TextPrimary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Right,
                    lineHeight = 18.sp
                )

                Text(
                    "طرق التفعيل المعتمدة:",
                    color = TechPurple,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Text(
                    "• أورنج كاش للرقم: 01228135423 (محمد حسام أبو حسين)\n• باي بال (خارج مصر): hamo.electronic@example.com",
                    color = TextPrimary,
                    fontSize = 11.sp,
                    textAlign = TextAlign.Right
                )

                HorizontalDivider(color = TechPurple.copy(alpha = 0.3f))

                Text(
                    "الخطوة 1: انضم لمنصات حمو الإلكتروني الرسمية",
                    color = TechPurple,
                    fontWeight = FontWeight.Bold,
                    fontSize = 12.sp
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { viewModel.setJoinedSocial("youtube") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (joinedYoutube) SafeGreen else BgPrimary
                        ),
                        border = BorderStroke(1.dp, if (joinedYoutube) SafeGreen else DangerRed)
                    ) {
                        Text(if (joinedYoutube) "تم بنجاح" else "يوتيوب 📺", fontSize = 10.sp, color = TextPrimary)
                    }
                    Button(
                        onClick = { viewModel.setJoinedSocial("telegram") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (joinedTelegram) SafeGreen else BgPrimary
                        ),
                        border = BorderStroke(1.dp, if (joinedTelegram) SafeGreen else NeonCyan)
                    ) {
                        Text(if (joinedTelegram) "تم بنجاح" else "تيليجرام 🛡️", fontSize = 10.sp, color = TextPrimary)
                    }
                    Button(
                        onClick = { viewModel.setJoinedSocial("facebook") },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (joinedFacebook) SafeGreen else BgPrimary
                        ),
                        border = BorderStroke(1.dp, if (joinedFacebook) SafeGreen else TechPurple)
                    ) {
                        Text(if (joinedFacebook) "تم بنجاح" else "فيسبوك 👥", fontSize = 10.sp, color = TextPrimary)
                    }
                }

                HorizontalDivider(color = TechPurple.copy(alpha = 0.3f))

                if (!isSubmittedToVerify) {
                    Text(
                        "الخطوة 2: ارفع لقطة الشاشة وأثبت التحويل لإكمال الفحص:",
                        color = TechPurple,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                    OutlinedTextField(
                        value = billingPhone,
                        onValueChange = { billingPhone = it },
                        label = { Text("رقم الهاتف أو البريد الذي تم التحويل منه", color = TextSecondary, fontSize = 10.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = TechPurple,
                            focusedContainerColor = BgPrimary,
                            unfocusedContainerColor = BgPrimary
                        )
                    )
                    Button(
                        onClick = {
                            if (billingPhone.isNotBlank()) {
                                isSubmittedToVerify = true
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        modifier = Modifier.fillMaxWidth().height(40.dp)
                    ) {
                        Text("إرسال لقطة الشاشة وتأكيد الدفع", color = BgPrimary, fontWeight = FontWeight.Bold)
                    }
                } else {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgPrimary),
                        modifier = Modifier.fillMaxWidth().border(1.dp, WarningAmber, RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                            Text("⚠️ طلب التحقق قيد المراجعة الفنية", color = WarningAmber, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("جارٍ مراجعة تفاصيل التحويل المالي من قبل مهندسي حمو الإلكتروني. سيتم تفعيل ترخيص الدرع المطلق فوراً في غضون 24 ساعة كحد أقصى.", color = TextPrimary, fontSize = 11.sp, textAlign = TextAlign.Right)
                            TextButton(onClick = { viewModel.attemptSubscribe() }) {
                                Text("محاكاة تفعيل ترخيص (تجاوز المطور للمراجعة 🔓)", color = NeonCyan, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardTab(viewModel: HamoShieldViewModel) {
    val scanState by viewModel.scanState.collectAsState()
    val recentLogs by viewModel.recentLogs.collectAsState()
    val isVpnConnected by viewModel.isVpnConnected.collectAsState()
    val isStealthActive by viewModel.isStealthModeActive.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Core Security Score Gauge
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "الدرع السيبراني النهائي 2035",
                        color = NeonCyan,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    Box(
                        modifier = Modifier.size(160.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val strokeColor = if (scanState is ScanState.Completed) SafeGreen else WarningAmber
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            drawArc(
                                color = BgPrimary,
                                startAngle = 135f,
                                sweepAngle = 270f,
                                useCenter = false,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 16f)
                            )
                            drawArc(
                                color = strokeColor,
                                startAngle = 135f,
                                sweepAngle = if (scanState is ScanState.Completed) 270f else 110f,
                                useCenter = false,
                                style = androidx.compose.ui.graphics.drawscope.Stroke(
                                    width = 16f,
                                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                                )
                            )
                        }

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            val scoreStr = if (scanState is ScanState.Completed) "95%" else "30%"
                            Text(
                                text = scoreStr,
                                color = strokeColor,
                                fontSize = 36.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (scanState is ScanState.Completed) "الجهاز محصن بالكامل" else "درع ضعيف بحاجة لفحص",
                                color = TextSecondary,
                                fontSize = 10.sp,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        QuickStatItem(title = "اتصال مشفر VPN", value = if (isVpnConnected) "متصل" else "مغلق", isOk = isVpnConnected)
                        QuickStatItem(title = "وضع التخفي", value = if (isStealthActive) "نشط" else "مغلق", isOk = isStealthActive)
                        QuickStatItem(title = "فحص التلاعب", value = "سليم ✔️", isOk = true)
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (scanState is ScanState.Scanning) {
                        val scanning = scanState as ScanState.Scanning
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            LinearProgressIndicator(
                                progress = scanning.progress,
                                color = NeonCyan,
                                trackColor = BgPrimary,
                                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(scanning.currentTask, color = TextPrimary, fontSize = 12.sp, textAlign = TextAlign.Center)
                        }
                    } else {
                        Button(
                            onClick = { viewModel.startFullScan() },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Text("بدء الفحص الأمني الشامل المسرَّع 🚀", color = BgPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Emergency Lockdown Module
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, DangerRed, RoundedCornerShape(16.dp)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f), horizontalAlignment = Alignment.End) {
                        Text("حالة الطوارئ الفائقة (Lockdown)", color = DangerRed, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("يقوم بقطع كافة أجهزة الاتصال اللاسلكية بنقرة واحدة بمجرد الشك الفوري.", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Right)
                    }
                    IconButton(
                        onClick = { viewModel.toggleStealthMode() },
                        modifier = Modifier.size(52.dp).background(DangerRed, RoundedCornerShape(26.dp))
                    ) {
                        Icon(Icons.Default.Warning, contentDescription = "Lockdown", tint = TextPrimary)
                    }
                }
            }
        }

        // Live Security Intelligence Logs
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = { viewModel.clearAllLogs() }) {
                    Text("مسح السجل", color = TechPurple, fontSize = 11.sp)
                }
                Text("سجل الذكاء الأمني المباشر (Hamo SecLog)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
        }

        if (recentLogs.isEmpty()) {
            item {
                Text(
                    "لا توجد سجلات دفاعية حالية. ابدأ فحصاً لتحديث النواة.",
                    color = TextSecondary,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        } else {
            items(recentLogs) { log ->
                SecurityLogCard(log = log)
            }
        }
    }
}

@Composable
fun QuickStatItem(title: String, value: String, isOk: Boolean) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(title, color = TextSecondary, fontSize = 10.sp)
        Text(value, color = if (isOk) SafeGreen else DangerRed, fontWeight = FontWeight.Bold, fontSize = 12.sp)
    }
}

@Composable
fun SecurityLogCard(log: SecurityLog) {
    val indicatorColor = when (log.type) {
        "DANGER" -> DangerRed
        "SUCCESS" -> SafeGreen
        "ALERT" -> WarningAmber
        else -> NeonCyan
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = BgSecondary),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, indicatorColor.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
    ) {
        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp)),
                    color = TextSecondary,
                    fontSize = 11.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(log.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(modifier = Modifier.size(10.dp).background(indicatorColor, RoundedCornerShape(5.dp)))
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Text(log.message, color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right)
        }
    }
}

@Composable
fun RadarTab(viewModel: HamoShieldViewModel) {
    val isStealthActive by viewModel.isStealthModeActive.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                    Text("وضع التخفي المطبق (Stealth Radar)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("يقوم تفعيل هذا الوضع بتعطيل الميكروفون وهاردوير الكاميرا على مستوى نظام التشغيل حماية ضد هجمات الابتزاز والتجسس الكارثي.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, lineHeight = 18.sp)
                    Spacer(modifier = Modifier.height(16.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isStealthActive,
                            onCheckedChange = { viewModel.toggleStealthMode() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = BgPrimary,
                                checkedTrackColor = NeonCyan,
                                uncheckedThumbColor = TextSecondary,
                                uncheckedTrackColor = BgPrimary
                            )
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(if (isStealthActive) "وضع التخفي نشط بالكامل" else "معلق الآن", color = if (isStealthActive) SafeGreen else WarningAmber, fontSize = 13.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Icon(Icons.Default.Search, contentDescription = "Radar indicator", tint = if (isStealthActive) SafeGreen else TextSecondary)
                        }
                    }
                }
            }
        }

        item {
            Text("رادار التطبيقات الخبيثة وبرامج الساي الفتاكة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, DangerRed, RoundedCornerShape(12.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("تم عزل 3 برمجيات خبيثة", color = DangerRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Icon(Icons.Default.Info, contentDescription = "Active Threats Found", tint = DangerRed)
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    ThreatItem(name = "calculator_pro.apk", threatType = "حصان طروادة (Trojan SMS)", status = "تم العزل الكامل ✔️")
                    Spacer(modifier = Modifier.height(8.dp))
                    ThreatItem(name = "x_flash_spy.apk", threatType = "مسجل شاشة وموقع جغرافي مكثف", status = "تم حظر استدعائه ✔️")
                    Spacer(modifier = Modifier.height(8.dp))
                    ThreatItem(name = "temporary_root_shell.sh", threatType = "محاولة رفع صلاحيات النظام", status = "تدمير النواة ومنع التلاعب ✔️")
                }
            }
        }
    }
}

@Composable
fun ThreatItem(name: String, threatType: String, status: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(BgPrimary, RoundedCornerShape(8.dp))
            .padding(10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(status, color = SafeGreen, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Column(horizontalAlignment = Alignment.End) {
            Text(name, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(threatType, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
fun ProxyTab(viewModel: HamoShieldViewModel) {
    val isVpnConnected by viewModel.isVpnConnected.collectAsState()
    val selectedServer by viewModel.selectedVpnServer.collectAsState()

    val servers = listOf("القاهرة (مصر)", "الرياض (السعودية)", "دبي (الإمارات)", "واشنطن (أمريكا)", "برلين (ألمانيا)", "طوكيو (اليابان)")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp), horizontalAlignment = Alignment.End) {
                    Text("نفق التوجيه المشفر VPN (WireGuard)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("توجيه الاتصالات بنهج صفر مستندات Zero-Log حماية مخصصة ضد هجمات ARP الخبيثة في الشبكات المفتوحة والتوأم الشريرة.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Right, lineHeight = 18.sp)
                    Spacer(modifier = Modifier.height(20.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { viewModel.toggleVpn() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isVpnConnected) SafeGreen else NeonCyan
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(if (isVpnConnected) "تأمين نشط ✔️" else "اتصال عبر WireGuard", color = BgPrimary)
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text("الخادم الحالي:", color = TextSecondary, fontSize = 11.sp)
                            Text(selectedServer, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                }
            }
        }

        item {
            Text("اختر خادم الدفاع الآمن السحابي", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp, textAlign = TextAlign.Right, modifier = Modifier.fillMaxWidth())
        }

        items(servers) { server ->
            val isCurrent = server == selectedServer
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isCurrent) TechPurple.copy(alpha = 0.2f) else BgSecondary)
                    .border(1.dp, if (isCurrent) NeonCyan else TechPurple.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                    .clickable { viewModel.setVpnServer(server) }
                    .padding(16.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isCurrent) {
                    Icon(Icons.Default.Check, contentDescription = "Selected", tint = NeonCyan)
                } else {
                    Box(modifier = Modifier.size(24.dp))
                }
                Text(server, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }
    }
}

@Composable
fun VaultTab(viewModel: HamoShieldViewModel) {
    val vaultItems by viewModel.vaultItems.collectAsState()

    var showAddDialog by remember { mutableStateOf(false) }
    var passcode by remember { mutableStateOf("") }
    var passcodeVerified by remember { mutableStateOf(false) }
    var passcodeError by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        if (!passcodeVerified) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = BgSecondary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
                ) {
                    Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Lock, contentDescription = "Vault Locked", tint = DangerRed, modifier = Modifier.size(52.dp))
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("الخزنة الرقمية الفولاذية مشفرة", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("يرجى إدخال رمز المرور الخماسي AES AES لفك تشفير المحتويات العائلية الآمنة.", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Center)

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = passcode,
                            onValueChange = { passcode = it; passcodeError = false },
                            label = { Text("رمز المرور السري (Passcode)", color = TextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            visualTransformation = PasswordVisualTransformation(),
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = TechPurple,
                                focusedContainerColor = BgPrimary,
                                unfocusedContainerColor = BgPrimary
                            )
                        )

                        if (passcodeError) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("رمز المرور المدخل خاطئ أو غير كافٍ. جرب '123456'", color = DangerRed, fontSize = 11.sp)
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = {
                                if (passcode == "123456" || passcode.length >= 6) {
                                    passcodeVerified = true
                                } else {
                                    passcodeError = true
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("التحقق وفك التشفير الآمن", color = BgPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            // Authorized Vault Display
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { showAddDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Add, contentDescription = "Add password", tint = BgPrimary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("تشفير عنصر جديد", color = BgPrimary)
                        }
                    }

                    Text("سجلات الخزنة المؤمنة (AES-256)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }

            if (vaultItems.isEmpty()) {
                item {
                    Text("لا توجد ملفات مشفرة حالياً. انقر على الزر لتأمين مستند ممتاز.", color = TextSecondary, fontSize = 12.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(top = 40.dp))
                }
            } else {
                items(vaultItems) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = BgSecondary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, TechPurple.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.End) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = { viewModel.deleteVaultItem(item.id) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete from Vault", tint = DangerRed)
                                }
                                Text(item.title, color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Text("اسم المستخدم التكنولوجي: ${item.username}", color = TextPrimary, fontSize = 12.sp)
                            Text("المفتاح المشفر: ********", color = SafeGreen, fontSize = 12.sp)
                            if (item.secretNote.isNotEmpty()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("الملاحظة السرية: ${item.secretNote}", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Right)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddDialog) {
        var title by remember { mutableStateOf("") }
        var username by remember { mutableStateOf("") }
        var passVal by remember { mutableStateOf("") }
        var secretNote by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddDialog = false }) {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = BgSecondary,
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    horizontalAlignment = Alignment.End
                ) {
                    Text("إضافة عنصر للخزنة العسكرية", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 15.sp)

                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        label = { Text("معرّف الخدمة (مثل بريد ياهو)", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = TechPurple
                        )
                    )

                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("اسم الحساب", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = TechPurple
                        )
                    )

                    OutlinedTextField(
                        value = passVal,
                        onValueChange = { passVal = it },
                        label = { Text("المفتاح أو كلمة المرور", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = TechPurple
                        )
                    )

                    OutlinedTextField(
                        value = secretNote,
                        onValueChange = { secretNote = it },
                        label = { Text("مذكرة تشفير مخصصة", color = TextSecondary) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = TechPurple
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { showAddDialog = false },
                            colors = ButtonDefaults.buttonColors(containerColor = BgPrimary),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("إلغاء", color = TextPrimary)
                        }
                        Button(
                            onClick = {
                                if (title.isNotEmpty() && username.isNotEmpty()) {
                                    viewModel.addVaultItem(title, username, passVal, secretNote)
                                    showAddDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("تشفير فوري", color = BgPrimary, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolsTab(viewModel: HamoShieldViewModel) {
    val terminalOutput by viewModel.terminalOutput.collectAsState()
    var terminalInput by remember { mutableStateOf("") }

    var pastedLink by remember { mutableStateOf("") }
    var linkResult by remember { mutableStateOf<String?>(null) }
    var resultPercent by remember { mutableStateOf(0) }

    val focusManager = LocalFocusManager.current

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Micro-OS Console Terminal
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "طرفية حمو السيبرانية (Terminal Shell)",
                        color = NeonCyan,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                        textAlign = TextAlign.Right,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Text log terminal
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .background(BgPrimary, RoundedCornerShape(8.dp))
                            .border(1.dp, TechPurple.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(8.dp)
                    ) {
                        LazyColumn(reverseLayout = true) {
                            items(terminalOutput.reversed()) { line ->
                                Text(
                                    line,
                                    color = if (line.startsWith(">")) NeonCyan else TextPrimary,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    fontSize = 11.sp,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                if (terminalInput.isNotBlank()) {
                                    viewModel.executeTerminalCommand(terminalInput)
                                    terminalInput = ""
                                    focusManager.clearFocus()
                                }
                            }
                        ) {
                            Icon(Icons.Default.Send, contentDescription = "Execute Command", tint = NeonCyan)
                        }

                        OutlinedTextField(
                            value = terminalInput,
                            onValueChange = { terminalInput = it },
                            placeholder = { Text("أدخل الأوامر مثل netstat أو help...", color = TextSecondary, fontSize = 11.sp) },
                            modifier = Modifier.weight(1f),
                            textStyle = TextStyle(fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace, fontSize = 11.sp, color = TextPrimary),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonCyan,
                                unfocusedBorderColor = TechPurple,
                                focusedContainerColor = BgPrimary,
                                unfocusedContainerColor = BgPrimary
                            )
                        )
                    }
                }
            }
        }

        // Link SMS Phishing Analyzer Simulator
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("محلل الروابط والشات (Zero-Click Shield)", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("صق الرابط المشبوه لتحليله فوراً بواسطة خوارزمية فحص النطاقات وعزل المخاطر.", color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Right)

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = pastedLink,
                        onValueChange = { pastedLink = it },
                        placeholder = { Text("http://example-danger.click", color = TextSecondary, fontSize = 12.sp) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            focusedBorderColor = NeonCyan,
                            unfocusedBorderColor = TechPurple
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            if (pastedLink.contains("gift") || pastedLink.contains("reward") || pastedLink.contains("click")) {
                                linkResult = "⚠️ تم الكشف عن رابط تصيد وهمي عالي التهديد. النطاق يحاول سرقة ملفات الارتباط وكلمات المرور المخزنة."
                                resultPercent = 98
                            } else {
                                linkResult = "✔️ النطاق يبدو طبيعياً ولكن كن حذراً عند إدخال بيانات بنكية."
                                resultPercent = 5
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("بدء تحليل التهديد الفوري", color = BgPrimary, fontWeight = FontWeight.Bold)
                    }

                    linkResult?.let { res ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = BgPrimary),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, if (resultPercent > 50) DangerRed else SafeGreen, RoundedCornerShape(12.dp))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), horizontalAlignment = Alignment.End) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("تأثير الخطر: $resultPercent%", color = if (resultPercent > 50) DangerRed else SafeGreen, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    Text("نتيجة الفحص التكنولوجي", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(res, color = TextSecondary, fontSize = 11.sp, textAlign = TextAlign.Right)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTab(viewModel: HamoShieldViewModel) {
    val userEmail by viewModel.userEmail.collectAsState()
    val isSubscribed by viewModel.isSubscribed.collectAsState()
    val isNfcProtected by viewModel.isNfcProtected.collectAsState()
    val isUssdProtected by viewModel.isUssdProtected.collectAsState()
    val isAdBlockActive by viewModel.isAdBlockActive.collectAsState()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // User Profile Block
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("المستخدم المرخص لديه", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("البريد الإلكتروني: $userEmail", color = TextPrimary, fontSize = 13.sp)
                    Text(
                        "حالة حماية الدرع: " + if (isSubscribed) "مفعل (ترخيص عسكري حتى 2035) ✔️" else "غير مفعّل",
                        color = if (isSubscribed) SafeGreen else DangerRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(
                        onClick = { viewModel.logout() },
                        colors = ButtonDefaults.buttonColors(containerColor = DangerRed),
                        modifier = Modifier.fillMaxWidth().height(40.dp)
                    ) {
                        Text("قطع الجلسة وتسجيل الخروج", color = TextPrimary)
                    }
                }
            }
        }

        // Hardware protection modules setting
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, TechPurple, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("أجهزة الحماية العتادية", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isNfcProtected,
                            onCheckedChange = { viewModel.toggleNfc() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BgPrimary, checkedTrackColor = NeonCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("تأمين مستشعر NFC", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("منع هجمات القراءة والتعقب اللاسلكي", color = TextSecondary, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isUssdProtected,
                            onCheckedChange = { viewModel.toggleUssd() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BgPrimary, checkedTrackColor = NeonCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("حماية أكواد USSD (*#)", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("منع التطبيقات الخلفية من إطلاق الأكواد", color = TextSecondary, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Switch(
                            checked = isAdBlockActive,
                            onCheckedChange = { viewModel.toggleAdBlock() },
                            colors = SwitchDefaults.colors(checkedThumbColor = BgPrimary, checkedTrackColor = NeonCyan)
                        )
                        Column(horizontalAlignment = Alignment.End) {
                            Text("حظر الإعلانات الفتاكة AdBlock", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("منع تتبع النشاطات والإعلانات المنبثقة", color = TextSecondary, fontSize = 10.sp)
                        }
                    }
                }
            }
        }

        // About Hamo Electronic Info module
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = BgSecondary),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(2.dp, NeonCyan, RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), horizontalAlignment = Alignment.End) {
                    Text("حول المطور والمشروع", color = NeonCyan, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("• المطور: محمد حسام أبو حسين (Hamo Electronic)\n• الإصدار: Hamo Cyber Shield alpha v5.0.0\n• الدعم الفني المباشر عبر تليجرام.\n• منصة أمنية مصغرة متكاملة تحمي من كافة أنواع الهجمات (Zero-Day) لتسجيل الحماية العتادية الذكية.", color = TextPrimary, fontSize = 12.sp, textAlign = TextAlign.Right, lineHeight = 20.sp)
                }
            }
        }
    }
}
