package com.example.ui

import android.app.Application
import android.os.Build
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.SecurityLog
import com.example.data.ShieldRepository
import com.example.data.VaultItem
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ScanState {
    object Idle : ScanState
    data class Scanning(val progress: Float, val currentTask: String) : ScanState
    data class Completed(
        val threatScore: Int,
        val issuesFound: Int,
        val appsChecked: Int,
        val vulnerabilities: List<String>
    ) : ScanState
}

class HamoShieldViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: ShieldRepository

    val recentLogs: StateFlow<List<SecurityLog>>
    val vaultItems: StateFlow<List<VaultItem>>

    // Application state
    private val _scanState = MutableStateFlow<ScanState>(ScanState.Idle)
    val scanState: StateFlow<ScanState> = _scanState.asStateFlow()

    private val _isVpnConnected = MutableStateFlow(false)
    val isVpnConnected: StateFlow<Boolean> = _isVpnConnected.asStateFlow()

    private val _selectedVpnServer = MutableStateFlow("القاهرة (مصر)")
    val selectedVpnServer: StateFlow<String> = _selectedVpnServer.asStateFlow()

    private val _isStealthModeActive = MutableStateFlow(false)
    val isStealthModeActive: StateFlow<Boolean> = _isStealthModeActive.asStateFlow()

    private val _isNfcProtected = MutableStateFlow(true)
    val isNfcProtected: StateFlow<Boolean> = _isNfcProtected.asStateFlow()

    private val _isUssdProtected = MutableStateFlow(true)
    val isUssdProtected: StateFlow<Boolean> = _isUssdProtected.asStateFlow()

    private val _isAdBlockActive = MutableStateFlow(true)
    val isAdBlockActive: StateFlow<Boolean> = _isAdBlockActive.asStateFlow()

    // Auth & Subscription
    private val _isSubscribed = MutableStateFlow(false)
    val isSubscribed: StateFlow<Boolean> = _isSubscribed.asStateFlow()

    private val _isUserLoggedIn = MutableStateFlow(false)
    val isUserLoggedIn: StateFlow<Boolean> = _isUserLoggedIn.asStateFlow()

    private val _userEmail = MutableStateFlow("")
    val userEmail: StateFlow<String> = _userEmail.asStateFlow()

    // Subscription gate controls
    private val _joinedYoutube = MutableStateFlow(false)
    val joinedYoutube: StateFlow<Boolean> = _joinedYoutube.asStateFlow()

    private val _joinedTelegram = MutableStateFlow(false)
    val joinedTelegram: StateFlow<Boolean> = _joinedTelegram.asStateFlow()

    private val _joinedFacebook = MutableStateFlow(false)
    val joinedFacebook: StateFlow<Boolean> = _joinedFacebook.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = ShieldRepository(database.vaultItemDao(), database.securityLogDao())
        
        recentLogs = repository.recentLogs.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )
        vaultItems = repository.vaultItems.stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

        viewModelScope.launch {
            repository.seedMockLogsOnInitial()
        }
    }

    // Terminal command history
    private val _terminalOutput = MutableStateFlow<List<String>>(
        listOf(
            "==============================================",
            "Hamo Cyber Armored V5 [Micro-OS Core Shell]",
            "تم التحميل بنجاح. أدخل 'help' لعرض الأوامر.",
            "=============================================="
        )
    )
    val terminalOutput: StateFlow<List<String>> = _terminalOutput.asStateFlow()

    fun executeTerminalCommand(commandText: String) {
        val trimmed = commandText.trim()
        if (trimmed.isEmpty()) return

        val args = trimmed.split("\\s+".toRegex())
        val mainCmd = args[0].lowercase()

        viewModelScope.launch {
            val updatedList = _terminalOutput.value.toMutableList()
            updatedList.add("> $trimmed")

            when (mainCmd) {
                "help" -> {
                    updatedList.addAll(listOf(
                        "الأوامر المدعومة:",
                        "  help          - عرض هذه المساعدة",
                        "  clear         - مسح الشاشة",
                        "  sysinfo       - معلومات النظام العتادية",
                        "  ps            - العمليات الجارية وقوة حمايتها",
                        "  netstat       - الاتصالات الشبكية المفتوحة",
                        "  scan          - تشغيل محرك الفحص الفوري المسرّع",
                        "  vpn status   - عرض حالة نفق التوجيه التلقائي",
                        "  firewall status - التحقق من سلامة الجدار النظير"
                    ))
                }
                "clear" -> {
                    updatedList.clear()
                }
                "sysinfo" -> {
                    updatedList.addAll(listOf(
                        "درع النظام: Hamo Cyber Armored V5 (Micro-OS)",
                        "إصدار المعمارية: 128-bit Cyphered Engine Engine",
                        "إصدار أندرويد: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                        "الشركة المصنعة للجهاز: ${Build.MANUFACTURER} ${Build.MODEL}",
                        "بنية الحماية: تشفير AES-256-GCM"
                    ))
                }
                "ps" -> {
                    updatedList.addAll(listOf(
                        "الحالات الجارية:",
                        "  [PID 1109] core.hamo_micro_os -> آمن ومحمي (حماية عسكرية)",
                        "  [PID 2415] system.ui.shell     -> مستقر ومؤمّن",
                        "  [PID 8831] background.tflite_scan -> نشط (AI Behavioral Analyzer)"
                    ))
                }
                "netstat" -> {
                    updatedList.addAll(listOf(
                        "المنافذ النشطة المعزولة:",
                        "  TCP 192.168.1.104:443 -> SECURED (HTTPS TLS 1.3)",
                        "  UDP 127.0.0.1:51820   -> SECURED (WireGuard Active Tun)"
                    ))
                }
                "scan" -> {
                    updatedList.add("جارٍ بدء فحص سريع من الطرفية...")
                    startFullScan()
                }
                "vpn" -> {
                    val sublevel = if (args.size > 1) args[1].lowercase() else ""
                    if (sublevel == "status") {
                        val active = if (_isVpnConnected.value) "متصل بنجاح" else "غير متصل"
                        updatedList.add("حالة الـ VPN: $active | الخادم: ${_selectedVpnServer.value}")
                    } else {
                        updatedList.add("خطأ: استخدام غير صحيح للأمر. جرب 'vpn status'")
                    }
                }
                "firewall" -> {
                    val sublevel = if (args.size > 1) args[1].lowercase() else ""
                    if (sublevel == "status") {
                        updatedList.add("حالة جدار الحماية: نشط ويراقب 14 تطبيقاً حالياً.")
                    } else {
                        updatedList.add("خطأ: اكتب 'firewall status'")
                    }
                }
                else -> {
                    updatedList.add("أمر غير معروف: '$mainCmd'. اكتب 'help' للقائمة.")
                }
            }

            _terminalOutput.value = updatedList
        }
    }

    // Security Scan Control
    fun startFullScan() {
        viewModelScope.launch {
            _scanState.value = ScanState.Scanning(0.0f, "تمهيد محرك فحص حمو V5...")
            delay(800)
            _scanState.value = ScanState.Scanning(0.2f, "فحص تطبيقات النظام والبحث عن برامج التجسس...")
            delay(1000)
            _scanState.value = ScanState.Scanning(0.40f, "تحليل الأذونات وتتبع محاولات التجسس الصامتة...")
            delay(800)
            _scanState.value = ScanState.Scanning(0.65f, "فحص سلامة شبكة الـ WiFi والكشف عن ARP/MITM...")
            delay(1000)
            _scanState.value = ScanState.Scanning(0.85f, "مراجعة ثغرات النظام الحيوية (CVE-2026-11842)...")
            delay(800)
            _scanState.value = ScanState.Scanning(1.0f, "تصدير نتائج التقرير العسكري الآمن...")
            delay(400)

            _scanState.value = ScanState.Completed(
                threatScore = 95,
                issuesFound = 0,
                appsChecked = 142,
                vulnerabilities = listOf(
                    "شبكة البلوتوث آمنة بالكامل بفضل حماية Bluetooth Armor",
                    "محاولات Zero-Click و Buffer Overflow معزولة",
                    "لا يوجد أي ثغرات مكشوفة في برامج النظام الحالية"
                )
            )

            // Log event to repository
            repository.insertLog(
                SecurityLog(
                    type = "SUCCESS",
                    title = "اكتمل الفحص الشامل",
                    message = "تم فحص 142 تطبيقاً بنجاح. النتيجة: آمن بنسبة 95% ومؤمّن بالكامل ضد ثغرات Zero-Day."
                )
            )
        }
    }

    fun resetScanState() {
        _scanState.value = ScanState.Idle
    }

    // Interactive toggles
    fun toggleVpn() {
        viewModelScope.launch {
            val nextState = !_isVpnConnected.value
            _isVpnConnected.value = nextState
            val msg = if (nextState) "تم تفعيل شبكة VPN عسكرية عبر WireGuard" else "تم إيقاف اتصال VPN الآمن"
            val type = if (nextState) "SUCCESS" else "ALERT"
            repository.insertLog(
                SecurityLog(
                    type = type,
                    title = "شبكة VPN المشفرة",
                    message = "$msg. الخادم المفعّل: ${_selectedVpnServer.value}"
                )
            )
        }
    }

    fun setVpnServer(server: String) {
        _selectedVpnServer.value = server
        if (_isVpnConnected.value) {
            // Re-trigger connection message
            viewModelScope.launch {
                repository.insertLog(
                    SecurityLog(
                        type = "SUCCESS",
                        title = "تغيير خادم نفق VPN",
                        message = "تم التبديل بنجاح إلى خادم: $server"
                    )
                )
            }
        }
    }

    fun toggleStealthMode() {
        viewModelScope.launch {
            val nextState = !_isStealthModeActive.value
            _isStealthModeActive.value = nextState
            val msg = if (nextState) "تم حظر الكاميرا والميكروفون بالكامل على مستوى النظام" else "تم فك قفل الهاردوير الحساس"
            val type = if (nextState) "SUCCESS" else "ALERT"
            repository.insertLog(
                SecurityLog(
                    type = type,
                    title = "وضع التخفي المطلق",
                    message = msg
                )
            )
        }
    }

    fun toggleNfc() {
        _isNfcProtected.value = !_isNfcProtected.value
    }

    fun toggleUssd() {
        _isUssdProtected.value = !_isUssdProtected.value
    }

    fun toggleAdBlock() {
        _isAdBlockActive.value = !_isAdBlockActive.value
    }

    // Vault logic
    fun addVaultItem(title: String, user: String, pass: String, note: String) {
        viewModelScope.launch {
            val item = VaultItem(
                title = title,
                username = user,
                encryptedPassword = pass,
                secretNote = note
            )
            repository.insertVaultItem(item)
            repository.insertLog(
                SecurityLog(
                    type = "SUCCESS",
                    title = "تشفير وحفظ بالخزنة",
                    message = "تم تخزين كلمة المرور لـ '$title' باستخدام تشفير AES-256-GCM الفولاذي بنجاح."
                )
            )
        }
    }

    fun deleteVaultItem(id: Int) {
        viewModelScope.launch {
            repository.deleteVaultItem(id)
        }
    }

    // Auth & force-gate simulation logic
    fun login(email: String, pass: String) : Boolean {
        if (email.isNotBlank() && pass.length >= 8) {
            _userEmail.value = email
            _isUserLoggedIn.value = true
            viewModelScope.launch {
                repository.insertLog(
                    SecurityLog(
                        type = "SUCCESS",
                        title = "تسجيل دخول آمن",
                        message = "تم تسجيل دخول المستخدم '$email' بنجاح. الرمز المميز TLS نشط."
                    )
                )
            }
            return true
        }
        return false
    }

    fun googleSignIn() {
        _userEmail.value = "user.hamo@gmail.com"
        _isUserLoggedIn.value = true
        viewModelScope.launch {
            repository.insertLog(
                SecurityLog(
                    type = "SUCCESS",
                    title = "تسجيل دخول Google",
                    message = "تم التحقق من هوية Google بنجاح. حماية الهوية نشطة."
                )
            )
        }
    }

    fun logout() {
        _isUserLoggedIn.value = false
        _userEmail.value = ""
        _isSubscribed.value = false
        _joinedYoutube.value = false
        _joinedTelegram.value = false
        _joinedFacebook.value = false
    }

    fun attemptSubscribe() {
        _isSubscribed.value = true
        viewModelScope.launch {
            repository.insertLog(
                SecurityLog(
                    type = "SUCCESS",
                    title = "اشتراك نشط",
                    message = "تهانينا! اشتراكك مفعل الآن في الدرع المالي لحمو V5 كحساب مؤيد حتى عام 2035."
                )
            )
        }
    }

    fun setJoinedSocial(platform: String) {
        when (platform) {
            "youtube" -> _joinedYoutube.value = true
            "telegram" -> _joinedTelegram.value = true
            "facebook" -> _joinedFacebook.value = true
        }
        // Auto unlock premium if developer bypass simulation toggles are used,
        // or let them activate subscription manually.
        if (_joinedYoutube.value && _joinedTelegram.value && _joinedFacebook.value) {
            _isSubscribed.value = true
        }
    }

    fun clearAllLogs() {
        viewModelScope.launch {
            repository.clearLogs()
        }
    }
}
